const test = require('node:test');
const assert = require('node:assert/strict');
const Module = require('node:module');
const path = require('node:path');
const packageJson = require('../package.json');
const templates = require('../templates.json');

function setupExtension() {
    let registeredProvider;
    let receiveMessage;
    let writable = true;
    let warningResponses = [];
    let quickPickResponses = [];
    const warnings = [];
    const errors = [];
    const quickPickCalls = [];
    const registeredCommands = new Map();
    const insertedSnippets = [];
    const postedMessages = [];
    const disposable = { dispose() {} };
    const vscode = {
        commands: {
            registerCommand(id, callback) { registeredCommands.set(id, callback); return disposable; },
            async executeCommand() { return undefined; }
        },
        window: {
            activeTextEditor: undefined,
            registerWebviewViewProvider(id, provider) {
                registeredProvider = { id, provider };
                return disposable;
            },
            onDidChangeActiveTextEditor() { return disposable; },
            onDidChangeTextEditorSelection() { return disposable; },
            async showWarningMessage(...args) {
                warnings.push(args);
                return warningResponses.shift();
            },
            async showQuickPick(items, options) {
                quickPickCalls.push({ items, options });
                return quickPickResponses.shift();
            },
            async showErrorMessage(message) { errors.push(message); },
            setStatusBarMessage() { return disposable; }
        },
        workspace: {
            fs: { isWritableFileSystem() { return writable; } }
        },
        Position: class Position {},
        Selection: class Selection {},
        Range: class Range {},
        EndOfLine: { CRLF: 2, LF: 1 },
        SnippetString: class SnippetString { constructor(value) { this.value = value; } },
        env: { clipboard: { async writeText() {}, async readText() { return ''; } } }
    };

    const originalLoad = Module._load;
    const extensionPath = path.resolve(__dirname, '..', 'extension.js');
    delete require.cache[extensionPath];
    let extension;
    try {
        Module._load = function (request, parent, isMain) {
            if (request === 'vscode') return vscode;
            return originalLoad.call(this, request, parent, isMain);
        };
        extension = require(extensionPath);
    } finally {
        Module._load = originalLoad;
    }
    extension.activate({ subscriptions: [] });

    let html = '';
    const webview = {
        options: undefined,
        set html(value) { html = value; },
        get html() { return html; },
        onDidReceiveMessage(handler) { receiveMessage = handler; },
        async postMessage(message) { postedMessages.push(message); return true; }
    };
    registeredProvider.provider.resolveWebviewView({ webview, onDidDispose() {} });

    return {
        vscode,
        registeredProvider,
        postedMessages,
        insertedSnippets,
        warnings,
        errors,
        quickPickCalls,
        registeredCommands,
        get html() { return html; },
        get receiveMessage() { return receiveMessage; },
        set writable(value) { writable = value; },
        set warningResponses(value) { warningResponses = [...value]; },
        set quickPickResponses(value) { quickPickResponses = [...value]; }
    };
}

function makeEditor(languageId = 'python', hasSelection = false) {
    const selection = { isEmpty: !hasSelection };
    return {
        document: {
            isClosed: false,
            languageId,
            uri: { scheme: 'file', toString: () => 'file:///workspace/sample.' + (languageId === 'python' ? 'py' : languageId === 'cpp' ? 'cpp' : 'java') }
        },
        selections: [selection],
        async insertSnippet(snippet) {
            this.insertedSnippet = snippet.value;
            return true;
        }
    };
}

test('Secondary Side Barに登録され、Webview内のスクリプトが構文解析できる', () => {
    assert.equal(packageJson.version, '1.7.0');
    assert.equal(packageJson.engines.vscode, '^1.106.0');
    assert.ok(packageJson.contributes.viewsContainers.secondarySidebar);

    const app = setupExtension();
    assert.ok(app.registeredProvider);
    assert.equal(app.registeredProvider.id, 'unityAssistUndoRedo.panel');
    assert.match(app.html, /C\+\+/);
    assert.match(app.html, /Python/);
    assert.match(app.html, /Java/);
    const script = app.html.match(/<script[^>]*>([\s\S]*?)<\/script>/);
    assert.ok(script, 'Webview script not found');
    assert.doesNotThrow(() => new Function(script[1]));
    assert.match(script[1], /\\\$\\\{/); // Snippet placeholder preview regex is preserved after HTML generation.
});

test('テンプレート挿入は言語と選択範囲を確認してから実行する', async () => {
    const app = setupExtension();
    const editor = makeEditor('python', false);
    app.vscode.window.activeTextEditor = editor;

    await app.receiveMessage({ type: 'insertTemplate', templateId: 'python-if' });
    const pythonIf = templates.find((item) => item.id === 'python-if');
    assert.equal(editor.insertedSnippet, pythonIf.body);
    assert.ok(app.postedMessages.some((message) => message.type === 'complete'));
    assert.equal(app.warnings.length, 0);

    const cppEditor = makeEditor('cpp', false);
    app.vscode.window.activeTextEditor = cppEditor;
    app.warningResponses = ['挿入する'];
    await app.receiveMessage({ type: 'insertTemplate', templateId: 'python-for' });
    assert.equal(cppEditor.insertedSnippet, templates.find((item) => item.id === 'python-for').body);
    assert.match(app.warnings[0][0], /Python用テンプレート/);

    const selectedEditor = makeEditor('python', true);
    app.vscode.window.activeTextEditor = selectedEditor;
    app.warningResponses = ['置き換えて挿入'];
    await app.receiveMessage({ type: 'insertTemplate', templateId: 'python-while' });
    assert.equal(selectedEditor.insertedSnippet, templates.find((item) => item.id === 'python-while').body);
    assert.match(app.warnings[1][0], /選択中の1か所/);
});

test('読み取り専用ファイルにはテンプレートを挿入しない', async () => {
    const app = setupExtension();
    const editor = makeEditor('python', false);
    app.vscode.window.activeTextEditor = editor;
    app.writable = false;

    await app.receiveMessage({ type: 'insertTemplate', templateId: 'python-if' });
    assert.equal(editor.insertedSnippet, undefined);
    const errorMessage = app.postedMessages.findLast((message) => message.type === 'error');
    assert.ok(errorMessage);
    assert.match(errorMessage.message, /読み取り専用/);
});


test('コマンドパレットは未対応言語なら言語を選ばせ、失敗時は説明を表示する', async () => {
    const app = setupExtension();
    const command = app.registeredCommands.get('unityAssistUndoRedo.insertTemplate');
    assert.equal(typeof command, 'function');

    await command();
    assert.match(app.errors[0], /先にC\+\+・Python・Javaのファイルを開いてください/);

    const editor = makeEditor('plaintext', false);
    editor.document.uri = { scheme: 'file', toString: () => 'file:///workspace/readme.txt' };
    app.vscode.window.activeTextEditor = editor;
    app.quickPickResponses = [
        { label: 'C++', value: 'cpp' },
        { label: 'if文', templateId: 'cpp-if' }
    ];
    await command();
    assert.equal(editor.insertedSnippet, templates.find((item) => item.id === 'cpp-if').body);
    assert.equal(app.errors.length, 1);
});
