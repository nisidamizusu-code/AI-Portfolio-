const test = require('node:test');
const assert = require('node:assert/strict');
const templates = require('../templates.json');

test('C++・Python・Javaに各20種類のテンプレートがある', () => {
    const counts = templates.reduce((result, item) => {
        result[item.language] = (result[item.language] || 0) + 1;
        return result;
    }, {});
    assert.deepEqual(counts, { cpp: 20, python: 20, java: 20 });
});

test('テンプレートIDは重複せず、必要な項目が揃っている', () => {
    const ids = templates.map((item) => item.id);
    assert.equal(new Set(ids).size, ids.length);
    for (const item of templates) {
        assert.ok(item.id && item.title && item.description && item.body && item.placement);
        assert.ok(['cpp', 'python', 'java'].includes(item.language));
        assert.ok(Array.isArray(item.tags));
    }
});

test('すべてのテンプレートにTab移動可能な入力箇所がある', () => {
    for (const item of templates) {
        assert.match(item.body, /\$\{\d+:/, `${item.id} にプレースホルダーがありません`);
        assert.match(item.body, /\$\{0(?::[^}]*)?\}/, `${item.id} に最終カーソル位置がありません`);
        const rest = item.body
            .replace(/\$\{\d+(?::[^}]*)?\}/g, '')
            .replace(/\$\d+/g, '');
        assert.equal(rest.includes('$'), false, `${item.id} に不正なスニペット記号があります`);
    }
});
