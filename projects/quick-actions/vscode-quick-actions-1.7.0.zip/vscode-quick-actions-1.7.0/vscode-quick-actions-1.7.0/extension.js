const vscode = require('vscode');
const crypto = require('crypto');
const TEMPLATE_CATALOG = require('./templates.json');
const TEMPLATE_MAP = new Map(TEMPLATE_CATALOG.map((template) => [template.id, template]));

const VIEW_ID = 'unityAssistUndoRedo.panel';
const COMMAND_PREFIX = 'unityAssistUndoRedo';

function languageForDocument(languageId) {
    if (['cpp', 'c', 'objective-cpp', 'cuda-cpp'].includes(languageId)) return 'cpp';
    if (languageId === 'python') return 'python';
    if (languageId === 'java') return 'java';
    return null;
}

function activate(context) {
    const actions = {
        undo: { id: 'undo', label: '戻る', requiresEditor: true, focusEditor: true },
        redo: { id: 'redo', label: 'やり直す', requiresEditor: true, focusEditor: true },
        selectAll: { id: 'editor.action.selectAll', label: 'すべて選択', requiresEditor: true, focusEditor: true },
        copy: { id: 'editor.action.clipboardCopyAction', label: 'コピー', requiresEditor: true, requiresSelection: true, focusEditor: true },
        paste: { id: 'editor.action.clipboardPasteAction', label: '貼り付け', requiresEditor: true, requiresWritable: true, focusEditor: true },
        cut: { id: 'editor.action.clipboardCutAction', label: '切り取り', requiresEditor: true, requiresSelection: true, requiresWritable: true, focusEditor: true },
        zoomIn: { id: 'workbench.action.zoomIn', label: '画面の拡大' },
        zoomOut: { id: 'workbench.action.zoomOut', label: '画面の縮小' },
        zoomReset: { id: 'workbench.action.zoomReset', label: '画面表示のリセット' },
        save: { id: 'workbench.action.files.save', label: '保存', requiresEditor: true, focusEditor: true },
        find: { id: 'actions.find', label: 'ファイル内検索', requiresEditor: true, focusEditor: true },
        replace: { id: 'editor.action.startFindReplaceAction', label: '検索と置換', requiresEditor: true, focusEditor: true },
        duplicateLine: { id: 'editor.action.copyLinesDownAction', label: '行の複製', requiresEditor: true, requiresWritable: true, focusEditor: true },
        deleteLine: { id: 'editor.action.deleteLines', label: '行の削除', requiresEditor: true, requiresWritable: true, focusEditor: true },
        toggleComment: { id: 'editor.action.commentLine', label: 'コメント切り替え', requiresEditor: true, requiresWritable: true, focusEditor: true },
        formatDocument: { id: 'editor.action.formatDocument', label: 'ドキュメントの整形', requiresEditor: true, requiresWritable: true, focusEditor: true },
        toggleTerminal: { id: 'workbench.action.togglePanel', label: '下部パネル表示切り替え' },
        commandPalette: { id: 'workbench.action.showCommands', label: 'コマンドパレット' },
        goToLine: { id: 'workbench.action.gotoLine', label: '行へ移動', requiresEditor: true, focusEditor: true },
        moveLineUp: { id: 'editor.action.moveLinesUpAction', label: '行を上へ移動', requiresEditor: true, requiresWritable: true, focusEditor: true },
        moveLineDown: { id: 'editor.action.moveLinesDownAction', label: '行を下へ移動', requiresEditor: true, requiresWritable: true, focusEditor: true },
        previousEditor: { id: 'workbench.action.previousEditor', label: '前のタブ' },
        nextEditor: { id: 'workbench.action.nextEditor', label: '次のタブ' },
        reopenClosedEditor: { id: 'workbench.action.reopenClosedEditor', label: '閉じたタブを再度開く' },
        saveAll: { id: 'workbench.action.files.saveAll', label: 'すべて保存' },
        trimTrailingWhitespace: {
            label: '行末の空白削除',
            requiresEditor: true,
            requiresWritable: true,
            focusEditor: true,
            run: trimTrailingWhitespace
        },
        removeBlankLines: {
            label: '空行の削除',
            requiresEditor: true,
            requiresWritable: true,
            focusEditor: true,
            run: removeBlankLines
        },
        toUpperCase: {
            label: '大文字に変換',
            requiresEditor: true,
            requiresSelection: true,
            requiresWritable: true,
            focusEditor: true,
            run: (editor) => transformSelectionCase(editor, 'upper')
        },
        toLowerCase: {
            label: '小文字に変換',
            requiresEditor: true,
            requiresSelection: true,
            requiresWritable: true,
            focusEditor: true,
            run: (editor) => transformSelectionCase(editor, 'lower')
        },
        indentMore: {
            id: 'editor.action.indentLines',
            label: 'インデントを増やす',
            requiresEditor: true,
            requiresWritable: true,
            focusEditor: true
        },
        indentLess: {
            id: 'editor.action.outdentLines',
            label: 'インデントを減らす',
            requiresEditor: true,
            requiresWritable: true,
            focusEditor: true
        },
        wrapSelection: {
            label: '括弧・引用符で囲む',
            requiresEditor: true,
            requiresSelection: true,
            requiresWritable: true,
            focusEditor: true,
            run: wrapSelection
        }
    };

    const executeAction = async (key) => {
        const action = Object.prototype.hasOwnProperty.call(actions, key) ? actions[key] : undefined;
        if (!action) {
            throw new Error('この操作は見つかりませんでした。');
        }

        const editor = action.requiresEditor ? getActiveEditor() : vscode.window.activeTextEditor;
        if (action.requiresSelection && !hasTextSelection(editor)) {
            throw new Error('先に変換するテキストを選択してください。');
        }
        if (action.requiresWritable) {
            ensureWritableEditor(editor);
        }

        if (action.focusEditor) {
            await vscode.commands.executeCommand('workbench.action.focusActiveEditorGroup');
        }

        try {
            if (typeof action.run === 'function') {
                return await action.run(editor);
            }
            if (['selectAll', 'copy', 'paste', 'cut'].includes(key)) {
                return await runEditorSelectionAction(key, editor);
            }
            return await vscode.commands.executeCommand(action.id);
        } finally {
            if (action.focusEditor) {
                await vscode.commands.executeCommand('workbench.action.focusActiveEditorGroup');
            }
        }
    };

    const commands = Object.keys(actions).map((key) =>
        vscode.commands.registerCommand(`${COMMAND_PREFIX}.${key}`, () => executeAction(key))
    );
    const templateCommand = vscode.commands.registerCommand(`${COMMAND_PREFIX}.insertTemplate`, async () => {
        try {
            if (!vscode.window.activeTextEditor) {
                throw new Error('先にC++・Python・Javaのファイルを開いてください。');
            }

            const languageId = vscode.window.activeTextEditor.document.languageId;
            let detectedLanguage = languageForDocument(languageId);
            if (!detectedLanguage) {
                const languageChoice = await vscode.window.showQuickPick([
                    { label: 'C++', value: 'cpp' },
                    { label: 'Python', value: 'python' },
                    { label: 'Java', value: 'java' }
                ], { placeHolder: 'テンプレートの言語を選択してください' });
                if (!languageChoice) return;
                detectedLanguage = languageChoice.value;
            }

            const choices = TEMPLATE_CATALOG.filter((template) => template.language === detectedLanguage).map((template) => ({
                label: template.title,
                description: template.description,
                templateId: template.id
            }));
            const choice = await vscode.window.showQuickPick(choices, { placeHolder: '挿入するテンプレートを選択してください' });
            if (!choice) return;

            const result = await insertTemplate(choice.templateId);
            if (result && result.message) vscode.window.setStatusBarMessage(result.message, 3000);
        } catch (error) {
            const detail = error instanceof Error ? error.message : String(error);
            await vscode.window.showErrorMessage(`Quick Actions: ${detail}`);
        }
    });
    const provider = new QuickActionsViewProvider(actions, executeAction, TEMPLATE_CATALOG);

    context.subscriptions.push(
        ...commands,
        templateCommand,
        vscode.window.registerWebviewViewProvider(VIEW_ID, provider)
    );
}

function getActiveEditor() {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
        throw new Error('先に編集するファイルを開いてください。');
    }
    if (editor.document.isClosed) {
        throw new Error('このファイルは既に閉じられています。もう一度開いてください。');
    }
    return editor;
}

function ensureWritableEditor(editor) {
    if (!editor || !editor.document || editor.document.isClosed) {
        throw new Error('編集するファイルを開いてください。');
    }
    const writable = vscode.workspace.fs.isWritableFileSystem(editor.document.uri.scheme);
    if (writable === false) {
        throw new Error('このファイルは読み取り専用のため編集できません。');
    }
}

function hasTextSelection(editor) {
    return Boolean(editor && editor.selections.some((selection) => !selection.isEmpty));
}

async function runEditorSelectionAction(command, editor) {
    if (command === 'selectAll') {
        const start = new vscode.Position(0, 0);
        const end = editor.document.positionAt(editor.document.getText().length);
        editor.selection = new vscode.Selection(start, end);
        return { message: 'ファイル全体を選択しました。' };
    }

    const selections = editor.selections;
    const selectedRanges = selections.filter((selection) => !selection.isEmpty);

    if ((command === 'copy' || command === 'cut') && selectedRanges.length === 0) {
        throw new Error('先にコピーまたは切り取りするテキストを選択してください。');
    }

    if (command === 'copy' || command === 'cut') {
        const text = selectedRanges
            .map((selection) => editor.document.getText(selection))
            .join(editor.document.eol === vscode.EndOfLine.CRLF ? '\r\n' : '\n');
        await vscode.env.clipboard.writeText(text);
    }

    if (command === 'paste') {
        const text = await vscode.env.clipboard.readText();
        if (text.length === 0) {
            throw new Error('クリップボードに貼り付けるテキストがありません。');
        }
        const applied = await editor.edit((editBuilder) => {
            for (const selection of selections) {
                editBuilder.replace(selection, text);
            }
        });
        if (!applied) {
            throw new Error('貼り付けできませんでした。ファイルが編集可能か確認してください。');
        }
        return { message: '貼り付けました。' };
    }

    if (command === 'cut') {
        const applied = await editor.edit((editBuilder) => {
            for (const selection of selectedRanges) {
                editBuilder.delete(selection);
            }
        });
        if (!applied) {
            throw new Error('切り取りできませんでした。ファイルが編集可能か確認してください。');
        }
        return { message: '選択したテキストを切り取りました。' };
    }

    if (command === 'copy') {
        return { message: 'コピーしました。' };
    }
}

function getTargetLineNumbers(editor) {
    const selectedRanges = editor.selections.filter((selection) => !selection.isEmpty);
    if (selectedRanges.length === 0) {
        return Array.from({ length: editor.document.lineCount }, (_, index) => index);
    }

    const lineNumbers = new Set();
    for (const selection of selectedRanges) {
        let endLine = selection.end.line;
        if (endLine > selection.start.line && selection.end.character === 0) {
            endLine -= 1;
        }
        for (let line = selection.start.line; line <= endLine; line += 1) {
            lineNumbers.add(line);
        }
    }
    return [...lineNumbers].sort((a, b) => a - b);
}

async function trimTrailingWhitespace(editor) {
    const selectedRanges = editor.selections.filter((selection) => !selection.isEmpty);
    const lineNumbers = getTargetLineNumbers(editor);
    const updates = lineNumbers
        .map((lineNumber) => {
            const line = editor.document.lineAt(lineNumber);
            return {
                range: line.range,
                original: line.text,
                updated: line.text.replace(/[\t ]+$/u, '')
            };
        })
        .filter((item) => item.original !== item.updated);

    if (updates.length === 0) {
        return { message: '削除できる行末空白はありませんでした。' };
    }

    if (selectedRanges.length === 0) {
        const confirmed = await vscode.window.showWarningMessage(
            `ファイル全体の${updates.length}行から行末の空白を削除します。Markdownの改行表現や、文字列内の空白に影響する場合があります。`,
            { modal: true },
            '削除する'
        );
        if (confirmed !== '削除する') {
            return { message: '行末の空白削除をキャンセルしました。' };
        }
    }

    const applied = await editor.edit((editBuilder) => {
        for (const item of updates) {
            editBuilder.replace(item.range, item.updated);
        }
    });
    if (!applied) {
        throw new Error('空白を削除できませんでした。ファイルが編集可能か確認してください。');
    }
    return {
        message: `${updates.length}行の行末空白を削除しました。元に戻す操作で取り消せます。`
    };
}

async function removeBlankLines(editor) {
    const document = editor.document;
    const selectedRanges = editor.selections.filter((selection) => !selection.isEmpty);
    const lineNumbers = getTargetLineNumbers(editor);
    const targetSet = new Set(lineNumbers);
    const originalText = document.getText();
    const eol = document.eol === vscode.EndOfLine.CRLF ? '\r\n' : '\n';
    const hasFinalNewline = /(?:\r\n|\n|\r)$/u.test(originalText);
    const lines = originalText.split(/\r\n|\n|\r/u);
    const contentLines = hasFinalNewline ? lines.slice(0, -1) : lines;
    const keptLines = [];
    let removedCount = 0;

    contentLines.forEach((line, index) => {
        if (targetSet.has(index) && line.trim().length === 0) {
            removedCount += 1;
        } else {
            keptLines.push(line);
        }
    });

    if (removedCount === 0) {
        return { message: '削除できる空行はありませんでした。' };
    }

    const scopeLabel = selectedRanges.length > 0 ? '選択した範囲' : 'ファイル全体';
    const confirmed = await vscode.window.showWarningMessage(
        `${scopeLabel}から空行を${removedCount}行削除します。複数行文字列の中の空行も削除される場合があります。`,
        { modal: true },
        '削除する'
    );
    if (confirmed !== '削除する') {
        return { message: '空行の削除をキャンセルしました。' };
    }

    const updatedText = keptLines.join(eol) + (hasFinalNewline && keptLines.length > 0 ? eol : '');
    const lastLine = document.lineAt(document.lineCount - 1);
    const fullRange = new vscode.Range(new vscode.Position(0, 0), lastLine.range.end);
    const applied = await editor.edit((editBuilder) => editBuilder.replace(fullRange, updatedText));
    if (!applied) {
        throw new Error('空行を削除できませんでした。ファイルが編集可能か確認してください。');
    }

    return { message: `${removedCount}行の空行を削除しました。元に戻す操作で取り消せます。` };
}

async function transformSelectionCase(editor, mode) {
    const selections = editor.selections.filter((selection) => !selection.isEmpty);
    if (selections.length === 0) {
        throw new Error('大文字・小文字に変換する文字列を選択してください。');
    }

    let changedCount = 0;
    const applied = await editor.edit((editBuilder) => {
        for (const selection of selections) {
            const original = editor.document.getText(selection);
            const transformed = mode === 'upper' ? original.toUpperCase() : original.toLowerCase();
            if (transformed !== original) {
                editBuilder.replace(selection, transformed);
                changedCount += 1;
            }
        }
    });
    if (!applied) {
        throw new Error('文字を変換できませんでした。ファイルが編集可能か確認してください。');
    }

    const modeLabel = mode === 'upper' ? '大文字' : '小文字';
    return {
        message: changedCount > 0
            ? `選択した文字列を${modeLabel}に変換しました。`
            : `選択範囲は既に${modeLabel}です。`
    };
}

async function wrapSelection(editor) {
    const choices = [
        { label: '丸括弧  ( )', open: '(', close: ')' },
        { label: '角括弧  [ ]', open: '[', close: ']' },
        { label: '波括弧  { }', open: '{', close: '}' },
        { label: 'シングルクォート  \' \'', open: "'", close: "'" },
        { label: 'ダブルクォート  " "', open: '"', close: '"' }
    ];
    const choice = await vscode.window.showQuickPick(choices, {
        placeHolder: '選択した文字列を何で囲みますか？',
        ignoreFocusOut: true
    });
    if (!choice) {
        return { message: '囲む操作をキャンセルしました。' };
    }

    const selections = editor.selections.filter((selection) => !selection.isEmpty);
    if (selections.length === 0) {
        throw new Error('先に括弧や引用符で囲む文字列を選択してください。');
    }

    const applied = await editor.edit((editBuilder) => {
        for (const selection of selections) {
            editBuilder.insert(selection.start, choice.open);
            editBuilder.insert(selection.end, choice.close);
        }
    });
    if (!applied) {
        throw new Error('選択範囲を囲めませんでした。ファイルが編集可能か確認してください。');
    }
    return { message: `選択した文字列を${choice.label}で囲みました。` };
}

async function insertTemplate(templateId) {
    const template = TEMPLATE_MAP.get(templateId);
    if (!template) {
        throw new Error('選択したテンプレートが見つかりません。パネルを更新して再度お試しください。');
    }

    const editor = getActiveEditor();
    ensureWritableEditor(editor);

    const actualLanguage = languageForDocument(editor.document.languageId);
    if (actualLanguage && actualLanguage !== template.language) {
        const languageNames = { cpp: 'C++', python: 'Python', java: 'Java' };
        const confirmedLanguage = await vscode.window.showWarningMessage(
            `現在のファイルは${languageNames[actualLanguage]}ですが、${languageNames[template.language]}用テンプレートを挿入しようとしています。続けますか？`,
            { modal: true },
            '挿入する'
        );
        if (confirmedLanguage !== '挿入する') {
            return { message: 'テンプレートの挿入をキャンセルしました。' };
        }
    }

    const selectedRanges = editor.selections.filter((selection) => !selection.isEmpty);
    if (selectedRanges.length > 0) {
        const confirmedReplace = await vscode.window.showWarningMessage(
            `選択中の${selectedRanges.length}か所をテンプレートで置き換えます。続けますか？`,
            { modal: true },
            '置き換えて挿入'
        );
        if (confirmedReplace !== '置き換えて挿入') {
            return { message: '選択範囲を保持しました。テンプレートの挿入をキャンセルしました。' };
        }
    }

    const inserted = await editor.insertSnippet(new vscode.SnippetString(template.body));
    if (!inserted) {
        throw new Error('テンプレートを挿入できませんでした。カーソル位置やファイルの編集状態を確認してください。');
    }

    return { message: `${template.title}を挿入しました。Tabキーで入力箇所を移動できます。` };
}

class QuickActionsViewProvider {
    constructor(actions, executeAction, templates) {
        this.actions = actions;
        this.executeAction = executeAction;
        this.templates = templates;
        this.webviewView = undefined;
        this.disposables = [];
        this.isRunning = false;
    }

    resolveWebviewView(webviewView) {
        this.webviewView = webviewView;
        webviewView.webview.options = { enableScripts: true };
        webviewView.webview.html = this.getHtml(webviewView.webview);

        const sendContext = () => this.postContext();
        this.disposables.push(
            vscode.window.onDidChangeActiveTextEditor(sendContext),
            vscode.window.onDidChangeTextEditorSelection((event) => {
                if (event.textEditor === vscode.window.activeTextEditor) {
                    sendContext();
                }
            })
        );
        webviewView.onDidDispose(() => {
            this.webviewView = undefined;
            this.disposables.forEach((disposable) => disposable.dispose());
            this.disposables = [];
        });

        webviewView.webview.onDidReceiveMessage(async (message) => {
            if (!message || typeof message.type !== 'string') {
                return;
            }
            if (message.type === 'ready') {
                await this.postContext();
                return;
            }
            if (this.isRunning) {
                return;
            }

            const isActionRequest = message.type === 'run' && typeof message.command === 'string';
            const isTemplateRequest = message.type === 'insertTemplate' && typeof message.templateId === 'string';
            if (!isActionRequest && !isTemplateRequest) {
                return;
            }

            const action = isActionRequest && Object.prototype.hasOwnProperty.call(this.actions, message.command)
                ? this.actions[message.command]
                : undefined;
            const template = isTemplateRequest ? TEMPLATE_MAP.get(message.templateId) : undefined;
            if ((isActionRequest && !action) || (isTemplateRequest && !template)) {
                await this.postMessage({ type: 'error', message: '指定された操作またはテンプレートが見つかりません。' });
                return;
            }

            this.isRunning = true;
            await this.postMessage({ type: 'busy', busy: true });
            try {
                const result = isActionRequest
                    ? await this.executeAction(message.command)
                    : await insertTemplate(message.templateId);
                const defaultMessage = isActionRequest ? `${action.label}を実行しました。` : `${template.title}を挿入しました。`;
                await this.postMessage({
                    type: 'complete',
                    message: result && result.message ? result.message : defaultMessage
                });
            } catch (error) {
                const detail = error instanceof Error ? error.message : String(error);
                await this.postMessage({ type: 'error', message: detail });
            } finally {
                this.isRunning = false;
                await this.postMessage({ type: 'busy', busy: false });
                await this.postContext();
            }
        });

        this.postContext();
    }

    async postMessage(message) {
        if (this.webviewView) {
            await this.webviewView.webview.postMessage(message);
        }
    }

    async postContext() {
        if (!this.webviewView) {
            return;
        }
        const editor = vscode.window.activeTextEditor;
        await this.postMessage({
            type: 'context',
            hasEditor: Boolean(editor),
            hasSelection: hasTextSelection(editor),
            isWritable: editor ? vscode.workspace.fs.isWritableFileSystem(editor.document.uri.scheme) !== false : false,
            languageId: editor ? editor.document.languageId : '',
            documentId: editor ? editor.document.uri.toString() : ''
        });
    }

    getHtml(webview) {
        const nonce = getNonce();
        const csp = `default-src 'none'; style-src 'nonce-${nonce}'; script-src 'nonce-${nonce}';`;

        return `<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Security-Policy" content="${csp}">
    <style nonce="${nonce}">
        body {
            box-sizing: border-box;
            margin: 0;
            padding: 0 12px 16px;
            color: var(--vscode-foreground);
            background:
                radial-gradient(circle at top, color-mix(in srgb, var(--vscode-focusBorder) 12%, transparent) 0%, transparent 32%),
                linear-gradient(180deg, color-mix(in srgb, var(--vscode-sideBar-background) 92%, transparent) 0%, var(--vscode-sideBar-background) 100%);
            font-family: var(--vscode-font-family);
        }
        .header {
            position: sticky;
            top: 0;
            z-index: 2;
            margin: 0 -12px 12px;
            padding: 12px 12px 10px;
            background: color-mix(in srgb, var(--vscode-sideBar-background) 86%, transparent);
            border-bottom: 1px solid color-mix(in srgb, var(--vscode-panel-border) 88%, transparent);
            backdrop-filter: blur(10px);
        }
        .title-row { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
        h2 { margin: 0; font-size: 15px; font-weight: 700; letter-spacing: 0.04em; }
        #action-count { color: var(--vscode-descriptionForeground); font-size: 10px; font-weight: 700; letter-spacing: 0.08em; white-space: nowrap; text-transform: uppercase; }
        .mode-tabs { display: grid; grid-template-columns: 1fr 1fr; gap: 4px; margin-top: 10px; padding: 3px; border-radius: 10px; background: var(--vscode-input-background); }
        .mode-tab { justify-content: center; min-height: 30px; padding: 5px 8px; border-color: transparent; background: transparent; box-shadow: none; font-size: 11px; }
        .mode-tab.active { border-color: var(--vscode-panel-border); background: var(--vscode-sideBar-background); box-shadow: 0 1px 3px rgba(0,0,0,.12); }
        .search-wrap { position: relative; margin-top: 10px; }
        #action-search {
            box-sizing: border-box; width: 100%; min-height: 38px; padding: 9px 34px 9px 12px;
            border: 1px solid color-mix(in srgb, var(--vscode-input-border, var(--vscode-panel-border)) 82%, transparent);
            border-radius: 12px; outline: none; color: var(--vscode-input-foreground);
            background: color-mix(in srgb, var(--vscode-input-background) 85%, var(--vscode-sideBar-background));
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.12); font: inherit; font-size: 12px;
            transition: border-color 120ms ease, box-shadow 120ms ease, transform 120ms ease;
        }
        #action-search:focus { border-color: var(--vscode-focusBorder); box-shadow: 0 0 0 1px rgba(128, 188, 255, 0.35), inset 0 1px 3px rgba(0, 0, 0, 0.12); }
        #clear-search {
            position: absolute; top: 5px; right: 5px; width: 26px; min-height: 26px; padding: 0;
            border: 0; border-radius: 8px; color: var(--vscode-descriptionForeground); background: transparent;
            cursor: pointer; font-size: 16px; line-height: 1;
        }
        #clear-search:hover { color: var(--vscode-foreground); background: var(--vscode-toolbar-hoverBackground); }
        .hint { margin: 8px 2px 0; color: var(--vscode-descriptionForeground); font-size: 10px; letter-spacing: 0.02em; line-height: 1.5; }
        .section {
            margin: 0 0 10px; border: 1px solid color-mix(in srgb, var(--vscode-panel-border) 85%, transparent);
            border-radius: 12px; background: color-mix(in srgb, var(--vscode-sideBar-background) 95%, var(--vscode-editor-background));
            overflow: hidden; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
        }
        .section summary {
            display: flex; min-height: 42px; align-items: center; justify-content: space-between; padding: 0 12px;
            color: var(--vscode-foreground); font-size: 12px; font-weight: 700; cursor: pointer;
            list-style: none; user-select: none;
            background: linear-gradient(180deg, color-mix(in srgb, var(--vscode-list-hoverBackground) 22%, transparent) 0%, transparent 100%);
        }
        .section summary::-webkit-details-marker { display: none; }
        .section summary::before {
            display: inline-flex; align-items: center; justify-content: center; width: 18px; margin-right: 6px;
            color: color-mix(in srgb, var(--vscode-focusBorder) 80%, var(--vscode-descriptionForeground));
            content: "›"; font-size: 16px; transition: transform 120ms ease;
        }
        .section[open] summary::before { transform: rotate(90deg); }
        .section summary:hover { background: var(--vscode-list-hoverBackground); }
        .section[hidden] { display: none; }
        .section-count { margin-left: auto; color: var(--vscode-descriptionForeground); font-size: 10px; font-weight: 700; letter-spacing: 0.08em; }
        .grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px; padding: 10px 10px 12px; }
        .language-tabs { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 6px; margin: 0 0 6px; }
        .language-tab { justify-content: center; min-height: 34px; padding: 6px 8px; }
        .language-tab.active { border-color: var(--vscode-focusBorder); background: var(--vscode-list-activeSelectionBackground); color: var(--vscode-list-activeSelectionForeground, var(--vscode-foreground)); }
        .template-hint { margin: 2px 2px 10px; }
        .template-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px; }
        .template-card { display: flex; flex-direction: column; align-items: flex-start; justify-content: center; gap: 4px; min-height: 54px; padding: 9px 10px; }
        .template-card strong { font-size: 12px; line-height: 1.35; }
        .template-card span { color: var(--vscode-descriptionForeground); font-size: 10px; font-weight: 400; line-height: 1.35; }
        .template-card[aria-pressed="true"] { border-color: var(--vscode-focusBorder); background: var(--vscode-list-activeSelectionBackground); }
        #template-empty-state { display: none; padding: 18px 10px 8px; color: var(--vscode-descriptionForeground); text-align: center; font-size: 12px; }
        .preview-card { margin-top: 12px; padding: 12px; border: 1px solid var(--vscode-focusBorder); border-radius: 12px; background: var(--vscode-editorWidget-background); }
        .preview-card[hidden] { display: none; }
        .preview-heading { display: flex; align-items: center; justify-content: space-between; gap: 8px; font-size: 13px; }
        .icon-button { width: 28px; min-height: 28px; justify-content: center; padding: 0; font-size: 16px; }
        .preview-description { margin: 8px 0; color: var(--vscode-foreground); font-size: 11px; line-height: 1.6; }
        .preview-meta { margin: 5px 0; color: var(--vscode-descriptionForeground); font-size: 10px; line-height: 1.5; overflow-wrap: anywhere; }
        .code-preview { max-height: 260px; overflow: auto; margin: 9px 0; padding: 10px; border: 1px solid var(--vscode-panel-border); border-radius: 8px; background: var(--vscode-textCodeBlock-background); color: var(--vscode-editor-foreground); font-family: var(--vscode-editor-font-family); font-size: 11px; line-height: 1.55; white-space: pre; tab-size: 4; }
        .insert-button { justify-content: center; width: 100%; }
        #actions-view[hidden], #templates-view[hidden] { display: none; }
        button {
            position: relative; display: flex; align-items: center; min-width: 0; min-height: 42px; padding: 9px 10px;
            border: 1px solid color-mix(in srgb, var(--vscode-panel-border) 82%, transparent); border-radius: 10px;
            color: var(--vscode-foreground);
            background: linear-gradient(180deg, color-mix(in srgb, var(--vscode-sideBar-background) 96%, var(--vscode-list-hoverBackground)) 0%, var(--vscode-sideBar-background) 100%);
            font: inherit; font-size: 12px; font-weight: 600; cursor: pointer; overflow-wrap: anywhere; text-align: left;
            transition: transform 80ms ease, border-color 120ms ease, box-shadow 120ms ease, background-color 120ms ease;
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.04);
        }
        button:hover:not(:disabled) { border-color: var(--vscode-focusBorder); background: var(--vscode-list-hoverBackground); transform: translateY(-1px); box-shadow: 0 4px 9px rgba(0, 0, 0, 0.07); }
        button:active:not(:disabled) { transform: translateY(0) scale(0.985); box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.12); }
        button.primary {
            border-color: color-mix(in srgb, var(--vscode-button-background) 75%, transparent);
            color: var(--vscode-button-foreground);
            background: linear-gradient(180deg, var(--vscode-button-background) 0%, color-mix(in srgb, var(--vscode-button-background) 78%, black) 100%);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.14);
        }
        button.primary:hover:not(:disabled) { background: var(--vscode-button-hoverBackground); }
        button.wide { grid-column: 1 / -1; }
        button:focus-visible { outline: 1px solid var(--vscode-focusBorder); outline-offset: 2px; }
        button:disabled { opacity: 0.42; cursor: not-allowed; transform: none; box-shadow: none; }
        button.is-busy:disabled { opacity: 0.72; cursor: wait; }
        #clear-search { min-height: 24px; border: 0; text-align: center; }
        #clear-search:hover { border-color: transparent; }
        button[hidden] { display: none; }
        #empty-state { display: none; padding: 18px 10px 8px; color: var(--vscode-descriptionForeground); text-align: center; font-size: 12px; font-weight: 600; }
        #status {
            min-height: 20px; margin: 8px 0 0; padding: 8px 10px; border: 1px solid var(--vscode-panel-border);
            border-radius: 10px; background: color-mix(in srgb, var(--vscode-editorWidget-background) 85%, var(--vscode-sideBar-background));
            overflow-wrap: anywhere; font-size: 11px; line-height: 1.5; box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.03);
        }
        #status:empty { display: none; }
        #status.error { color: var(--vscode-errorForeground); border-color: color-mix(in srgb, var(--vscode-errorForeground) 35%, var(--vscode-panel-border)); }
        @media (prefers-reduced-motion: reduce) { button, #action-search, .section summary::before { transition: none; } }
    </style>
</head>
<body>
    <header class="header">
        <div class="title-row"><h2>Quick Actions</h2><span id="action-count" aria-live="polite"></span></div>
        <div class="mode-tabs" role="tablist" aria-label="表示する機能">
            <button type="button" class="mode-tab active" data-mode="actions" role="tab" aria-selected="true">操作</button>
            <button type="button" class="mode-tab" data-mode="templates" role="tab" aria-selected="false">テンプレート</button>
        </div>
        <div class="search-wrap">
            <input id="action-search" type="search" placeholder="操作名で検索…" aria-label="操作を検索">
            <button id="clear-search" type="button" aria-label="検索をクリア" title="検索をクリア" hidden>×</button>
        </div>
        <p class="hint" id="context-hint">ファイルを開くと編集操作が使えます。「/」で検索、Escで解除。</p>
    </header>
    <div id="actions-view">
    <details class="section" data-section open>
        <summary>よく使う <span class="section-count"></span></summary>
        <div class="grid">
            <button type="button" class="primary" data-command="save" data-search="保存 save ctrl s" data-requires-editor title="現在のファイルを保存します。">保存</button>
            <button type="button" data-command="undo" data-search="戻る undo ctrl z" data-requires-editor title="直前の編集操作を取り消します。">戻る</button>
            <button type="button" data-command="redo" data-search="やり直す redo ctrl shift z" data-requires-editor title="取り消した操作をやり直します。">やり直す</button>
            <button type="button" data-command="find" data-search="検索 ファイル内検索 find search" data-requires-editor title="現在開いているファイル内の文字列を検索します。">検索</button>
            <button type="button" data-command="toggleTerminal" data-search="ターミナル terminal 下部パネル 表示切替" title="ターミナルや問題など、下部パネルの表示を切り替えます。">下部パネル表示</button>
            <button type="button" data-command="saveAll" data-search="すべて保存 save all" title="開いているファイルをすべて保存します。">すべて保存</button>
        </div>
    </details>
    <details class="section" data-section>
        <summary>編集 <span class="section-count"></span></summary>
        <div class="grid">
            <button type="button" data-command="selectAll" data-search="すべて選択 select all" data-requires-editor title="現在のファイル内の内容をすべて選択します。">すべて選択</button>
            <button type="button" data-command="copy" data-search="コピー copy" data-requires-editor data-requires-selection title="選択したテキストをコピーします。">コピー</button>
            <button type="button" data-command="paste" data-search="貼り付け paste" data-requires-editor data-requires-write title="クリップボードの内容をカーソル位置に貼り付けます。">貼り付け</button>
            <button type="button" data-command="cut" data-search="切り取り cut" data-requires-editor data-requires-write data-requires-selection title="選択したテキストを切り取ります。">切り取り</button>
            <button type="button" data-command="duplicateLine" data-search="行を複製 duplicate line" data-requires-editor data-requires-write title="カーソルがある行を下に複製します。">行を複製</button>
            <button type="button" data-command="deleteLine" data-search="行を削除 delete line" data-requires-editor data-requires-write title="カーソルがある行を削除します。">行を削除</button>
            <button type="button" data-command="moveLineUp" data-search="行を上へ move line up" data-requires-editor data-requires-write title="カーソルがある行を1行上へ移動します。">行を上へ</button>
            <button type="button" data-command="moveLineDown" data-search="行を下へ move line down" data-requires-editor data-requires-write title="カーソルがある行を1行下へ移動します。">行を下へ</button>
            <button type="button" data-command="toggleComment" data-search="コメント切替 comment toggle" data-requires-editor data-requires-write title="選択範囲または現在の行のコメントを切り替えます。">コメント切替</button>
            <button type="button" data-command="formatDocument" data-search="コード整形 format document" data-requires-editor data-requires-write title="現在のファイルを利用可能なフォーマッターで整形します。">コード整形</button>
        </div>
    </details>
    <details class="section" data-section>
        <summary>コード整理・変換 <span class="section-count"></span></summary>
        <div class="grid">
            <button type="button" data-command="trimTrailingWhitespace" data-search="行末 空白 削除 whitespace trim" data-requires-editor data-requires-write title="選択した行、またはファイル全体の行末にある空白を削除します。">行末の空白削除</button>
            <button type="button" data-command="removeBlankLines" data-search="空行 削除 blank lines" data-requires-editor data-requires-write title="選択範囲、または確認後にファイル全体の空行を削除します。">空行の削除</button>
            <button type="button" data-command="toUpperCase" data-search="大文字 uppercase upper case" data-requires-editor data-requires-selection data-requires-write title="選択した文字列を大文字に変換します。文字列を選択すると使えます。">大文字に変換</button>
            <button type="button" data-command="toLowerCase" data-search="小文字 lowercase lower case" data-requires-editor data-requires-selection data-requires-write title="選択した文字列を小文字に変換します。文字列を選択すると使えます。">小文字に変換</button>
            <button type="button" data-command="indentMore" data-search="インデント 増やす indent in" data-requires-editor data-requires-write title="現在の行、または選択行のインデントを増やします。">インデントを増やす</button>
            <button type="button" data-command="indentLess" data-search="インデント 減らす indent outdent" data-requires-editor data-requires-write title="現在の行、または選択行のインデントを減らします。">インデントを減らす</button>
            <button type="button" class="wide" data-command="wrapSelection" data-search="括弧 引用符 囲む wrap parentheses quotes" data-requires-editor data-requires-selection data-requires-write title="選択した文字列を括弧や引用符で囲みます。文字列を選択すると使えます。">括弧・引用符で囲む</button>
        </div>
    </details>
    <details class="section" data-section>
        <summary>検索・移動 <span class="section-count"></span></summary>
        <div class="grid">
            <button type="button" data-command="find" data-search="検索 ファイル内検索 find search" data-requires-editor title="現在開いているファイル内の文字列を検索します。">ファイル内検索</button>
            <button type="button" data-command="replace" data-search="検索 置換 replace find" data-requires-editor title="現在のファイル内で検索した文字列を置き換えます。">検索と置換</button>
            <button type="button" data-command="goToLine" data-search="行へ移動 goto line" data-requires-editor title="行番号を指定して移動します。">行へ移動</button>
            <button type="button" data-command="commandPalette" data-search="コマンドパレット command palette" title="VS Codeで実行できるコマンドの一覧を開きます。">コマンド一覧</button>
        </div>
    </details>
    <details class="section" data-section>
        <summary>画面表示 <span class="section-count"></span></summary>
        <div class="grid">
            <button type="button" data-command="zoomIn" data-search="画面 拡大 zoom in" title="VS Code全体の表示を拡大します。">画面を拡大</button>
            <button type="button" data-command="zoomOut" data-search="画面 縮小 zoom out" title="VS Code全体の表示を縮小します。">画面を縮小</button>
            <button type="button" class="wide" data-command="zoomReset" data-search="画面 リセット reset" title="VS Code全体の表示倍率を初期状態に戻します。">画面表示をリセット</button>
        </div>
    </details>
    <details class="section" data-section>
        <summary>タブ <span class="section-count"></span></summary>
        <div class="grid">
            <button type="button" data-command="previousEditor" data-search="前のタブ previous tab" title="ひとつ前に開いていたタブへ移動します。">前のタブ</button>
            <button type="button" data-command="nextEditor" data-search="次のタブ next tab" title="次のタブへ移動します。">次のタブ</button>
            <button type="button" class="wide" data-command="reopenClosedEditor" data-search="閉じたタブ 再度開く reopen closed" title="直前に閉じたエディターを再度開きます。">閉じたタブを再度開く</button>
        </div>
    </details>
    <p id="empty-state">該当する操作がありません。</p>
    </div>
    <div id="templates-view" hidden>
        <div class="language-tabs" role="tablist" aria-label="テンプレートの言語">
            <button type="button" class="language-tab" data-language="cpp" role="tab" aria-selected="false">C++</button>
            <button type="button" class="language-tab active" data-language="python" role="tab" aria-selected="true">Python</button>
            <button type="button" class="language-tab" data-language="java" role="tab" aria-selected="false">Java</button>
        </div>
        <p class="hint template-hint" id="language-hint">現在のファイルに合わせて言語を自動選択します。タブから手動で変更できます。</p>
        <div id="template-list" class="template-grid"></div>
        <p id="template-empty-state">該当するテンプレートがありません。</p>
        <section id="template-preview" class="preview-card" hidden aria-live="polite">
            <div class="preview-heading">
                <strong id="preview-title"></strong>
                <button type="button" id="close-preview" class="icon-button" aria-label="プレビューを閉じる">×</button>
            </div>
            <p id="preview-description" class="preview-description"></p>
            <p id="preview-placement" class="preview-meta"></p>
            <p id="preview-requirements" class="preview-meta"></p>
            <pre id="preview-code" class="code-preview"></pre>
            <p class="preview-meta">選択中の文字列がある場合は、確認後に置き換えて挿入します。</p>
            <button type="button" id="insert-template" class="primary insert-button" disabled>カーソル位置に挿入</button>
        </section>
    </div>
    <p id="status" role="status" aria-live="polite"></p>
    <script nonce="${nonce}">
        const templateCatalog = ${JSON.stringify(this.templates).replace(/</g, '\\u003c')};
        const vscode = acquireVsCodeApi();
        const status = document.getElementById('status');
        const search = document.getElementById('action-search');
        const count = document.getElementById('action-count');
        const emptyState = document.getElementById('empty-state');
        const contextHint = document.getElementById('context-hint');
        const actionsView = document.getElementById('actions-view');
        const templatesView = document.getElementById('templates-view');
        const modeTabs = [...document.querySelectorAll('[data-mode]')];
        const languageTabs = [...document.querySelectorAll('[data-language]')];
        const templateList = document.getElementById('template-list');
        const templateEmptyState = document.getElementById('template-empty-state');
        const templatePreview = document.getElementById('template-preview');
        const previewTitle = document.getElementById('preview-title');
        const previewDescription = document.getElementById('preview-description');
        const previewPlacement = document.getElementById('preview-placement');
        const previewRequirements = document.getElementById('preview-requirements');
        const previewCode = document.getElementById('preview-code');
        const insertTemplateButton = document.getElementById('insert-template');
        const closePreviewButton = document.getElementById('close-preview');
        const languageHint = document.getElementById('language-hint');
        const sections = [...document.querySelectorAll('[data-section]')];
        const buttons = [...document.querySelectorAll('button[data-command]')];
        const sectionState = sections.map((section) => section.open);
        const clearSearchButton = document.getElementById('clear-search');
        let contextState = { hasEditor: false, hasSelection: false, isWritable: false, languageId: '', documentId: '' };
        let activeMode = 'actions';
        let activeLanguage = 'python';
        let manualLanguage = false;
        let lastDocumentId = '';
        let selectedTemplateId = null;
        let busy = false;

        function updateStatus(message, isError = false) {
            status.textContent = message || '';
            status.className = isError ? 'error' : '';
        }

        function updateAvailability() {
            buttons.forEach((button) => {
                const needsEditor = button.hasAttribute('data-requires-editor');
                const needsSelection = button.hasAttribute('data-requires-selection');
                const needsWrite = button.hasAttribute('data-requires-write');
                const unavailable = (needsEditor && !contextState.hasEditor) ||
                    (needsSelection && !contextState.hasSelection) ||
                    (needsWrite && contextState.hasEditor && !contextState.isWritable);
                button.disabled = busy || unavailable;
                if (!button.dataset.baseTitle) button.dataset.baseTitle = button.title;
                if (!busy && needsEditor && !contextState.hasEditor) {
                    button.title = button.dataset.baseTitle + '（先にファイルを開いてください）';
                } else if (!busy && needsSelection && !contextState.hasSelection && contextState.hasEditor) {
                    button.title = button.dataset.baseTitle + '（先に文字列を選択してください）';
                } else if (!busy && needsWrite && contextState.hasEditor && !contextState.isWritable) {
                    button.title = button.dataset.baseTitle + '（このファイルは編集できません）';
                } else {
                    button.title = button.dataset.baseTitle;
                }
                button.classList.toggle('is-busy', busy);
                if (busy) {
                    button.setAttribute('aria-busy', 'true');
                } else {
                    button.removeAttribute('aria-busy');
                }
            });

            if (!contextState.hasEditor) {
                contextHint.textContent = 'ファイルを開くと編集操作が使えます。「/」で検索、Escで解除。';
            } else if (!contextState.isWritable) {
                contextHint.textContent = 'このファイルは読み取り専用です。編集操作は利用できません。';
            } else if (!contextState.hasSelection) {
                contextHint.textContent = '文字変換・囲む操作は、先にエディターで文字列を選択してください。';
            } else {
                contextHint.textContent = '選択範囲に使える操作が有効になっています。「/」で検索できます。';
            }
            insertTemplateButton.disabled = busy || !contextState.hasEditor || !contextState.isWritable;
        }

        function detectLanguage(languageId) {
            if (['cpp', 'c', 'objective-cpp', 'cuda-cpp'].includes(languageId)) return 'cpp';
            if (languageId === 'python') return 'python';
            if (languageId === 'java') return 'java';
            return null;
        }

        function updateLanguageTabs() {
            languageTabs.forEach((tab) => {
                const active = tab.dataset.language === activeLanguage;
                tab.classList.toggle('active', active);
                tab.setAttribute('aria-selected', active ? 'true' : 'false');
            });
            if (manualLanguage) {
                languageHint.textContent = '言語を手動で選択中です。現在のファイルと異なる言語のテンプレートは挿入前に確認します。';
            } else if (detectLanguage(contextState.languageId)) {
                languageHint.textContent = '現在のファイルに合わせて言語を自動選択しています。タブから手動で変更できます。';
            } else if (contextState.hasEditor) {
                languageHint.textContent = 'このファイルの言語は自動判定対象外です。C++・Python・Javaから選択してください。';
            } else {
                languageHint.textContent = 'ファイルを開くと対応言語を自動選択します。タブから手動で選択することもできます。';
            }
        }

        function setMode(mode) {
            activeMode = mode;
            const showTemplates = mode === 'templates';
            actionsView.hidden = showTemplates;
            templatesView.hidden = !showTemplates;
            modeTabs.forEach((tab) => {
                const active = tab.dataset.mode === mode;
                tab.classList.toggle('active', active);
                tab.setAttribute('aria-selected', active ? 'true' : 'false');
            });
            search.placeholder = showTemplates ? 'テンプレートを検索…' : '操作名で検索…';
            if (showTemplates) renderTemplates();
            else filterActions();
            search.focus();
        }

        function snippetPreview(body) {
            return body
                .replace(/\\$\\{(\\d+):([^}]*)\\}/gu, (_, number, value) => value)
                .replace(/\\$\\{(\\d+)\\|([^}]*)\\|\\}/gu, (_, number, choices) => choices.split(',')[0])
                .replace(/\\$\\{(\\d+)\\}/gu, '')
                .replace(/\\$(\\d+)/gu, '');
        }

        function showTemplatePreview(template) {
            selectedTemplateId = template.id;
            previewTitle.textContent = template.title;
            previewDescription.textContent = template.description;
            previewPlacement.textContent = '挿入位置の目安：' + template.placement;
            previewRequirements.textContent = template.requirements ? '必要な準備：' + template.requirements : '必要な準備：特になし';
            previewCode.textContent = snippetPreview(template.body);
            templatePreview.hidden = false;
            [...templateList.querySelectorAll('[data-template-id]')].forEach((button) => {
                button.setAttribute('aria-pressed', button.dataset.templateId === template.id ? 'true' : 'false');
            });
            updateAvailability();
        }

        function renderTemplates() {
            const query = search.value.trim().toLocaleLowerCase();
            const matches = templateCatalog.filter((template) => {
                if (template.language !== activeLanguage) return false;
                const searchable = [template.title, template.description, template.tags.join(' '), template.requirements]
                    .join(' ').toLocaleLowerCase();
                return searchable.includes(query);
            });
            templateList.replaceChildren();
            matches.forEach((template) => {
                const button = document.createElement('button');
                button.type = 'button';
                button.className = 'template-card';
                button.dataset.templateId = template.id;
                button.setAttribute('aria-pressed', template.id === selectedTemplateId ? 'true' : 'false');
                const title = document.createElement('strong');
                title.textContent = template.title;
                const description = document.createElement('span');
                description.textContent = template.description;
                button.append(title, description);
                templateList.append(button);
            });
            templateEmptyState.style.display = matches.length === 0 ? 'block' : 'none';
            count.textContent = query ? matches.length + '件' : matches.length + 'テンプレート';
        }

        modeTabs.forEach((tab) => tab.addEventListener('click', () => setMode(tab.dataset.mode)));
        languageTabs.forEach((tab) => tab.addEventListener('click', () => {
            activeLanguage = tab.dataset.language;
            manualLanguage = true;
            updateLanguageTabs();
            renderTemplates();
            templatePreview.hidden = true;
            selectedTemplateId = null;
        }));
        templateList.addEventListener('click', (event) => {
            const button = event.target.closest('[data-template-id]');
            if (!button) return;
            const template = templateCatalog.find((item) => item.id === button.dataset.templateId);
            if (template) showTemplatePreview(template);
        });
        closePreviewButton.addEventListener('click', () => {
            templatePreview.hidden = true;
            selectedTemplateId = null;
            renderTemplates();
        });
        insertTemplateButton.addEventListener('click', () => {
            if (!selectedTemplateId || insertTemplateButton.disabled || busy) return;
            updateStatus('');
            vscode.postMessage({ type: 'insertTemplate', templateId: selectedTemplateId });
        });

        sections.forEach((section, index) => {
            section.addEventListener('toggle', () => {
                if (!search.value.trim()) sectionState[index] = section.open;
            });
        });

        function filterActions() {
            const query = search.value.trim().toLocaleLowerCase();
            let visibleCount = 0;
            sections.forEach((section, index) => {
                const sectionButtons = [...section.querySelectorAll('button[data-command]')];
                let sectionCount = 0;
                sectionButtons.forEach((button) => {
                    const searchableText = (button.dataset.search || button.textContent || button.title || '').toLocaleLowerCase();
                    const visible = searchableText.includes(query);
                    button.hidden = !visible;
                    if (visible) sectionCount += 1;
                });
                section.hidden = sectionCount === 0;
                section.querySelector('.section-count').textContent = query ? sectionCount + '件' : sectionButtons.length + '件';
                section.open = query ? sectionCount > 0 : sectionState[index];
                visibleCount += sectionCount;
            });
            count.textContent = query ? visibleCount + '件' : buttons.length + '操作';
            emptyState.style.display = visibleCount === 0 ? 'block' : 'none';
        }

        function updateClearSearchButton() {
            clearSearchButton.hidden = search.value.trim().length === 0;
        }

        search.addEventListener('input', () => {
            if (activeMode === 'templates') renderTemplates();
            else filterActions();
            updateClearSearchButton();
        });
        clearSearchButton.addEventListener('click', () => {
            search.value = '';
            if (activeMode === 'templates') renderTemplates();
            else filterActions();
            updateClearSearchButton();
            search.focus();
        });
        search.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') {
                search.value = '';
                if (activeMode === 'templates') renderTemplates();
                else filterActions();
                updateClearSearchButton();
            }
        });
        document.addEventListener('keydown', (event) => {
            if (event.key === '/' && !event.ctrlKey && !event.metaKey && !event.altKey &&
                !['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) {
                event.preventDefault();
                search.focus();
            }
        });

        buttons.forEach((button) => {
            button.addEventListener('click', () => {
                if (button.disabled || busy) return;
                updateStatus('');
                vscode.postMessage({ type: 'run', command: button.dataset.command });
            });
        });

        window.addEventListener('message', (event) => {
            const message = event.data;
            if (!message || typeof message.type !== 'string') return;
            if (message.type === 'context') {
                contextState = {
                    hasEditor: Boolean(message.hasEditor),
                    hasSelection: Boolean(message.hasSelection),
                    isWritable: Boolean(message.isWritable),
                    languageId: typeof message.languageId === 'string' ? message.languageId : '',
                    documentId: typeof message.documentId === 'string' ? message.documentId : ''
                };
                if (contextState.documentId !== lastDocumentId) {
                    lastDocumentId = contextState.documentId;
                    manualLanguage = false;
                }
                const detectedLanguage = detectLanguage(contextState.languageId);
                if (detectedLanguage && !manualLanguage && activeLanguage !== detectedLanguage) {
                    activeLanguage = detectedLanguage;
                    templatePreview.hidden = true;
                    selectedTemplateId = null;
                }
                updateLanguageTabs();
                updateAvailability();
                if (activeMode === 'templates') renderTemplates();
            } else if (message.type === 'busy') {
                busy = Boolean(message.busy);
                updateAvailability();
            } else if (message.type === 'complete') {
                updateStatus(message.message || '操作が完了しました。');
                busy = false;
                updateAvailability();
            } else if (message.type === 'error') {
                updateStatus(message.message || '操作を実行できませんでした。', true);
                busy = false;
                updateAvailability();
            }
        });

        filterActions();
        renderTemplates();
        updateLanguageTabs();
        updateClearSearchButton();
        updateAvailability();
        vscode.postMessage({ type: 'ready' });
    </script>
</body>
</html>`;
    }
}

function getNonce() {
    return crypto.randomBytes(16).toString('base64');
}

function deactivate() {}

module.exports = { activate, deactivate };
