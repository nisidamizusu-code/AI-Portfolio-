# Build / Change Report — Unity Assist Texture Color Engine 0.1.0-preview.8

## Base

- Base package: `0.1.0-preview.7`
- Purpose: prevent false-positive selection in two-point flows when source anchor colors are near-neutral.

## Changes

- Treat OKLCH hue as a valid flow axis only when both source anchors have chroma of at least 0.02.
- For flows with at least one near-neutral anchor, compare each pixel's OKLab a/b coordinates against the expected source path and taper selection by a small corridor tolerance.
- Added a regression case using the two RGB anchor colors shown in the user's screenshot: (245, 244, 244) and (201, 196, 192). The case includes a warm, chromatic distractor with matching lightness and an in-between hue; it must remain unchanged while the neutral midpoint is recolored.
- Preserved the preview.7 OKLab projection/interpolation for flow progress and destination color.
- Left single-color conversion, texture import, editor UI, and PNG export unchanged.

## Verification

- Reviewed the modified source and regression test.
- Confirmed package and assembly-definition JSON syntax.
- Confirmed archive integrity after packaging.
- Ran a numerical Python reproduction of the neutral-anchor selection gate: the neutral midpoint passes the corridor, while the warm chromatic distractor is rejected.

## Not performed

- Unity C# compilation and NUnit Test Runner execution (Unity Editor is not available in this environment).
- Visual confirmation on the user's complete original texture.

Treat this as a targeted candidate build until it is tested in the user's Unity project.
