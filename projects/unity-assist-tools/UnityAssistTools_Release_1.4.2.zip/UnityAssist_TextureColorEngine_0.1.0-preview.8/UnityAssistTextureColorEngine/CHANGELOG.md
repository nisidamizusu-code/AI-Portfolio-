## 0.1.0-preview.8

- Fixed two-point selection for near-neutral source anchors. OKLCH hue values are no longer treated as a valid flow axis unless both anchors have sufficient chroma.
- Added an OKLab a/b corridor gate for near-neutral flows so vivid warm/cool pixels with coincidentally matching hue and lightness are not selected.
- Kept the unified OKLab progress projection and target interpolation introduced in preview.7.
- Kept single-color conversion, image loading, UI, and PNG export paths unchanged.
- Added a regression test using the same near-neutral anchor RGB values shown in the user's screenshot and a warm distractor with matching lightness.

## 0.1.0-preview.7

- 2点変換の進行度を、OKLCHの明度・彩度・色相それぞれの進行度の加重平均から、OKLab空間の線分射影へ変更。
- 変換元・変換先の中間色をOKLabで補間し、複数の色成分が同時に変化する素材での色の流れの偏りを軽減。
- 低彩度画素では不安定な色相差分を陰影・色相残差として反映しないよう調整。
- 2点変換の滑らかな色流れに関する回帰テストを追加。
- 単色変換および既存の対象色判定ロジックは変更なし。

## 0.1.0-preview.6

- Removed development-only wording about the 1.4.1 UI from the editor window.
- Renamed the visible Unity menu item and window title to Texture Color Replacer.
- Simplified user-facing instructions and removed the technical read-method row.
- Kept the runtime color engine, image loading, recoloring, and export logic unchanged.

## 0.1.0-preview.5

- Replaced target-color HEX text fields with Unity's native visual Color Picker field.
- Kept single-color and two-point target color values as ordinary LDR colors; alpha and HDR controls are hidden.
- Left runtime color recognition, recoloring algorithms, source loading, and export code unchanged.

# Changelog

## 0.1.0-preview.4
- Fixed missing scalar `Lerp(float, float, float)` helper in `MaterialColorProfile`.
- Updated package version and build report.

## 0.1.0-preview.3
- Added hex sRGB target-color entry to the sandbox.
- Allowed sandbox PNG export into `Assets/` even when the source asset is under `Packages/`.
- Expanded research and license tracking.

