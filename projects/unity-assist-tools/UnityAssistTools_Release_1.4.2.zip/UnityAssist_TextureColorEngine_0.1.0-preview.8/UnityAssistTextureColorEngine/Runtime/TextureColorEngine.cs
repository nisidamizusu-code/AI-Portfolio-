using System;

namespace UnityAssist.TextureColorEngine
{
    /// <summary>Internal defaults for VRC clothing textures. These are not intended as UI sliders.</summary>
    public sealed class EngineSettings
    {
        public float ShadingRetention = 0.76f;
        public float HueVariationRetention = 0.12f;
        public float ChromaVariationRetention = 0.12f;
        public float TwoPointLightnessMargin = 0.065f;
        public float TwoPointHueMarginDegrees = 9f;
        public float TwoPointChromaMargin = 0.025f;
        public byte TransparentAlphaThreshold = 16;

        public EngineSettings Clone()
        {
            return (EngineSettings)MemberwiseClone();
        }
    }

    /// <summary>
    /// Independent pixel engine. It has no EditorWindow, mask-painting UI, AI dependency, or dependency on the 1.4.1 UI.
    /// Selection is based on a lightness-conditioned hue/chroma profile and independent channel gates, never a Euclidean color-distance radius.
    /// </summary>
    public static class TextureColorEngine
    {
        private const float MinimumApplyWeight = 0.01f;

        public static MaterialColorProfile BuildSingleColorProfile(TexturePixels source, int sampleX, int sampleY)
        {
            return MaterialColorProfile.Build(source, sampleX, sampleY);
        }

        public static RecolorResult RecolorSingle(
            TexturePixels source,
            int sampleX,
            int sampleY,
            Rgba32 targetColor,
            EngineSettings settings = null)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            settings = settings ?? new EngineSettings();
            MaterialColorProfile profile = MaterialColorProfile.Build(source, sampleX, sampleY);
            Oklch target = ColorMath.ToOklch(targetColor);
            int sampleIndex = sampleY * source.Width + sampleX;
            Rgba32[] output = new Rgba32[source.Pixels.Length];
            int matched = 0;
            int partial = 0;
            int opaque = 0;

            for (int i = 0; i < source.Pixels.Length; i++)
            {
                Rgba32 pixel = source.Pixels[i];
                if (pixel.A < settings.TransparentAlphaThreshold)
                {
                    output[i] = pixel;
                    continue;
                }
                opaque++;
                if (i == sampleIndex)
                {
                    // The sampled source pixel is the exact anchor; it must map exactly to the target color.
                    output[i] = new Rgba32(targetColor.R, targetColor.G, targetColor.B, pixel.A);
                    matched++;
                    continue;
                }

                Oklch current = ColorMath.ToOklch(pixel);
                float weight = profile.GetSelectionWeight(current);
                if (weight <= MinimumApplyWeight)
                {
                    output[i] = pixel;
                    continue;
                }

                float profileHue, hueTolerance, medianChroma, minChroma, maxChroma;
                profile.GetAtLightness(current.L, out profileHue, out hueTolerance, out medianChroma, out minChroma, out maxChroma);

                float hueResidual = current.C < 0.012f ? 0f : ColorMath.SignedHueDelta(profileHue, current.H);
                float chromaRatio = current.C / Math.Max(0.012f, medianChroma);
                chromaRatio = ColorMath.Clamp(chromaRatio, 0.72f, 1.55f);

                // Replace material hue/chroma while preserving subdued per-pixel variation and most original luminance detail.
                Oklch changed = new Oklch(
                    target.L + (current.L - profile.SampleColor.L) * ColorMath.Clamp01(settings.ShadingRetention),
                    target.C * (1f + (chromaRatio - 1f) * ColorMath.Clamp01(settings.ChromaVariationRetention)),
                    target.H + hueResidual * ColorMath.Clamp01(settings.HueVariationRetention));

                Oklab blended = ColorMath.Blend(ColorMath.ToOklab(current), ColorMath.ToOklab(changed), weight);
                Oklch outputLch = ColorMath.ToOklch(blended);
                output[i] = ColorMath.ToSrgb(outputLch, pixel.A);
                if (weight >= 0.999f) matched++;
                else partial++;
            }

            return new RecolorResult(new TexturePixels(source.Width, source.Height, output, true), matched, partial, opaque);
        }

        public static RecolorResult RecolorTwoPoint(
            TexturePixels source,
            int startX,
            int startY,
            int endX,
            int endY,
            Rgba32 targetStartColor,
            Rgba32 targetEndColor,
            EngineSettings settings = null)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            settings = settings ?? new EngineSettings();
            if (startX < 0 || startY < 0 || startX >= source.Width || startY >= source.Height)
                throw new ArgumentOutOfRangeException("1点目の座標がテクスチャ範囲外です。");
            if (endX < 0 || endY < 0 || endX >= source.Width || endY >= source.Height)
                throw new ArgumentOutOfRangeException("2点目の座標がテクスチャ範囲外です。");
            Rgba32 startPixel = source.Pixels[startY * source.Width + startX];
            Rgba32 endPixel = source.Pixels[endY * source.Width + endX];
            if (startPixel.A < settings.TransparentAlphaThreshold)
                throw new InvalidOperationException("1点目が透明ピクセルです。");
            if (endPixel.A < settings.TransparentAlphaThreshold)
                throw new InvalidOperationException("2点目が透明ピクセルです。");

            Oklch sourceStart = ColorMath.ToOklch(startPixel);
            Oklch sourceEnd = ColorMath.ToOklch(endPixel);
            Oklch targetStart = ColorMath.ToOklch(targetStartColor);
            Oklch targetEnd = ColorMath.ToOklch(targetEndColor);

            // Use one perceptual coordinate system for the flow itself. Independent L/C/H
            // progress values can disagree on real textures (especially when hue and lightness
            // change together), producing uneven or visibly bent transitions.
            Oklab sourceStartLab = ColorMath.ToOklab(sourceStart);
            Oklab sourceEndLab = ColorMath.ToOklab(sourceEnd);
            Oklab targetStartLab = ColorMath.ToOklab(targetStart);
            Oklab targetEndLab = ColorMath.ToOklab(targetEnd);

            float deltaL = sourceEnd.L - sourceStart.L;
            float deltaC = sourceEnd.C - sourceStart.C;
            float deltaH = ColorMath.SignedHueDelta(sourceStart.H, sourceEnd.H);
            float absL = Math.Abs(deltaL);
            float absC = Math.Abs(deltaC);
            float absH = Math.Abs(deltaH);
            bool useL = absL >= 0.045f;
            bool useC = absC >= 0.025f;

            // OKLCH hue is undefined for near-neutral colors. Tiny RGB channel differences can
            // produce large numerical hue swings even though the colors are perceptually gray.
            // Only treat hue as an actual flow axis when BOTH anchors have enough chroma.
            const float reliableHueChroma = 0.02f;
            bool useHueFlow = absH >= 5.0f &&
                              sourceStart.C >= reliableHueChroma &&
                              sourceEnd.C >= reliableHueChroma;
            bool useNeutralFlow = sourceStart.C < reliableHueChroma || sourceEnd.C < reliableHueChroma;

            if (!useL && !useC && !useHueFlow)
                throw new InvalidOperationException("2点の色が近すぎます。明暗・彩度・色相の違いが十分ある2点を指定してください。");

            // For ordinary chromatic materials, retain the image-adaptive hue profile.
            // For neutral flows, hue is not a meaningful discriminator; a/b corridor gating
            // below prevents unrelated vivid pixels with similar lightness from being selected.
            MaterialColorProfile profile = (useHueFlow || useNeutralFlow)
                ? null
                : MaterialColorProfile.Build(source, startX, startY);
            float neutralFlowAbTolerance = Math.Min(
                0.035f,
                Math.Max(0.015f, Math.Max(sourceStart.C, sourceEnd.C) * 1.5f + 0.004f));
            int startIndex = startY * source.Width + startX;
            int endIndex = endY * source.Width + endX;

            Rgba32[] output = new Rgba32[source.Pixels.Length];
            int matched = 0;
            int partial = 0;
            int opaque = 0;

            for (int i = 0; i < source.Pixels.Length; i++)
            {
                Rgba32 pixel = source.Pixels[i];
                if (pixel.A < settings.TransparentAlphaThreshold)
                {
                    output[i] = pixel;
                    continue;
                }
                opaque++;
                if (i == startIndex)
                {
                    output[i] = new Rgba32(targetStartColor.R, targetStartColor.G, targetStartColor.B, pixel.A);
                    matched++;
                    continue;
                }
                if (i == endIndex)
                {
                    output[i] = new Rgba32(targetEndColor.R, targetEndColor.G, targetEndColor.B, pixel.A);
                    matched++;
                    continue;
                }

                Oklch current = ColorMath.ToOklch(pixel);
                Oklab currentLab = ColorMath.ToOklab(current);
                float axisWeight = 1f;
                if (useL)
                {
                    float min = Math.Min(sourceStart.L, sourceEnd.L) - settings.TwoPointLightnessMargin;
                    float max = Math.Max(sourceStart.L, sourceEnd.L) + settings.TwoPointLightnessMargin;
                    axisWeight *= RangeWeight(current.L, min, max, 0.02f);
                }

                float minimumSourceChroma = Math.Min(sourceStart.C, sourceEnd.C);
                float maximumSourceChroma = Math.Max(sourceStart.C, sourceEnd.C);
                if (useC)
                {
                    // The chroma margin is relative to the selected material so a nearly neutral pixel
                    // cannot enter a colorful flow solely because the user selected a very dark endpoint.
                    float adaptiveMargin = Math.Min(settings.TwoPointChromaMargin, Math.Max(0.006f, minimumSourceChroma * 0.35f));
                    float min = Math.Max(0f, minimumSourceChroma - adaptiveMargin);
                    float max = maximumSourceChroma + settings.TwoPointChromaMargin;
                    axisWeight *= RangeWeight(current.C, min, max, 0.01f);
                }
                else if (maximumSourceChroma >= 0.012f && !useNeutralFlow)
                {
                    // Independent neutral guard for a mostly constant-chroma flow.
                    float materialFloor = minimumSourceChroma * 0.24f;
                    float low = Math.Max(0.006f, materialFloor * 0.45f);
                    float high = Math.Max(0.014f, materialFloor);
                    axisWeight *= ColorMath.SmoothStep(low, high, current.C);
                }

                if (useHueFlow)
                {
                    // Both chromatic endpoints define the allowed hue arc.
                    axisWeight *= HueArcRangeWeight(current.H, sourceStart.H, deltaH, settings.TwoPointHueMarginDegrees);
                }
                else if (profile != null)
                {
                    // When hue is not the flow axis but the anchors are still chromatic,
                    // use the texture's lightness-conditioned material hue profile.
                    float profileHue, tolerance, medianC, minC, maxC;
                    profile.GetAtLightness(current.L, out profileHue, out tolerance, out medianC, out minC, out maxC);
                    float hueLimit = Math.Max(tolerance, settings.TwoPointHueMarginDegrees);
                    float hueWeight = 1f - ColorMath.SmoothStep(hueLimit, hueLimit + 5f, ColorMath.HueDistance(profileHue, current.H));
                    axisWeight *= hueWeight;
                }

                if (useNeutralFlow)
                {
                    // A near-neutral anchor has an unstable hue angle. Compare the pixel's
                    // chromatic coordinates against the expected source path instead. This
                    // prevents warm/orange pixels from being accepted just because their
                    // arbitrary hue happens to fall between two almost-gray anchors.
                    float neutralProgress = DetermineProgress(currentLab, sourceStartLab, sourceEndLab);
                    Oklab expectedNeutral = Oklab.Lerp(sourceStartLab, sourceEndLab, neutralProgress);
                    float da = currentLab.A - expectedNeutral.A;
                    float db = currentLab.B - expectedNeutral.B;
                    float abDistance = (float)Math.Sqrt(da * da + db * db);
                    float neutralWeight = 1f - ColorMath.SmoothStep(
                        neutralFlowAbTolerance * 0.55f,
                        neutralFlowAbTolerance,
                        abDistance);
                    axisWeight *= neutralWeight;
                }

                float weight = ColorMath.Clamp01(axisWeight);
                if (weight <= MinimumApplyWeight)
                {
                    output[i] = pixel;
                    continue;
                }

                float t = DetermineProgress(currentLab, sourceStartLab, sourceEndLab);

                // Interpolate both the source path and the destination path in OKLab. This
                // keeps the progress parameter consistent even when the OKLCH hue/chroma
                // coordinates bend or pass close to the neutral axis.
                Oklch expectedSource = ColorMath.ToOklch(Oklab.Lerp(sourceStartLab, sourceEndLab, t));
                Oklch expectedTarget = ColorMath.ToOklch(Oklab.Lerp(targetStartLab, targetEndLab, t));
                float lightnessResidual = (current.L - expectedSource.L) * ColorMath.Clamp01(settings.ShadingRetention);
                float hueResidual = (current.C < 0.012f || expectedSource.C < 0.012f)
                    ? 0f
                    : ColorMath.SignedHueDelta(expectedSource.H, current.H) * ColorMath.Clamp01(settings.HueVariationRetention);
                float chromaRatio = current.C / Math.Max(0.015f, expectedSource.C);
                chromaRatio = ColorMath.Clamp(chromaRatio, 0.72f, 1.55f);
                Oklch changed = new Oklch(
                    expectedTarget.L + lightnessResidual,
                    expectedTarget.C * (1f + (chromaRatio - 1f) * ColorMath.Clamp01(settings.ChromaVariationRetention)),
                    expectedTarget.H + hueResidual);

                Oklab blended = ColorMath.Blend(currentLab, ColorMath.ToOklab(changed), weight);
                output[i] = ColorMath.ToSrgb(ColorMath.ToOklch(blended), pixel.A);
                if (weight >= 0.999f) matched++;
                else partial++;
            }

            return new RecolorResult(new TexturePixels(source.Width, source.Height, output, true), matched, partial, opaque);
        }

        /// <summary>
        /// Projects a pixel onto the source segment in OKLab and returns its normalized
        /// position. A single projection avoids averaging unrelated L/C/H progress values.
        /// The existing axis gates remain responsible for deciding whether the pixel belongs
        /// to the selected material flow.
        /// </summary>
        private static float DetermineProgress(Oklab pixel, Oklab start, Oklab end)
        {
            float dL = end.L - start.L;
            float dA = end.A - start.A;
            float dB = end.B - start.B;
            float lengthSquared = dL * dL + dA * dA + dB * dB;
            if (lengthSquared <= 0.0000001f) return 0f;

            float pL = pixel.L - start.L;
            float pA = pixel.A - start.A;
            float pB = pixel.B - start.B;
            float projection = pL * dL + pA * dA + pB * dB;
            return ColorMath.Clamp01(projection / lengthSquared);
        }

        private static float RangeWeight(float value, float min, float max, float softness)
        {
            if (value < min) return ColorMath.SmoothStep(min - softness, min, value);
            if (value > max) return 1f - ColorMath.SmoothStep(max, max + softness, value);
            return 1f;
        }

        private static float HueArcRangeWeight(float hue, float startHue, float signedDelta, float marginDegrees)
        {
            float progress = ColorMath.SignedHueDelta(startHue, hue) / signedDelta;
            float margin = marginDegrees / Math.Max(5f, Math.Abs(signedDelta));
            if (progress < 0f) return ColorMath.SmoothStep(-margin, 0f, progress);
            if (progress > 1f) return 1f - ColorMath.SmoothStep(1f, 1f + margin, progress);
            return 1f;
        }
    }
}
