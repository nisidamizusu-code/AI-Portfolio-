# CHANGELOG — Unity Assist Tools

## Release 1.4.1 Preview — 2026-11-12

### Project File Colorizer 1.1.1
- 手動カラータグの選択取得を `Selection.assetGUIDs` に変更。Project Browserの2列表示で左列からフォルダーを選択した場合もGUIDを取得できるようにした。
- 右クリックメニューの検証コールバックを取り除き、コンテキストメニューの表示時点でSelectionが確定していない場合に項目が無効化される可能性を回避。
- 設定の保存を見直し、初回は検証済み一時ファイルを新規作成先へコピー、2回目以降はUnity Editorの `FileUtil.ReplaceFile` で置換。置換前バックアップ、保存後の再読込検証、失敗時のバックアップ復元を追加。
- 起動時にメイン設定ファイルが欠落・破損している場合、バックアップから復旧する処理を追加。
- 右クリックに加えて、設定ウィンドウから選択中アセットへカスタムカラーを設定できる入口を追加。
- 既存9分類、カテゴリ色設定、EditorPrefsキー、ON/OFF、アセット表示処理を維持。

### Other packages carried forward unchanged
- Transform Helper 1.0.2
- Texture Color Replacer 1.3.0

## Release 1.4.0 Preview — 2026-11-12 (superseded)
- 手動カラータグ、色別アセット一覧、検索、選択・Ping機能の初回実装。
- このPreviewはユーザー環境で正常動作しなかったため、1.4.1で選択取得と設定保存の処理を見直した。1.4.0は使用しないこと。

## Release 1.3.0 — 2026-11-10
- 3つのツールを独立したUnity UPMパッケージとして整理。
- Project File Colorizerの既存Projectウィンドウ色分け、カテゴリ色設定、EditorPrefs保存を維持。
- Transform Helperの選択更新、Undo/Redo再描画、親子二重適用防止、数値検査を追加。
- Texture Color ReplacerのOKLab色判定、マスク編集、色変換、PNG保存を統合。
