# テスト・検査報告 — Unity Assist Tools Release 1.4.1 Preview

検査日: 2026-11-12

## 検査結果

静的・構成検査38項目と、保存・復旧処理のファイル操作を模した検証4項目を実施し、合計42項目が通過しました。これらはソース・パッケージ構成・保存処理設計の検査であり、Unity Editor上のコンパイルや実操作テストではありません。

| 検査 | 結果 | 内容 |
|---|---|---|
| package.json / asmdef | PASS | 3パッケージのJSON構文を検証 |
| パッケージID・バージョン | PASS | 既存IDを維持し、Project File Colorizerを1.1.1へ更新 |
| `.meta` GUID | PASS | 同梱メタファイルのGUID重複なし |
| C#字句・括弧構造 | PASS | 変更した2ファイルを字句解析し、括弧・文字列・コメント構造を確認 |
| MenuItem登録 | PASS | メニュー項目パスの重複なし。Assets配下に登録 |
| 選択取得 | PASS | Projectウィンドウ用の `Selection.assetGUIDs` を使用 |
| コンテキストメニュー | PASS | 選択状態が確定する前に無効化される可能性のある検証コールバックを削除 |
| 設定保存 | PASS | 初回は検証済み一時ファイルを新規作成先へコピー。既存ファイルはUnity Editorの `FileUtil.ReplaceFile` で置換 |
| 保存後検証 | PASS | 一時ファイル・保存先の両方でGUIDと色の内容を照合 |
| バックアップ | PASS | 置換前バックアップ、失敗時復元、起動時の欠落・破損ファイルからの復旧処理を確認 |
| 旧機能の保持 | PASS | EditorPrefsキー、ON/OFF、9分類、既定色マッピング、拡張子分類を維持 |
| 既存分類メソッド | PASS | `GetDefaultColor` と `GetCategory` の実装内容がRelease 1.3.0と一致 |
| 他パッケージ | PASS | Transform HelperとTexture Color Replacerの主要ソースはRelease 1.3.0とバイト単位で一致 |
| ロールバックZIP | PASS | 同梱Release 1.3.0 ZIPのSHA-256が元のRelease 1.3.0 ZIPと一致 |
| 保存・復旧模擬検証 | PASS | 初回保存、連続保存、保存失敗時の復元、破損ファイルからのバックアップ復旧を検証 |
| ZIP整合性 | PASS | 作成後にZIP CRC、展開、同梱ファイルを確認 |

## 今回見直した箇所

### 1. Projectウィンドウの選択取得

前回Previewでは `Selection.objects` からアセットパスを取得してGUIDへ変換していました。今回は `Selection.assetGUIDs` を使う構成に変更しました。UnityのAPI資料では、Project Browserの2列表示で左列からフォルダーを選んだ場合も扱えるため、アセット選択時はこのプロパティを使うことが推奨されています。

### 2. 右クリックメニュー

前回Previewでは各メニュー項目に選択状態を確認する検証関数を付けていました。Projectコンテキストメニューで検証関数が呼ばれるタイミングに依存しないよう、検証コールバックを削除しました。実行時に選択GUIDを取得し、対象がない場合は警告して何も変更しません。

### 3. 設定の保存

前回Previewで使っていた `System.IO.File.Replace` を廃止しました。初回保存は検証済み一時ファイルを新しい保存先へコピーし、既存設定の更新ではUnity 2021.3のEditor APIである `FileUtil.ReplaceFile` を使います。既存設定のバックアップ、置換後の再読込検証、失敗時の復元を行います。メイン設定が破損・欠落した場合はバックアップからの復旧を試みます。

### 4. 右クリック以外の設定入口

`Tools > Unity File Colorizer` の設定ウィンドウに「選択中のアセットに色を設定」ボタンを追加しました。右クリックメニューの操作が難しい場合も、Projectウィンドウでアセットを選択してから設定できます。

## Unity Editor上で未実施の検査

この作成環境にはUnity EditorおよびC#コンパイラ（dotnet / csc / mcs）がありません。そのため、以下は未実施です。

- Unity 2021.3での実コンパイル
- Projectウィンドウ右クリックメニューの実表示・カラー適用
- 単体・複数アセットへの色付け、カスタムカラー、色解除
- 2列表示のProject Browserで左列フォルダーを選んだ場合の色設定
- ProjectSettingsへの保存、Unity再起動後の復元、バックアップ復旧
- ファイル名変更・フォルダー移動後のGUID追跡
- 色別グループ一覧、検索、選択・Ping、個別解除
- 大量のタグを登録した場合のEditor操作負荷
- Windows / macOSでの実ファイル置換動作

したがって、本リリースは静的検査と保存処理の模擬検証に通過したPreviewです。Unity Editor上の実動作まで合格したという意味ではありません。Release 1.3.0を残したまま、複製プロジェクトでのみ確認してください。

## Unity上での確認手順

1. 既存プロジェクトを複製し、複製側でテストします。
2. Package ManagerからProject File Colorizerの旧版だけを削除し、今回の `Packages/UnityProjectFileColorizer/package.json` を追加します。Transform HelperとTexture Color Replacerは変更していないため、そのまま残します。
3. Consoleに赤いコンパイルエラーがないことを確認します。
4. Projectウィンドウでアセットを選択し、右クリックの `Unity Assist Tools > カラータグ` から色を付けます。
5. `Tools > Unity File Colorizer > Color Groups` を開き、検索・表示・解除を確認します。
6. Unityを再起動し、色が保持されていることを確認します。
7. アセットの改名・フォルダー移動を行い、色が追従することを確認します。
8. 既存9分類、カテゴリ色、ON/OFFがRelease 1.3.0と同じように動作することを確認します。

問題があれば1.4.1の使用を中止し、手元で正常動作を確認済みのRelease 1.3.0へ戻してください。同梱のRollback版も元の1.3.0 ZIPとSHA-256が一致することを確認しています。
