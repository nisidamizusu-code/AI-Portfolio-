# Unity Assist Tools — Release 1.4.1 Preview

> Preview build: 静的検査は完了していますが、Unity Editor上のコンパイル・実操作はこの作成環境では実行できていません。必ず複製プロジェクトで確認してください。

このリリースは3つの独立したUnity UPMパッケージを収録します。Project File Colorizerに、手動カラータグと色別アセット一覧を追加しています。

## パッケージ一覧

| ツール | UPM ID | バージョン | 主な機能 |
|---|---|---:|---|
| Project File Colorizer | `com.unityassist.project-file-colorizer` | 1.1.1 | 種類別色分け、手動カラータグ、色別一覧 |
| Transform Helper | `com.unityassist.transform-tool` | 1.0.2 | Transform一括操作、Undo/Redo再描画、数値検査 |
| Texture Color Replacer | `com.unityassist.texture-color-replacer` | 1.3.0 | OKLab色判定、マスク編集、色変換、PNG保存 |

## 導入方法

1. 作業中のUnityプロジェクトを複製するか、少なくとも `Assets`、`Packages/manifest.json`、`ProjectSettings` をバックアップします。
2. Unityの **Window > Package Manager > In Project** で、`com.unityassist.project-file-colorizer`（Project File Colorizer）だけを削除します。Transform HelperとTexture Color Replacerは今回変更していないため、そのまま残してください。
3. Package Managerの **＋ > Add package from disk...** を選び、`Packages/UnityProjectFileColorizer/package.json` だけを追加します。
4. Unityのコンパイル完了後、`Tools > Unity File Colorizer` とProjectウィンドウの右クリックメニューを確認します。
5. 最初は複製したテスト用プロジェクトで操作してください。

## Project File Colorizer — 手動カラータグ

1. Projectウィンドウでアセットを1つ、または複数選択します。
2. 右クリックして **Unity Assist Tools > カラータグ** を開きます。
3. ターコイズ、ブルー、グリーン、イエロー、オレンジ、レッド、パープル、グレーから選択するか、カスタムカラーを指定します。
4. 右クリックメニューが使いにくい場合は、`Tools > Unity File Colorizer` の設定ウィンドウから **選択中のアセットに色を設定** を使用できます。
5. 色別一覧は **Tools > Unity File Colorizer > Color Groups** または設定ウィンドウの **カラーグループを開く** から開けます。
6. 一覧の **表示** を押すと、対象アセットがProjectウィンドウで選択・強調表示されます。**解除** で個別タグを削除できます。

手動タグは色ごとの疑似グループとして扱います。実ファイルやフォルダは移動しません。手動タグのないアセットは従来の拡張子別色分けを維持し、手動タグを解除すると従来表示に戻ります。

手動タグは `ProjectSettings/UnityAssist.ProjectFileColorizer.ManualTags.json` にアセットGUIDと色の対応として保存されます。アセットの移動・改名後もGUIDが維持されていればタグを引き継ぎます。正常な保存時は直前の設定を `.backup` に保管します。メイン設定が欠落・破損している場合はバックアップからの復旧を試み、読み込みできない場合は設定を上書きしません。

## 不具合が出た場合の戻し方

### A. Release 1.3.0へ戻す

1. Package Managerで `com.unityassist.project-file-colorizer` だけを削除します。Transform HelperとTexture Color Replacerはそのまま残します。
2. `Rollback/UnityAssistTools_Release_1.3.0.zip` を別の場所に展開します。
3. 旧版の `Packages/UnityProjectFileColorizer/package.json` を、Package Managerの **＋ > Add package from disk...** から再登録します。
4. Unityのコンパイル完了後、従来のメニューと色表示を確認します。

### B. 元の初期パッケージへ戻す

`Rollback/unityツール軍_original_2026-11-10.zip` を展開し、各フォルダーの `package.json` を指定して導入します。

### C. さらに前の版を参照する

`Rollback/PreviousChanges/` に旧ソースと旧ZIPを保管しています。個別機能の比較用です。

## 安全性・互換性

- Project File Colorizerの従来9分類、カテゴリ色設定、EditorPrefsキー、ON/OFFを維持します。
- 手動タグは別ファイルで管理し、アセット本体・ファイル名・フォルダ構成・`.meta` を変更しません。
- Projectウィンドウ描画時はメモリ上のGUID辞書を参照し、設定ファイルI/Oや全アセット検索を行いません。
- Transform HelperとTexture Color ReplacerのソースはRelease 1.3.0から変更していません。
- 旧版Release 1.3.0のZIPをそのままRollbackフォルダーに保管しています。
- Unity Editor上の実コンパイル・画面操作は未実施です。詳細は `TEST_REPORT.md` を参照してください。
