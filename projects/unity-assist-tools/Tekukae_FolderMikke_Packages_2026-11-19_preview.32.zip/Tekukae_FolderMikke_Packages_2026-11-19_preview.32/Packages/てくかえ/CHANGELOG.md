## 0.1.0-preview.32
- Fixed the compile error caused by passing an argument to the parameterless UpdateResultPreviewTexture method.

## 0.1.0-preview.30
- スライダー操作中は最大512pxの縮小プレビューだけを更新し、操作停止後にフル解像度を一度だけ再計算
- PNG保存時は必ずフル解像度の調整結果を確定
- 領域グラデーションの複数対象では、操作中・停止後とも表示中の対象だけを更新し、全対象はPNG保存前に確定
- プレビュー用の低解像度画像・マスク・OKLabキャッシュを事前生成し、スライダー操作時の割り当てと処理量を削減

## 0.1.0-preview.29
- Improve live brightness/saturation slider responsiveness by caching source OKLab values and recalculating only recolored pixels.
- Reuse the result preview Texture2D and Color32 upload buffer instead of recreating them on every slider change.
- Keep the normal editor window compact at 760 px; use stacked previews until the user widens the window to 1080 px.
- Reduce preview pane max width to 500 px and preview canvas height to 400 px.

# Changelog

## 0.1.0-preview.29
- Speed up post-conversion brightness/saturation adjustment by caching original OKLab values.
- Reuse the result preview Texture2D and upload buffer while adjusting sliders.
- Keep the normal editor window compact; show side-by-side previews only when the user widens the window.
- Reduce preview panel width and use a compact initial window size.

# Changelog

## 0.1.0-preview.28
- Added common post-conversion brightness and saturation controls for changed pixels only.
- Slider adjustments are recalculated from the unadjusted conversion result and are included in PNG export.
- Region Gradient applies the same global controls to the union of enabled selected regions on each target texture.
- Added EditMode tests for unchanged pixels, alpha preservation, chroma reduction, and non-cumulative adjustment.

# てくかえ 0.1.0-preview.27

- 使用色履歴の色見本をEditorボタンの背景色乗算から独立させ、保存されたRGB値を直接描画するよう修正
- 色選択後の実色と履歴スウォッチの見た目が一致するように変更
- 履歴の保存・上限16件・再選択・消去の動作は変更なし

# てくかえ 0.1.0-preview.26

- 使用色の履歴パネルを拡大し、色見本を19×18pxから34×30pxへ変更
- 履歴全体を枠付きパネルにまとめ、見出し・登録数・消去ボタンを整理
- 履歴の最大16件・保存形式・重複排除・再選択処理は変更なし

# てくかえ 0.1.0-preview.25

- 使用した変換先色の履歴を最大16色保存。単色・2点変換・領域グラデーションで共通利用
- 同じ色は重複登録せず先頭へ移動し、古い色から自動削除
- 履歴色見本から再選択でき、履歴の全消去にも対応
- 履歴はEditorPrefsへ保存し、Unity再起動後も維持
- 色変換アルゴリズム・領域グラデーション処理は変更なし

# てくかえ 0.1.0-preview.24

- 通常ホイールはウィンドウスクロールに変更
- Ctrl（MacはCommand）＋ホイールで画像ズーム
- UIの説明文・ツールチップを短縮
- 変換処理と画像移動処理は変更なし

# てくかえ 0.1.0-preview.22

- 拡大時の画像パン移動制限を撤廃。上下左右へドラッグ量どおりに自由移動できるよう変更
- 画像の一部を表示領域に残すクランプも撤廃し、テクスチャ端・隅の詳細確認を妨げないよう修正
- 画像を表示領域外へ移動した場合は「中央」ボタンで拡大率を維持したまま復帰可能
- フィット表示以下では中央固定を維持し、縮小時に画像が流れない挙動は継続
- 拡大上限64倍・縮小下限50%は維持
- 色変換・領域グラデーションの処理ロジックは変更なし

# てくかえ 0.1.0-preview.21

- 拡大中の通常の左ドラッグで、元画像・変換結果のプレビューを移動できるよう修正
- 短い左クリックは従来どおり色選択として扱い、ドラッグ操作と区別するため4pxの移動しきい値を追加
- 中ドラッグ／Space＋左ドラッグも引き続き利用可能
- 移動時はドラッグ開始位置からの差分でパン量を計算し、横長・縦長画像でも操作を安定化
- 画像を見失わないための表示残量を80pxから24pxへ緩和
- 色変換・領域グラデーションの処理ロジックは変更なし

# てくかえ 0.1.0-preview.20

- 拡大時のパン制限を緩和し、テクスチャの元のフィット範囲ではなくプレビューキャンバス全体を基準に移動可能に変更
- パノラマ・縦長テクスチャでも、空白領域を含むキャンバス内で上下左右に十分移動できるよう修正
- 画像が完全に見えなくならないよう、各方向に一定量の画像を表示してドラッグで復帰可能に変更
- フィット表示以下では従来どおり中央固定し、縮小時に迷子にならない挙動を維持
- 「中央」ボタンを追加し、拡大率を維持したまま画像位置のみをリセット可能に変更
- 拡大上限64倍・縮小下限50%は維持
- 色変換・領域グラデーションの処理ロジックは変更なし

# てくかえ 0.1.0-preview.19

- 元画像・変換結果のプレビュー縮小率の下限を、フィット表示の50%に設定
- 縮小時はプレビューを表示領域の中央に固定し、ドラッグで迷子にならないよう変更
- 拡大時は画像の端がプレビュー表示領域から外れない範囲にパン移動を制限
- 拡大上限は従来どおり64倍を維持し、細部確認の操作性を維持
- マウスホイール・ツールバー・100%表示の各操作に同じ範囲制御を適用
- 色変換・領域グラデーションの処理ロジックは変更なし

# てくかえ 0.1.0-preview.18

- 初回起動時のウィンドウサイズを約800×560pxに縮小し、Unityメインウィンドウ内で中央表示
- 最小サイズを600×420pxへ変更し、ユーザーが自由にリサイズしやすくした
- ウィンドウサイズは初回表示時のみ設定し、以後はUnity Editorのウィンドウレイアウトに任せてユーザーの調整を維持
- 幅が狭い場合は元画像・変換結果のプレビューを横並びから縦並びへ切り替え
- 色変換・領域グラデーションの処理ロジックは変更なし

# てくかえ 0.1.0-preview.17

- パッケージIDを `com.tekukae.texture-color-engine` に変更
- namespace / Assembly Definition名を `Tekukae.TextureColorEngine` 系へ統一
- Editorウィンドウの内部クラス名を `TekukaeWindow` に統一
- 色変換・領域グラデーション処理ロジックは変更なし

# てくかえ 更新履歴

## 0.1.0-preview.16

- Unityメニューとウィンドウ名を「てくかえ」に変更
- メインEditorWindowのC#ソースファイル名を `TekukaeWindow.cs` に変更
- UPMの表示名を「てくかえ」に変更
- 色変換・領域グラデーションの処理ロジックは変更なし
- 既存のUPM Package IDを維持
