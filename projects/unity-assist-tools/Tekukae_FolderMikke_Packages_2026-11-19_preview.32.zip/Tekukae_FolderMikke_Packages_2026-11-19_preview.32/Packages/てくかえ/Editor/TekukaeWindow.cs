using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using Tekukae.TextureColorEngine;
using Tekukae.TextureColorEngine.Editor.RegionGradient;

namespace Tekukae.TextureColorEngine.Editor
{
    /// <summary>
    /// Small verification UI for the independent engine. This is not the final 1.4.1 UI.
    /// It intentionally exposes only source selection, 1/2-point picking, target colors, preview and export.
    /// </summary>
    internal sealed class TekukaeWindow : EditorWindow
    {
        private Texture2D sourceAsset;
        private LoadedTextureSource loadedSource;
        private Texture2D sourcePreview;
        private Texture2D resultPreview;
        private Color32[] resultPreviewColorBuffer;
        private Texture2D resultInteractivePreview;
        private Color32[] resultInteractivePreviewColorBuffer;
        private bool adjustmentPreviewNeedsFinalize;
        private RecolorResult lastResult;
        private bool adjustmentFinalizePending;
        private bool adjustmentFinalizeSubscribed;
        private bool adjustmentSliderDragging;
        private bool hasFinalizedAdjustment;
        private float finalizedOutputBrightness;
        private float finalizedOutputSaturation = 100f;
        private double adjustmentFinalizeAt;
        private const double AdjustmentFinalizeDelaySeconds = 0.22;
        private float outputBrightness = 0f;
        private float outputSaturation = 100f;
        private RecolorMode mode = RecolorMode.SingleColor;
        // Target colors are selected visually with Unity's native Color Picker.
        // The engine input remains unchanged: selected LDR colors are converted to sRGB RGBA8.
        private Color targetColor = new Color32(64, 115, 184, 255);
        private Color targetStartColor = new Color32(64, 115, 184, 255);
        private Color targetEndColor = new Color32(115, 174, 221, 255);
        private int firstX = -1;
        private int firstY = -1;
        private int secondX = -1;
        private int secondY = -1;
        private int activePoint;
        private string outputName = "";
        private string statusMessage;
        private Vector2 scrollPosition;

        // Preview navigation is presentation-only and independent for each canvas.
        // It never changes source pixels or engine inputs.
        private float sourcePreviewZoom = 1f;
        private Vector2 sourcePreviewPanOffset;
        private float sourcePreviewFitScale = 1f;
        private float resultPreviewZoom = 1f;
        private Vector2 resultPreviewPanOffset;
        private float resultPreviewFitScale = 1f;
        private bool spaceHeld;
        private bool isPanning;
        private int activePanPane;
        private int previewPanControlId;
        private bool previewPanMoved;
        private bool previewPendingLeftClick;
        private Vector2 previewPanStartPosition;
        private Vector2 previewPanStartOffset;
        private const float PreviewPanDragThreshold = 4f;
        private int activeFeatureTab;
        private RegionGradientPanel regionGradientPanel;

        private const string InitialWindowSizePreferenceKey = "Tekukae.TextureColorEngine.InitialWindowSizeApplied.v2";
        private const float InitialWindowWidth = 760f;
        private const float InitialWindowHeight = 620f;
        private const float MinimumWindowWidth = 560f;
        private const float MinimumWindowHeight = 420f;
        // Keep the normal window compact. Side-by-side previews are enabled only after
        // the user deliberately widens the window beyond this threshold.
        private const float SideBySidePreviewWidth = 1080f;

        // Keep zoomed-out previews at a useful size. When zoomed in, panning is intentionally
        // unrestricted so users can inspect any texture area without hitting an artificial edge.
        // The toolbar's "中央" action is the explicit recovery path if the image is moved off-screen.
        private const float MinimumPreviewZoom = 0.5f;
        private const float MaximumPreviewZoom = 64f;

        [MenuItem("Tools/てくかえ")]
        private static void Open()
        {
            TekukaeWindow window = GetWindow<TekukaeWindow>();
            window.titleContent = new GUIContent("てくかえ");
            window.minSize = new Vector2(MinimumWindowWidth, MinimumWindowHeight);

            // Set a compact, centered size only on the first explicit open.
            // Unity then keeps the user's resized position and dimensions in its window layout.
            if (!EditorPrefs.GetBool(InitialWindowSizePreferenceKey, false))
            {
                Rect mainWindow = EditorGUIUtility.GetMainWindowPosition();
                if (mainWindow.width <= 0f || mainWindow.height <= 0f)
                    mainWindow = new Rect(100f, 100f, 1200f, 800f);

                float width = Mathf.Clamp(mainWindow.width - 80f, MinimumWindowWidth, InitialWindowWidth);
                float height = Mathf.Clamp(mainWindow.height - 100f, MinimumWindowHeight, InitialWindowHeight);
                float x = mainWindow.x + (mainWindow.width - width) * 0.5f;
                float y = mainWindow.y + (mainWindow.height - height) * 0.5f;
                window.position = new Rect(x, y, width, height);
                EditorPrefs.SetBool(InitialWindowSizePreferenceKey, true);
            }

            window.Show();
            window.Focus();
        }

        private void OnEnable()
        {
            // Keep the window freely resizable; narrow layouts switch the previews to a vertical stack.
            minSize = new Vector2(MinimumWindowWidth, MinimumWindowHeight);
        }

        private void OnDisable()
        {
            CancelPendingAdjustmentFinalize();
            DestroyPreviewTextures();
            if (regionGradientPanel != null)
            {
                regionGradientPanel.Dispose();
                regionGradientPanel = null;
            }
            loadedSource = null;
            lastResult = null;
            spaceHeld = false;
            isPanning = false;
            previewPendingLeftClick = false;
            previewPanMoved = false;
            GUIUtility.hotControl = 0;
        }

        private void OnLostFocus()
        {
            spaceHeld = false;
            isPanning = false;
            previewPendingLeftClick = false;
            previewPanMoved = false;
            if (GUIUtility.hotControl == previewPanControlId)
                GUIUtility.hotControl = 0;

            // If the editor loses focus while a slider is held, release the deferred
            // full-resolution commit instead of leaving it pending indefinitely.
            adjustmentSliderDragging = false;
            if (adjustmentFinalizePending)
                adjustmentFinalizeAt = EditorApplication.timeSinceStartup + 0.08;
            if (regionGradientPanel != null)
                regionGradientPanel.OnOwnerLostFocus();
        }

        private void OnGUI()
        {
            activeFeatureTab = GUILayout.Toolbar(activeFeatureTab, new[] { "色変換", "領域グラデーション" });
            if (activeFeatureTab == 1)
            {
                if (regionGradientPanel == null) regionGradientPanel = new RegionGradientPanel();
                regionGradientPanel.Draw(this);
                return;
            }

            if (previewPanControlId == 0)
                previewPanControlId = GUIUtility.GetControlID(FocusType.Passive);
            HandlePreviewNavigationEvents();

            scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);
            EditorGUILayout.HelpBox(
                "クリック：色選択　拡大中の左ドラッグ：移動　Ctrl（MacはCommand）＋ホイール：ズーム",
                MessageType.Info);

            EditorGUI.BeginChangeCheck();
            Texture2D newAsset = (Texture2D)EditorGUILayout.ObjectField(
                new GUIContent("元テクスチャ", "変換するテクスチャ。"),
                sourceAsset, typeof(Texture2D), false);
            if (EditorGUI.EndChangeCheck() && newAsset != sourceAsset)
            {
                sourceAsset = newAsset;
                ClearLoadedSource();
            }

            using (new EditorGUI.DisabledScope(sourceAsset == null))
            {
                if (GUILayout.Button("元画像を読み込む")) LoadSource();
            }

            if (loadedSource == null || sourcePreview == null)
            {
                EditorGUILayout.HelpBox("テクスチャを指定して「元画像を読み込む」を押してください。", MessageType.Warning);
                EditorGUILayout.EndScrollView();
                return;
            }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("画像情報", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("サイズ", loadedSource.Pixels.Width + " × " + loadedSource.Pixels.Height);
            if (!string.IsNullOrEmpty(loadedSource.Warning))
                EditorGUILayout.HelpBox(loadedSource.Warning, MessageType.Warning);
            if (loadedSource.Pixels.Pixels.Length > 4194304)
                EditorGUILayout.HelpBox("高解像度画像：プレビューに時間がかかる場合があります。", MessageType.Warning);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("変換設定", EditorStyles.boldLabel);
            int nextModeIndex = EditorGUILayout.Popup("変換方式", (int)mode, new[] { "単色変換", "2点の色の流れ" });
            RecolorMode nextMode = (RecolorMode)nextModeIndex;
            if (nextMode != mode)
            {
                mode = nextMode;
                lastResult = null;
                DestroyResultPreview();
                activePoint = 0;
            }

            EditorGUI.BeginChangeCheck();
            if (mode == RecolorMode.SingleColor)
            {
                targetColor = DrawTargetColorField("変換先の色", targetColor);
                DrawSampleLabel("変換元", firstX, firstY);
                EditorGUILayout.HelpBox("元画像をクリックして変換元の色を選択。", MessageType.None);
            }
            else
            {
                EditorGUILayout.HelpBox(
                    "元画像を始点、終点の順にクリック。",
                    MessageType.None);
                using (new EditorGUILayout.HorizontalScope())
                {
                    DrawTwoPointAnchorCard("01  始点", firstX, firstY, ref targetStartColor, 0);
                    DrawTwoPointAnchorCard("02  終点", secondX, secondY, ref targetEndColor, 1);
                }
                using (new EditorGUILayout.HorizontalScope())
                {
                    GUILayout.FlexibleSpace();
                    if (GUILayout.Button("2点の選択をクリア", GUILayout.Width(140f)))
                    {
                        firstX = firstY = secondX = secondY = -1;
                        activePoint = 0;
                        lastResult = null;
                        DestroyResultPreview();
                        statusMessage = "始点と終点の選択をクリアしました。";
                    }
                }
            }

            if (EditorGUI.EndChangeCheck())
            {
                lastResult = null;
                DestroyResultPreview();
            }

            EditorGUILayout.Space(8f);
            if (position.width >= SideBySidePreviewWidth)
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    GUILayout.FlexibleSpace();
                    using (new EditorGUILayout.HorizontalScope(GUILayout.MaxWidth(1200f)))
                    {
                        DrawSourcePreview();
                        GUILayout.Space(12f);
                        DrawResultPreview();
                    }
                    GUILayout.FlexibleSpace();
                }
            }
            else
            {
                // Keep the UI usable when the user narrows the floating EditorWindow.
                using (new EditorGUILayout.VerticalScope(GUILayout.ExpandWidth(true)))
                {
                    DrawSourcePreview();
                    GUILayout.Space(12f);
                    DrawResultPreview();
                }
            }

            bool hasSamples = firstX >= 0 && firstY >= 0 &&
                              (mode == RecolorMode.SingleColor || (secondX >= 0 && secondY >= 0));
            using (new EditorGUI.DisabledScope(!hasSamples))
            {
                if (GUILayout.Button("変換プレビューを作成")) BuildPreview();
            }

            if (lastResult != null)
            {
                DrawOutputColorAdjustments();
                EditorGUILayout.LabelField(
                    "対象ピクセル: " + lastResult.MatchedPixels.ToString("N0") +
                    " / 一部適用: " + lastResult.PartiallyMatchedPixels.ToString("N0") +
                    " / 不透明画素: " + lastResult.OpaquePixels.ToString("N0"),
                    EditorStyles.miniLabel);
                outputName = EditorGUILayout.TextField("保存名", string.IsNullOrEmpty(outputName) ? sourceAsset.name + "_Recolored" : outputName);
                if (GUILayout.Button("PNGとして別名保存")) SaveResult();
            }

            if (!string.IsNullOrEmpty(statusMessage))
                EditorGUILayout.HelpBox(statusMessage, MessageType.Info);

            EditorGUILayout.EndScrollView();
        }

        private void DrawSourcePreview()
        {
            using (new EditorGUILayout.VerticalScope(GUILayout.MinWidth(300f), GUILayout.MaxWidth(500f), GUILayout.ExpandWidth(true)))
            {
                EditorGUILayout.LabelField("元画像（クリックして色を選択）", EditorStyles.centeredGreyMiniLabel);
                DrawPreviewNavigationToolbar(ref sourcePreviewZoom, ref sourcePreviewPanOffset, sourcePreviewFitScale);
                Rect container = GUILayoutUtility.GetRect(300f, 400f, GUILayout.ExpandWidth(true));
                DrawPreviewCanvas(container, sourcePreview, true,
                    ref sourcePreviewZoom, ref sourcePreviewPanOffset, ref sourcePreviewFitScale, 0);
            }
        }

        private void DrawResultPreview()
        {
            using (new EditorGUILayout.VerticalScope(GUILayout.MinWidth(300f), GUILayout.MaxWidth(500f), GUILayout.ExpandWidth(true)))
            {
                EditorGUILayout.LabelField("変換結果", EditorStyles.centeredGreyMiniLabel);
                Texture2D displayTexture = adjustmentPreviewNeedsFinalize && resultInteractivePreview != null
                    ? resultInteractivePreview
                    : resultPreview;
                if (displayTexture == null)
                {
                    using (new EditorGUI.DisabledScope(true))
                        DrawPreviewNavigationToolbar(ref resultPreviewZoom, ref resultPreviewPanOffset, resultPreviewFitScale);
                    Rect emptyContainer = GUILayoutUtility.GetRect(300f, 400f, GUILayout.ExpandWidth(true));
                    GUI.Box(emptyContainer, GUIContent.none);
                    GUI.Label(emptyContainer, "プレビューなし", EditorStyles.centeredGreyMiniLabel);
                    return;
                }
                DrawPreviewNavigationToolbar(ref resultPreviewZoom, ref resultPreviewPanOffset, resultPreviewFitScale);
                Rect container = GUILayoutUtility.GetRect(300f, 400f, GUILayout.ExpandWidth(true));
                DrawPreviewCanvas(container, displayTexture, false,
                    ref resultPreviewZoom, ref resultPreviewPanOffset, ref resultPreviewFitScale, 1);
            }
        }

        private void DrawPreviewNavigationToolbar(ref float zoom, ref Vector2 panOffset, float fitScale)
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                GUILayout.Label(GetZoomPercentageText(zoom, fitScale), EditorStyles.miniLabel, GUILayout.Width(48f));
                if (GUILayout.Button("-", EditorStyles.toolbarButton, GUILayout.Width(24f)))
                {
                    zoom = Mathf.Clamp(zoom / 1.25f, MinimumPreviewZoom, MaximumPreviewZoom);
                    Repaint();
                }
                if (GUILayout.Button("+", EditorStyles.toolbarButton, GUILayout.Width(24f)))
                {
                    zoom = Mathf.Clamp(zoom * 1.25f, MinimumPreviewZoom, MaximumPreviewZoom);
                    Repaint();
                }
                if (GUILayout.Button("全体", EditorStyles.toolbarButton, GUILayout.Width(42f)))
                {
                    zoom = 1f;
                    panOffset = Vector2.zero;
                    Repaint();
                }
                if (GUILayout.Button("100%", EditorStyles.toolbarButton, GUILayout.Width(48f)))
                {
                    zoom = Mathf.Clamp(1f / Mathf.Max(0.0001f, fitScale), MinimumPreviewZoom, MaximumPreviewZoom);
                    panOffset = Vector2.zero;
                    Repaint();
                }
                if (GUILayout.Button(new GUIContent("中央", "表示位置を中央へ戻す。"),
                    EditorStyles.toolbarButton, GUILayout.Width(42f)))
                {
                    // Recenter without changing magnification, so users can recover the image
                    // after freely moving it around the preview canvas.
                    panOffset = Vector2.zero;
                    Repaint();
                }
                GUILayout.FlexibleSpace();
            }
        }

        private static string GetZoomPercentageText(float zoom, float fitScale)
        {
            float percentage = zoom * fitScale * 100f;
            return Mathf.RoundToInt(percentage).ToString() + "%";
        }

        private void HandlePreviewNavigationEvents()
        {
            Event current = Event.current;
            if (current.type == EventType.KeyDown && current.keyCode == KeyCode.Space)
            {
                spaceHeld = true;
                return;
            }
            if (current.type == EventType.KeyUp && current.keyCode == KeyCode.Space)
            {
                spaceHeld = false;
                return;
            }
        }

        private void DrawPreviewCanvas(
            Rect container,
            Texture2D texture,
            bool allowPicking,
            ref float zoom,
            ref Vector2 panOffset,
            ref float fitScale,
            int paneId)
        {
            GUI.BeginGroup(container);
            Rect bounds = new Rect(0f, 0f, container.width, container.height);
            GUI.Box(bounds, GUIContent.none);

            Rect fitRect = GetAspectRect(bounds, texture.width, texture.height);
            fitScale = fitRect.width / texture.width;
            zoom = Mathf.Clamp(zoom, MinimumPreviewZoom, MaximumPreviewZoom);
            panOffset = ClampPreviewPanOffset(bounds, fitRect, zoom, panOffset);
            Rect imageRect = GetPreviewImageRect(fitRect, zoom, panOffset);

            Event current = Event.current;
            if (current.type == EventType.ScrollWheel && bounds.Contains(current.mousePosition) &&
                (current.control || current.command))
            {
                float nextZoom = Mathf.Clamp(zoom * Mathf.Pow(1.15f, -current.delta.y), MinimumPreviewZoom, MaximumPreviewZoom);
                if (!Mathf.Approximately(nextZoom, zoom))
                {
                    Vector2 mouse = current.mousePosition;
                    float ratio = nextZoom / zoom;
                    Vector2 nextPosition = mouse - (mouse - imageRect.position) * ratio;
                    panOffset = nextPosition - fitRect.position;
                    zoom = nextZoom;
                    panOffset = ClampPreviewPanOffset(bounds, fitRect, zoom, panOffset);
                }
                current.Use();
                Repaint();
                imageRect = GetPreviewImageRect(fitRect, zoom, panOffset);
            }

            // At fit size a normal left click selects a source pixel. Once zoomed in,
            // left-drag pans the image; a short click still selects the pixel on MouseUp.
            // Middle-drag and Space+left-drag remain available at every zoom level.
            if (current.type == EventType.MouseDown && bounds.Contains(current.mousePosition))
            {
                bool middleDrag = current.button == 2;
                bool spaceDrag = current.button == 0 && spaceHeld;
                bool zoomedLeftGesture = current.button == 0 && !spaceHeld && zoom > 1.0001f;

                if (middleDrag || spaceDrag || zoomedLeftGesture)
                {
                    isPanning = true;
                    activePanPane = paneId;
                    previewPanMoved = middleDrag || spaceDrag;
                    previewPendingLeftClick = zoomedLeftGesture && allowPicking;
                    previewPanStartPosition = current.mousePosition;
                    previewPanStartOffset = panOffset;
                    GUIUtility.hotControl = previewPanControlId;
                    current.Use();
                }
                else if (allowPicking && current.button == 0 && !spaceHeld && imageRect.Contains(current.mousePosition))
                {
                    SelectSourcePixel(imageRect, current.mousePosition);
                    current.Use();
                    Repaint();
                }
            }

            if (current.type == EventType.MouseDrag && isPanning &&
                GUIUtility.hotControl == previewPanControlId && activePanPane == paneId)
            {
                if (!previewPanMoved &&
                    (current.mousePosition - previewPanStartPosition).sqrMagnitude >= PreviewPanDragThreshold * PreviewPanDragThreshold)
                {
                    previewPanMoved = true;
                }

                if (previewPanMoved)
                {
                    panOffset = previewPanStartOffset + (current.mousePosition - previewPanStartPosition);
                    panOffset = ClampPreviewPanOffset(bounds, fitRect, zoom, panOffset);
                    imageRect = GetPreviewImageRect(fitRect, zoom, panOffset);
                }

                current.Use();
                Repaint();
            }

            if (current.type == EventType.MouseUp && isPanning &&
                GUIUtility.hotControl == previewPanControlId && activePanPane == paneId)
            {
                bool shouldPick = previewPendingLeftClick && !previewPanMoved && allowPicking;
                Vector2 releasePosition = current.mousePosition;

                isPanning = false;
                previewPendingLeftClick = false;
                previewPanMoved = false;
                GUIUtility.hotControl = 0;
                current.Use();

                if (shouldPick && imageRect.Contains(releasePosition))
                    SelectSourcePixel(imageRect, releasePosition);

                Repaint();
            }

            GUI.DrawTexture(imageRect, texture, ScaleMode.StretchToFill, true);
            DrawMarker(imageRect, firstX, firstY, loadedSource.Pixels.Width, loadedSource.Pixels.Height,
                new Color(1f, 0.25f, 0.2f, 1f));
            if (mode == RecolorMode.TwoPointFlow)
                DrawMarker(imageRect, secondX, secondY, loadedSource.Pixels.Width, loadedSource.Pixels.Height,
                    new Color(0.2f, 0.85f, 1f, 1f));

            GUI.EndGroup();
        }

        private void SelectSourcePixel(Rect imageRect, Vector2 mousePosition)
        {
            if (loadedSource == null || loadedSource.Pixels == null ||
                loadedSource.Pixels.Width <= 0 || loadedSource.Pixels.Height <= 0 ||
                imageRect.width <= 0f || imageRect.height <= 0f)
                return;

            int x = Mathf.Clamp(
                Mathf.FloorToInt((mousePosition.x - imageRect.x) / imageRect.width * loadedSource.Pixels.Width),
                0, loadedSource.Pixels.Width - 1);
            int y = Mathf.Clamp(
                Mathf.FloorToInt((imageRect.yMax - mousePosition.y) / imageRect.height * loadedSource.Pixels.Height),
                0, loadedSource.Pixels.Height - 1);

            if (mode == RecolorMode.SingleColor || activePoint == 0)
            {
                firstX = x;
                firstY = y;
                if (mode == RecolorMode.TwoPointFlow)
                {
                    activePoint = 1;
                    statusMessage = "始点を選択しました。続けて終点を選択してください。";
                }
                else
                {
                    statusMessage = "変換元の色を選択しました。";
                }
            }
            else
            {
                secondX = x;
                secondY = y;
                statusMessage = "終点を選択しました。";
            }

            lastResult = null;
            DestroyResultPreview();
        }

        private static Vector2 ClampPreviewPanOffset(Rect bounds, Rect fitRect, float zoom, Vector2 panOffset)
        {
            // At fit size or below, keep the image centered so it cannot drift away while
            // navigating the whole texture.
            if (zoom <= 1f)
            {
                return new Vector2(
                    (fitRect.width - fitRect.width * zoom) * 0.5f,
                    (fitRect.height - fitRect.height * zoom) * 0.5f);
            }

            // IMPORTANT: Do not clamp panning while zoomed in.
            // Previous versions restricted the image to a narrow range around the preview canvas,
            // which prevented users from reaching edge/corner details on large textures.
            // Preserve the exact drag delta (1 screen point = 1 GUI point) and allow the image
            // to move freely in every direction. If it is moved off-screen, the "中央" toolbar
            // button resets panOffset to zero without changing zoom.
            return panOffset;
        }

        private static Rect GetPreviewImageRect(Rect fitRect, float zoom, Vector2 panOffset)
        {
            return new Rect(
                fitRect.x + panOffset.x,
                fitRect.y + panOffset.y,
                fitRect.width * zoom,
                fitRect.height * zoom);
        }

        private void DrawTwoPointAnchorCard(string title, int x, int y, ref Color targetColor, int pointIndex)
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox, GUILayout.MinWidth(0f)))
            {
                EditorGUILayout.LabelField(title, EditorStyles.boldLabel);
                DrawSampleLabel("変換元", x, y);
                targetColor = DrawTargetColorField("変換先", targetColor);
                bool isActive = activePoint == pointIndex;
                string buttonLabel = isActive ? "画像上で選択中" : "この点を選択";
                if (GUILayout.Button(buttonLabel, GUILayout.Height(22f)))
                    activePoint = pointIndex;
            }
        }

        private void LoadSource()
        {
            try
            {
                ClearLoadedSource();
                loadedSource = TextureSourceReader.Load(sourceAsset);
                sourcePreview = CreateViewTexture(loadedSource.Pixels);
                sourcePreviewZoom = resultPreviewZoom = 1f;
                sourcePreviewPanOffset = resultPreviewPanOffset = Vector2.zero;
                outputName = sourceAsset.name + "_Recolored";
                statusMessage = "元画像を読み込みました。";
            }
            catch (Exception exception)
            {
                ClearLoadedSource();
                statusMessage = "読み込みに失敗しました: " + exception.Message;
                Debug.LogException(exception);
            }
        }

        private void DrawOutputColorAdjustments()
        {
            EditorGUILayout.Space(6f);
            EditorGUILayout.LabelField("変換後の色調整", EditorStyles.boldLabel);
            EditorGUI.BeginChangeCheck();
            outputBrightness = EditorGUILayout.Slider("明るさ", outputBrightness, -100f, 100f);
            outputSaturation = EditorGUILayout.Slider("彩度", outputSaturation, 0f, 200f);
            bool changed = EditorGUI.EndChangeCheck();
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.FlexibleSpace();
                if (GUILayout.Button("調整をリセット", GUILayout.Width(110f)))
                {
                    outputBrightness = 0f;
                    outputSaturation = 100f;
                    changed = true;
                }
            }
            if (changed && lastResult != null)
                ScheduleInteractiveAdjustmentPreview(
                    GUIUtility.hotControl != 0 && Event.current.rawType != EventType.MouseUp);

            // A held slider can pause longer than the debounce interval. Do not perform
            // expensive full-resolution work during that pause; commit once on release.
            if (adjustmentFinalizePending && Event.current.rawType == EventType.MouseUp)
            {
                adjustmentSliderDragging = false;
                FinalizeColorAdjustmentNow();
            }
        }

        private void BuildPreview()
        {
            try
            {
                CancelPendingAdjustmentFinalize();
                hasFinalizedAdjustment = false;
                if (mode == RecolorMode.SingleColor)
                {
                    lastResult = TextureColorEngine.RecolorSingle(
                        loadedSource.Pixels, firstX, firstY, ToSrgbRgba(targetColor));
                    RecentColorHistory.Record(targetColor);
                }
                else
                {
                    lastResult = TextureColorEngine.RecolorTwoPoint(
                        loadedSource.Pixels, firstX, firstY, secondX, secondY,
                        ToSrgbRgba(targetStartColor), ToSrgbRgba(targetEndColor));
                    RecentColorHistory.Record(targetStartColor);
                    RecentColorHistory.Record(targetEndColor);
                }

                lastResult.UpdateColorAdjustments(outputBrightness, outputSaturation);
                MarkAdjustmentFinalized();
                UpdateResultPreviewTexture();
                statusMessage = "プレビューを作成しました。調整結果はPNG出力にも反映されます。";
            }
            catch (Exception exception)
            {
                lastResult = null;
                DestroyResultPreview();
                statusMessage = "変換に失敗しました: " + exception.Message;
                Debug.LogException(exception);
            }
        }

        private void SaveResult()
        {
            try
            {
                FinalizeColorAdjustmentNow();
                string folder = string.IsNullOrEmpty(loadedSource.AssetPath)
                    ? "Assets"
                    : Path.GetDirectoryName(loadedSource.AssetPath).Replace('\\', '/');
                // Package assets and generated textures may not live under Assets/. Export user output
                // into Assets instead of attempting to write into a read-only Packages directory.
                if (!(folder == "Assets" || folder.StartsWith("Assets/", StringComparison.Ordinal)))
                    folder = "Assets";
                string savedPath = TextureSourceReader.ExportPng(loadedSource, lastResult.Image, folder, outputName);
                UnityEngine.Object saved = AssetDatabase.LoadAssetAtPath<Texture2D>(savedPath);
                if (saved != null) EditorGUIUtility.PingObject(saved);
                statusMessage = "PNG画像を保存しました: " + savedPath;
            }
            catch (Exception exception)
            {
                statusMessage = "保存に失敗しました: " + exception.Message;
                Debug.LogException(exception);
            }
        }

        private void DrawSampleLabel(string label, int x, int y)
        {
            if (x < 0 || y < 0)
            {
                EditorGUILayout.LabelField(label, "未選択", EditorStyles.miniLabel);
                return;
            }
            Rgba32 pixel = loadedSource.Pixels.Pixels[y * loadedSource.Pixels.Width + x];
            EditorGUILayout.LabelField(label,
                "(" + x + ", " + y + ")  RGBA(" + pixel.R + ", " + pixel.G + ", " + pixel.B + ", " + pixel.A + ")",
                EditorStyles.miniLabel);
        }

        private static void DrawMarker(Rect imageRect, int x, int y, int textureWidth, int textureHeight, Color color)
        {
            if (x < 0 || y < 0 || textureWidth <= 0 || textureHeight <= 0) return;
            float px = imageRect.x + (x + 0.5f) / textureWidth * imageRect.width;
            float py = imageRect.yMax - (y + 0.5f) / textureHeight * imageRect.height;
            EditorGUI.DrawRect(new Rect(px - 5f, py - 0.75f, 10f, 1.5f), color);
            EditorGUI.DrawRect(new Rect(px - 0.75f, py - 5f, 1.5f, 10f), color);
        }

        private static Rect GetAspectRect(Rect container, int width, int height)
        {
            float aspect = (float)width / height;
            float containerAspect = container.width / container.height;
            if (aspect > containerAspect)
            {
                float drawnHeight = container.width / aspect;
                return new Rect(container.x, container.y + (container.height - drawnHeight) * 0.5f, container.width, drawnHeight);
            }
            float drawnWidth = container.height * aspect;
            return new Rect(container.x + (container.width - drawnWidth) * 0.5f, container.y, drawnWidth, container.height);
        }

        private static Color DrawTargetColorField(string label, Color value)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.PrefixLabel(new GUIContent(label, "変換先の色を設定。"));
                // Unity's native Color Picker provides visual hue / saturation / value selection.
                // Alpha and HDR are disabled because the recolor engine accepts ordinary LDR colors
                // and preserves the source pixel alpha channel.
                value = EditorGUILayout.ColorField(GUIContent.none, value, false, false, false, GUILayout.MinWidth(88f));
            }
            RecentColorHistory.Draw(ref value);
            return value;
        }

        private static Rgba32 ToSrgbRgba(Color color)
        {
            // ColorField returns the selected LDR color through Unity's standard Color API.
            // The engine contract remains sRGB RGBA8; the original texture alpha is preserved
            // later by the engine, so the selected target alpha is deliberately opaque.
            Color32 bytes = color;
            return new Rgba32(bytes.r, bytes.g, bytes.b, 255);
        }

        private void UpdateResultPreviewTexture()
        {
            if (lastResult != null)
                UpdatePreviewTexture(ref resultPreview, ref resultPreviewColorBuffer,
                    lastResult.Image, "てくかえ_変換プレビュー");
        }

        private void UpdateInteractiveResultPreviewTexture(TexturePixels pixels)
        {
            UpdatePreviewTexture(ref resultInteractivePreview, ref resultInteractivePreviewColorBuffer,
                pixels, "てくかえ_操作中プレビュー");
        }

        private static void UpdatePreviewTexture(ref Texture2D texture, ref Color32[] colorBuffer,
            TexturePixels pixels, string textureName)
        {
            if (pixels == null) return;
            if (texture == null || texture.width != pixels.Width || texture.height != pixels.Height)
            {
                DestroyTexture(ref texture);
                texture = new Texture2D(pixels.Width, pixels.Height, TextureFormat.RGBA32, false, false);
                texture.name = textureName;
                colorBuffer = new Color32[pixels.Pixels.Length];
            }
            else if (colorBuffer == null || colorBuffer.Length != pixels.Pixels.Length)
            {
                colorBuffer = new Color32[pixels.Pixels.Length];
            }

            Rgba32[] source = pixels.Pixels;
            for (int i = 0; i < source.Length; i++)
            {
                Rgba32 p = source[i];
                colorBuffer[i] = new Color32(p.R, p.G, p.B, p.A);
            }

            texture.SetPixels32(colorBuffer);
            texture.Apply(false, false);
        }

        private void ScheduleInteractiveAdjustmentPreview(bool sliderDragging)
        {
            if (lastResult == null) return;

            lastResult.UpdatePreviewColorAdjustments(outputBrightness, outputSaturation);
            UpdateInteractiveResultPreviewTexture(lastResult.PreviewImage);
            adjustmentPreviewNeedsFinalize = true;
            adjustmentSliderDragging = sliderDragging;
            adjustmentFinalizePending = true;
            adjustmentFinalizeAt = EditorApplication.timeSinceStartup + AdjustmentFinalizeDelaySeconds;
            if (!adjustmentFinalizeSubscribed)
            {
                EditorApplication.update += UpdateAdjustmentFinalize;
                adjustmentFinalizeSubscribed = true;
            }
            Repaint();
        }

        private void UpdateAdjustmentFinalize()
        {
            if (!adjustmentFinalizePending || lastResult == null)
            {
                CancelPendingAdjustmentFinalize();
                return;
            }
            // GUIUtility.hotControl remains set while the user is dragging the slider.
            // The idle timer may elapse during a slow drag, but must never trigger a
            // full-resolution rebuild until the control is released.
            if (adjustmentSliderDragging || GUIUtility.hotControl != 0) return;
            if (EditorApplication.timeSinceStartup < adjustmentFinalizeAt) return;
            FinalizeColorAdjustmentNow();
        }

        private bool IsCurrentAdjustmentFinalized()
        {
            if (!hasFinalizedAdjustment || adjustmentPreviewNeedsFinalize || lastResult == null || resultPreview == null) return false;
            return Mathf.Approximately(finalizedOutputBrightness, outputBrightness) &&
                   Mathf.Approximately(finalizedOutputSaturation, outputSaturation);
        }

        private void MarkAdjustmentFinalized()
        {
            hasFinalizedAdjustment = true;
            adjustmentPreviewNeedsFinalize = false;
            finalizedOutputBrightness = outputBrightness;
            finalizedOutputSaturation = outputSaturation;
        }

        private void FinalizeColorAdjustmentNow()
        {
            CancelPendingAdjustmentFinalize();
            if (lastResult == null || IsCurrentAdjustmentFinalized()) return;
            lastResult.UpdateColorAdjustments(outputBrightness, outputSaturation);
            UpdateResultPreviewTexture();
            MarkAdjustmentFinalized();
            Repaint();
        }

        private void CancelPendingAdjustmentFinalize()
        {
            adjustmentFinalizePending = false;
            if (adjustmentFinalizeSubscribed)
            {
                EditorApplication.update -= UpdateAdjustmentFinalize;
                adjustmentFinalizeSubscribed = false;
            }
            adjustmentSliderDragging = false;
        }

        private static Texture2D CreateViewTexture(TexturePixels pixels)
        {
            Texture2D texture = new Texture2D(pixels.Width, pixels.Height, TextureFormat.RGBA32, false, false);
            Color32[] colors = new Color32[pixels.Pixels.Length];
            for (int i = 0; i < colors.Length; i++)
            {
                Rgba32 p = pixels.Pixels[i];
                colors[i] = new Color32(p.R, p.G, p.B, p.A);
            }
            texture.SetPixels32(colors);
            texture.Apply(false, false);
            return texture;
        }

        private void ClearLoadedSource()
        {
            DestroyPreviewTextures();
            loadedSource = null;
            lastResult = null;
            firstX = firstY = secondX = secondY = -1;
            sourcePreviewZoom = resultPreviewZoom = 1f;
            sourcePreviewPanOffset = resultPreviewPanOffset = Vector2.zero;
            statusMessage = null;
        }

        private void DestroyPreviewTextures()
        {
            DestroyTexture(ref sourcePreview);
            DestroyResultPreview();
        }

        private void DestroyResultPreview()
        {
            CancelPendingAdjustmentFinalize();
            hasFinalizedAdjustment = false;
            DestroyTexture(ref resultPreview);
            DestroyTexture(ref resultInteractivePreview);
            resultPreviewColorBuffer = null;
            resultInteractivePreviewColorBuffer = null;
            adjustmentPreviewNeedsFinalize = false;
        }

        private static void DestroyTexture(ref Texture2D texture)
        {
            if (texture == null) return;
            UnityEngine.Object.DestroyImmediate(texture);
            texture = null;
        }
    }
}
