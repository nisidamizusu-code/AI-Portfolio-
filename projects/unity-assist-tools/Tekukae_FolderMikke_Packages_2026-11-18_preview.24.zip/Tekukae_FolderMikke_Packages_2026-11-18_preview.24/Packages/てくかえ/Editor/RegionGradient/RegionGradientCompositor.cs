using UnityEngine;

namespace Tekukae.TextureColorEngine.Editor.RegionGradient
{
    /// <summary>Applies the new gradient using separately extracted original texture characteristics.</summary>
    internal static class RegionGradientCompositor
    {
        public static RegionGradientResult Compose(Color32[] source, Color32[] basePixels, int width, int height, byte[] selection,
            byte[] softMask, Vector2[] normalizedCoordinates, OriginalTextureProfile profile, RegionGradientSettings settings)
        {
            Color32[] output = (Color32[])basePixels.Clone();
            int selectedPixels = 0;
            int partiallySelectedPixels = 0;
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    int index = y * width + x;
                    float mask = softMask[index] / 255f;
                    if (mask <= 0.001f || source[index].a < 16) continue;
                    if (selection[index] > 0) selectedPixels++;
                    if (softMask[index] > 0 && softMask[index] < 255) partiallySelectedPixels++;

                    Vector2 coordinate = normalizedCoordinates != null
                        ? normalizedCoordinates[index]
                        : new Vector2((x + 0.5f) / width, (y + 0.5f) / height);
                    OklchColor gradientColor = EvaluateGradient(settings, EvaluatePosition(coordinate, settings));
                    OklabColor originalLab = RegionGradientColorMath.ToOklab(source[index]);
                    OklchColor original = RegionGradientColorMath.ToOklch(originalLab);
                    OklabColor baseLab = OriginalTextureProfileAnalyzer.SampleLowFrequency(
                        profile, (x + 0.5f) / width, (y + 0.5f) / height);
                    OklchColor baseColor = RegionGradientColorMath.ToOklch(baseLab);

                    float hueProfile = profile.CenterColor.C > 0.025f && baseColor.C > 0.025f
                        ? RegionGradientColorMath.HueDelta(profile.CenterColor.H, baseColor.H) : 0f;
                    float hueDetail = baseColor.C > 0.025f && original.C > 0.025f
                        ? RegionGradientColorMath.HueDelta(baseColor.H, original.H) : 0f;

                    // Broad source gradients, lightness trends, saturation trends and local shading are independent controls.
                    float outL = gradientColor.L
                               + (baseColor.L - profile.CenterColor.L) * settings.BrightnessRetention
                               + (original.L - baseColor.L) * settings.ShadingRetention;
                    float outC = gradientColor.C
                               + (baseColor.C - profile.CenterColor.C) * settings.SaturationRetention
                               + (original.C - baseColor.C) * 0.12f;
                    float outH = gradientColor.H
                               + hueProfile * settings.OriginalGradientRetention
                               + hueDetail * 0.10f;

                    OklabColor desiredLab = RegionGradientColorMath.ToOklab(new OklchColor(outL, outC, outH));
                    OklabColor basePixelLab = RegionGradientColorMath.ToOklab(basePixels[index]);
                    OklabColor blended = new OklabColor(
                        Mathf.Lerp(basePixelLab.L, desiredLab.L, mask),
                        Mathf.Lerp(basePixelLab.A, desiredLab.A, mask),
                        Mathf.Lerp(basePixelLab.B, desiredLab.B, mask));
                    output[index] = RegionGradientColorMath.ToSrgb(RegionGradientColorMath.ToOklch(blended), source[index].a);
                }
            }
            return new RegionGradientResult(output, selectedPixels, partiallySelectedPixels);
        }

        private static float EvaluatePosition(Vector2 coordinate, RegionGradientSettings settings)
        {
            float angle = settings.AngleDegrees * Mathf.Deg2Rad;
            Vector2 direction = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));
            Vector2 origin = new Vector2(settings.PositionX, settings.PositionY);
            float projection = Vector2.Dot(coordinate - origin, direction);
            return Mathf.Clamp01(0.5f + projection / Mathf.Max(0.025f, settings.Scale));
        }

        private static OklchColor EvaluateGradient(RegionGradientSettings settings, float t)
        {
            if (t <= 0.5f) return RegionGradientColorMath.Lerp(settings.StartColor, settings.MiddleColor, t * 2f);
            return RegionGradientColorMath.Lerp(settings.MiddleColor, settings.EndColor, (t - 0.5f) * 2f);
        }
    }
}
