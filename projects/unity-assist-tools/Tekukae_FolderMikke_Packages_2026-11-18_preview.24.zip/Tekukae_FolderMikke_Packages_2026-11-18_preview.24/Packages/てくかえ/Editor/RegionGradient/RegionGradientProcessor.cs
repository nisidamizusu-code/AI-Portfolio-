using System;
using UnityEngine;

namespace Tekukae.TextureColorEngine.Editor.RegionGradient
{
    /// <summary>
    /// Orchestrates the independent Region Gradient pipeline. Analysis and composition are separate modules.
    /// </summary>
    internal static class RegionGradientProcessor
    {
        private const int MaximumPixels = 4194304;

        public static RegionGradientResult Apply(Color32[] source, int width, int height, byte[] selection,
            Vector2[] normalizedCoordinates, RegionGradientSettings settings)
        {
            return Apply(source, source, width, height, selection, normalizedCoordinates, settings);
        }

        /// <summary>
        /// Applies one independent region pass. Source is always the untouched original image used for analysis;
        /// basePixels is the accumulated result from earlier regions. This keeps each region's source profile stable.
        /// </summary>
        public static RegionGradientResult Apply(Color32[] source, Color32[] basePixels, int width, int height, byte[] selection,
            Vector2[] normalizedCoordinates, RegionGradientSettings settings)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (basePixels == null) throw new ArgumentNullException(nameof(basePixels));
            if (selection == null) throw new ArgumentNullException(nameof(selection));
            if (settings == null) throw new ArgumentNullException(nameof(settings));
            int count = checked(width * height);
            if (source.Length != count || basePixels.Length != count || selection.Length != count) throw new ArgumentException("Image and selection sizes do not match.");
            if (count > MaximumPixels)
                throw new InvalidOperationException("Region Gradientの初期版は4,194,304ピクセルまでです。対象テクスチャを縮小するか、領域を分けてください。");
            if (normalizedCoordinates != null && normalizedCoordinates.Length != count)
                throw new ArgumentException("Coordinate map size does not match.");

            byte[] softMask = RegionSelectionEngine.Feather(selection, width, height, settings.FeatherPixels);
            OriginalTextureProfile profile = OriginalTextureProfileAnalyzer.Analyze(source, width, height, selection);
            return RegionGradientCompositor.Compose(source, basePixels, width, height, selection, softMask,
                normalizedCoordinates, profile, settings);
        }
    }
}
