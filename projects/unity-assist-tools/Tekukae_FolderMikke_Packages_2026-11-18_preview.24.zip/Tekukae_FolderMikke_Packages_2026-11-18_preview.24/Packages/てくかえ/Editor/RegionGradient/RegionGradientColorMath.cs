using System;
using UnityEngine;

namespace Tekukae.TextureColorEngine.Editor.RegionGradient
{
    /// <summary>
    /// Independent perceptual color implementation for Region Gradient.
    /// All color analysis, interpolation and composition happen in OKLab/OKLCH.
    /// Color32 is only the sRGB image I/O boundary.
    /// </summary>
    internal static class RegionGradientColorMath
    {
        internal static float Clamp01(float value) { return Mathf.Clamp01(value); }
        internal static float NormalizeHue(float hue)
        {
            hue %= 360f;
            return hue < 0f ? hue + 360f : hue;
        }
        internal static float HueDelta(float from, float to)
        {
            float delta = NormalizeHue(to) - NormalizeHue(from);
            if (delta > 180f) delta -= 360f;
            if (delta < -180f) delta += 360f;
            return delta;
        }

        internal static OklabColor ToOklab(Color32 srgb)
        {
            float r = SrgbToLinear(srgb.r / 255f);
            float g = SrgbToLinear(srgb.g / 255f);
            float b = SrgbToLinear(srgb.b / 255f);
            float l = 0.4122214708f * r + 0.5363325363f * g + 0.0514459929f * b;
            float m = 0.2119034982f * r + 0.6806995451f * g + 0.1073969566f * b;
            float s = 0.0883024619f * r + 0.2817188376f * g + 0.6299787005f * b;
            float lr = Cbrt(l), mr = Cbrt(m), sr = Cbrt(s);
            return new OklabColor(
                0.2104542553f * lr + 0.7936177850f * mr - 0.0040720468f * sr,
                1.9779984951f * lr - 2.4285922050f * mr + 0.4505937099f * sr,
                0.0259040371f * lr + 0.7827717662f * mr - 0.8086757660f * sr);
        }

        internal static OklchColor ToOklch(OklabColor lab)
        {
            float c = Mathf.Sqrt(lab.A * lab.A + lab.B * lab.B);
            float h = c < 1e-6f ? 0f : Mathf.Atan2(lab.B, lab.A) * Mathf.Rad2Deg;
            return new OklchColor(lab.L, c, NormalizeHue(h));
        }

        internal static OklabColor ToOklab(OklchColor lch)
        {
            float radians = lch.H * Mathf.Deg2Rad;
            return new OklabColor(lch.L, lch.C * Mathf.Cos(radians), lch.C * Mathf.Sin(radians));
        }

        internal static OklchColor Lerp(OklchColor a, OklchColor b, float t)
        {
            t = Clamp01(t);
            return new OklchColor(
                Mathf.Lerp(a.L, b.L, t),
                Mathf.Lerp(a.C, b.C, t),
                NormalizeHue(a.H + HueDelta(a.H, b.H) * t));
        }

        internal static Color32 ToSrgb(OklchColor desired, byte alpha)
        {
            float low = 0f;
            float high = Mathf.Max(0f, desired.C);
            float r, g, b;
            if (TryToLinearRgb(ToOklab(desired), out r, out g, out b) && InGamut(r, g, b))
                return MakeSrgb(r, g, b, alpha);

            for (int i = 0; i < 18; i++)
            {
                float mid = (low + high) * 0.5f;
                OklchColor test = new OklchColor(desired.L, mid, desired.H);
                if (TryToLinearRgb(ToOklab(test), out r, out g, out b) && InGamut(r, g, b)) low = mid;
                else high = mid;
            }
            OklchColor mapped = new OklchColor(desired.L, low, desired.H);
            TryToLinearRgb(ToOklab(mapped), out r, out g, out b);
            return MakeSrgb(r, g, b, alpha);
        }

        internal static float Distance(OklabColor a, OklabColor b)
        {
            float dl = a.L - b.L;
            float da = a.A - b.A;
            float db = a.B - b.B;
            return Mathf.Sqrt(dl * dl + da * da + db * db);
        }

        private static float SrgbToLinear(float value)
        {
            return value <= 0.04045f ? value / 12.92f : Mathf.Pow((value + 0.055f) / 1.055f, 2.4f);
        }
        private static float LinearToSrgb(float value)
        {
            value = Mathf.Clamp01(value);
            return value <= 0.0031308f ? value * 12.92f : 1.055f * Mathf.Pow(value, 1f / 2.4f) - 0.055f;
        }
        private static float Cbrt(float value) { return value < 0f ? -Mathf.Pow(-value, 1f / 3f) : Mathf.Pow(value, 1f / 3f); }
        private static bool InGamut(float r, float g, float b)
        {
            const float e = 1e-5f;
            return r >= -e && g >= -e && b >= -e && r <= 1f + e && g <= 1f + e && b <= 1f + e;
        }
        private static bool TryToLinearRgb(OklabColor lab, out float r, out float g, out float b)
        {
            float l = lab.L + 0.3963377774f * lab.A + 0.2158037573f * lab.B;
            float m = lab.L - 0.1055613458f * lab.A - 0.0638541728f * lab.B;
            float s = lab.L - 0.0894841775f * lab.A - 1.2914855480f * lab.B;
            l *= l * l; m *= m * m; s *= s * s;
            r = 4.0767416621f * l - 3.3077115913f * m + 0.2309699292f * s;
            g = -1.2684380046f * l + 2.6097574011f * m - 0.3413193965f * s;
            b = -0.0041960863f * l - 0.7034186147f * m + 1.7076147010f * s;
            return IsFinite(r) && IsFinite(g) && IsFinite(b);
        }
        private static bool IsFinite(float value) { return !float.IsNaN(value) && !float.IsInfinity(value); }
        private static Color32 MakeSrgb(float r, float g, float b, byte alpha)
        {
            return new Color32(
                (byte)Mathf.RoundToInt(LinearToSrgb(r) * 255f),
                (byte)Mathf.RoundToInt(LinearToSrgb(g) * 255f),
                (byte)Mathf.RoundToInt(LinearToSrgb(b) * 255f), alpha);
        }
    }

    internal struct OklabColor
    {
        public float L, A, B;
        public OklabColor(float l, float a, float b) { L = l; A = a; B = b; }
    }

    internal struct OklchColor
    {
        public float L, C, H;
        public OklchColor(float l, float c, float h)
        {
            L = Mathf.Clamp01(l);
            C = Mathf.Max(0f, c);
            H = RegionGradientColorMath.NormalizeHue(h);
        }
    }
}
