namespace Tekukae.TextureColorEngine.Editor.RegionGradient
{
    internal sealed class OriginalTextureProfile
    {
        public readonly OklchColor CenterColor;
        public readonly OklabColor[] LowFrequencyLab;
        public readonly int GridWidth;
        public readonly int GridHeight;

        public OriginalTextureProfile(OklchColor centerColor, OklabColor[] lowFrequencyLab, int gridWidth, int gridHeight)
        {
            CenterColor = centerColor;
            LowFrequencyLab = lowFrequencyLab;
            GridWidth = gridWidth;
            GridHeight = gridHeight;
        }
    }
}
