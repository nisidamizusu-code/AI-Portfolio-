using System;
using UnityEngine;

namespace Tekukae.TextureColorEngine.Editor.RegionGradient
{
    /// <summary>
    /// Separates broad original color gradients from local shading/details in OKLab.
    /// No RGB/HSV/HSL arithmetic is used in the analysis stage.
    /// </summary>
    internal static class OriginalTextureProfileAnalyzer
    {
        public static OriginalTextureProfile Analyze(Color32[] source, int width, int height, byte[] selection)
        {
            if (source == null || selection == null) throw new ArgumentNullException();
            if (source.Length != width * height || selection.Length != source.Length)
                throw new ArgumentException("Source and selection dimensions do not match.");
            OklchColor center = AverageSelectedColor(source, selection);
            int gridWidth = Mathf.Min(192, width);
            int gridHeight = Mathf.Min(192, height);
            OklabColor[] lowFrequency = BuildLowFrequencyProfile(source, width, height, selection, gridWidth, gridHeight);
            return new OriginalTextureProfile(center, lowFrequency, gridWidth, gridHeight);
        }

        private static OklchColor AverageSelectedColor(Color32[] source, byte[] selection)
        {
            double l = 0d, a = 0d, b = 0d;
            long count = 0;
            for (int i = 0; i < source.Length; i++)
            {
                if (selection[i] == 0 || source[i].a < 16) continue;
                OklabColor lab = RegionGradientColorMath.ToOklab(source[i]);
                l += lab.L; a += lab.A; b += lab.B; count++;
            }
            if (count == 0) throw new InvalidOperationException("選択範囲に処理可能な不透明ピクセルがありません。");
            return RegionGradientColorMath.ToOklch(new OklabColor((float)(l / count), (float)(a / count), (float)(b / count)));
        }

        private static OklabColor[] BuildLowFrequencyProfile(Color32[] source, int width, int height, byte[] selection, int gridWidth, int gridHeight)
        {
            int gridCount = gridWidth * gridHeight;
            double[] l = new double[gridCount];
            double[] a = new double[gridCount];
            double[] b = new double[gridCount];
            int[] counts = new int[gridCount];
            for (int y = 0; y < height; y++)
            {
                int gy = Mathf.Min(gridHeight - 1, y * gridHeight / height);
                for (int x = 0; x < width; x++)
                {
                    int sourceIndex = y * width + x;
                    Color32 pixel = source[sourceIndex];
                    if (selection[sourceIndex] == 0 || pixel.a < 16) continue;
                    int gx = Mathf.Min(gridWidth - 1, x * gridWidth / width);
                    int index = gy * gridWidth + gx;
                    OklabColor lab = RegionGradientColorMath.ToOklab(pixel);
                    l[index] += lab.L; a[index] += lab.A; b[index] += lab.B; counts[index]++;
                }
            }
            OklabColor[] result = new OklabColor[gridCount];
            bool[] assigned = new bool[gridCount];
            int[] queue = new int[gridCount];
            int head = 0, tail = 0;
            for (int i = 0; i < gridCount; i++)
            {
                if (counts[i] <= 0) continue;
                result[i] = new OklabColor((float)(l[i] / counts[i]), (float)(a[i] / counts[i]), (float)(b[i] / counts[i]));
                assigned[i] = true;
                queue[tail++] = i;
            }
            if (tail == 0) throw new InvalidOperationException("選択範囲の低周波色プロファイルを作成できません。");
            // Fill empty coarse cells from their nearest selected cell before smoothing.
            while (head < tail)
            {
                int index = queue[head++];
                int x = index % gridWidth;
                int y = index / gridWidth;
                Fill(x - 1, y, index); Fill(x + 1, y, index); Fill(x, y - 1, index); Fill(x, y + 1, index);
            }
            return BlurGrid(result, gridWidth, gridHeight);

            void Fill(int x, int y, int from)
            {
                if (x < 0 || y < 0 || x >= gridWidth || y >= gridHeight) return;
                int index = y * gridWidth + x;
                if (assigned[index]) return;
                assigned[index] = true;
                result[index] = result[from];
                queue[tail++] = index;
            }
        }

        private static OklabColor[] BlurGrid(OklabColor[] input, int width, int height)
        {
            OklabColor[] horizontal = new OklabColor[input.Length];
            OklabColor[] output = new OklabColor[input.Length];
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    OklabColor sum = default(OklabColor); int samples = 0;
                    for (int k = -2; k <= 2; k++)
                    {
                        OklabColor c = input[y * width + Mathf.Clamp(x + k, 0, width - 1)];
                        sum.L += c.L; sum.A += c.A; sum.B += c.B; samples++;
                    }
                    horizontal[y * width + x] = new OklabColor(sum.L / samples, sum.A / samples, sum.B / samples);
                }
            }
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    OklabColor sum = default(OklabColor); int samples = 0;
                    for (int k = -2; k <= 2; k++)
                    {
                        OklabColor c = horizontal[Mathf.Clamp(y + k, 0, height - 1) * width + x];
                        sum.L += c.L; sum.A += c.A; sum.B += c.B; samples++;
                    }
                    output[y * width + x] = new OklabColor(sum.L / samples, sum.A / samples, sum.B / samples);
                }
            }
            return output;
        }

        public static OklabColor SampleLowFrequency(OriginalTextureProfile profile, float u, float v)
        {
            float fx = Mathf.Clamp01(u) * (profile.GridWidth - 1);
            float fy = Mathf.Clamp01(v) * (profile.GridHeight - 1);
            int x0 = Mathf.FloorToInt(fx), y0 = Mathf.FloorToInt(fy);
            int x1 = Mathf.Min(profile.GridWidth - 1, x0 + 1);
            int y1 = Mathf.Min(profile.GridHeight - 1, y0 + 1);
            float tx = fx - x0, ty = fy - y0;
            OklabColor a = Lerp(profile.LowFrequencyLab[y0 * profile.GridWidth + x0], profile.LowFrequencyLab[y0 * profile.GridWidth + x1], tx);
            OklabColor b = Lerp(profile.LowFrequencyLab[y1 * profile.GridWidth + x0], profile.LowFrequencyLab[y1 * profile.GridWidth + x1], tx);
            return Lerp(a, b, ty);
        }

        private static OklabColor Lerp(OklabColor a, OklabColor b, float t)
        {
            return new OklabColor(Mathf.Lerp(a.L, b.L, t), Mathf.Lerp(a.A, b.A, t), Mathf.Lerp(a.B, b.B, t));
        }
    }
}
