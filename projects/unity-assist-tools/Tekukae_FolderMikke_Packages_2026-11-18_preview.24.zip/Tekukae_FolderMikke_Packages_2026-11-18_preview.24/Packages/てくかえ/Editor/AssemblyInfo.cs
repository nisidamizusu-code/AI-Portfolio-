using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Tekukae.TextureColorEngine.Tests")]
