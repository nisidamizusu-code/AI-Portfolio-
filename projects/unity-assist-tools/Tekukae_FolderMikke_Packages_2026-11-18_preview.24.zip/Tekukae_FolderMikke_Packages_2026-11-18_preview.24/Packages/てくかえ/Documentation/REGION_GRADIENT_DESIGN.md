# Region Gradient Extension — 0.1.0-preview.13

## 目的

既存のColor Conversion機能を維持したまま、選択領域へグラデーションを適用する機能を追加する。元テクスチャが持つ広い範囲の色変化、明度傾向、彩度傾向、局所的な陰影を別々に分析し、新しいグラデーションへ反映する。

髪のMain / Sideなど、異なるRenderer・Material・Textureに分かれたパーツを同じTarget Groupへ登録し、Avatar Root基準の共通3D座標からグラデーションを評価することを目標とする。

## 既存機能の保護

- `Runtime/ColorMath.cs`、`Runtime/MaterialColorProfile.cs`、`Runtime/TextureColorEngine.cs`は変更しない。
- 既存の`TextureSourceReader.cs`と既存の色変換処理も変更しない。
- 既存EditorWindowにはFeature ToolbarとRegion Gradient Panelへの入口だけを追加する。
- Region Gradientは独立したクラス群で色変換・選択・分析・合成を実行する。既存の`TextureColorEngine`を呼び出さない。
- 元Textureと既存Materialを上書きしない。出力PNGは新しいアセットとして生成する。

## 主な機能

### 1. Target Group

- 最大12個のTexture Targetを登録できる。
- 各TargetはTexture、Renderer（任意）、Material Index、Texture Propertyを保持する。
- Main / Sideなど、別々のTextureを同じグループへ登録できる。
- Avatar Rootを指定すると、各Rendererの頂点位置をAvatar Rootローカル座標へ変換して共通Boundsを求める。

### 2. 自動領域選択

- Texture View：画像上のクリック位置から連続領域を自動選択する。
- Scene View：登録済みRendererをクリックし、対象SubMeshの三角形と交差するUV0を取得して同じ領域選択処理へ渡す。
- Shift + Click：既存選択へ領域を追加する。
- Texture ViewのAlt + Click / Scene ViewのCtrl + Click：領域を既存選択から除外する。
- 選択判定はOKLabの色差、隣接画素間の変化、シード色からの許容範囲を組み合わせる。
- 選択マスクは0～255の値で保持し、適用前にFeather処理できる。

この初期版は意味認識AIではない。色の近さと連続性に基づくSeeded Region Growingであり、同じ色が隣接する別パーツや境界の弱い部分では誤選択する可能性がある。

### 3. Texture Analysis

元TextureをOKLab / OKLCHへ変換し、選択領域を基準に次の情報を抽出する。

- Original Gradient：低周波の色相変化。元テクスチャの根元～毛先などの大きな色の流れを移植する。
- Brightness：低周波OKLab明度の領域平均との差。
- Saturation：低周波OKLCH彩度の領域平均との差。
- Shading：元画素と低周波プロファイルとの差。局所的な明暗・ハイライトを主に扱う。

低周波プロファイルは選択画素のみを192×192以下の粗い格子へ集約し、空セルを近傍の選択セルで補完して平滑化する。高周波側は元画素と低周波プロファイルの差として扱う。

これは画像信号のスケール分離による推定であり、色グラデーションと陰影を意味的に完全分離するものではない。保持率で結果を調整する必要がある。

### 4. Perceptual Gradient

- 色計算・色補間・色差・色合成は、この機能専用のOKLab / OKLCH実装で行う。
- sRGB RGBA8は画像入出力境界としてのみ使用する。
- Start / Middle / Endの3色を設定できる。
- Position X / Y、Angle、Scaleでグラデーションの位置・方向・幅を調整する。
- UV座標モードではTexture Preview上のハンドルをドラッグでき、同じ値をスライダーで微調整できる。
- Avatar Rootの3D座標マップがあるTargetでは共通Model Space座標で評価し、Texture Viewのハンドルは表示しない。スライダーが共通座標値を制御する。

### 5. 複数Textureへの共通適用

- Target Group内でGradient設定は共有する。
- 元色グラデーション・明度・彩度・陰影プロファイルは各Textureから個別に抽出する。
- 3D座標マップが構築できるTargetは、Avatar Rootローカル座標の共通Boundsに正規化してグラデーションを評価する。
- Renderer / Material Index / Texture Propertyが合わないTarget、UV0がないTarget、標準外のTiling / Offsetを持つTargetは3D座標マッピングを行わず、UV座標へフォールバックする。
- UV重複は衝突画素数を警告する。共有UV画素に異なる3D位置の色を個別に出力することはできない。

## 色計算

OKLab / OKLCHへの変換式はRegion Gradient専用の`RegionGradientColorMath`に実装し、既存Runtimeの`ColorMath`とは独立させる。

低周波プロファイルを`base`、元画素を`original`、選択領域の代表色を`center`、新しいグラデーション色を`gradient`とする。現在の合成モデルは概ね次のとおり。

- `Lout = gradient.L + (base.L - center.L) * BrightnessRetention + (original.L - base.L) * ShadingRetention`
- `Cout = gradient.C + (base.C - center.C) * SaturationRetention + (original.C - base.C) * 0.12`
- `Hout = gradient.H + HueDelta(center.H, base.H) * OriginalGradientRetention + HueDelta(base.H, original.H) * 0.10`

選択マスクの値で元画素と合成し、最終色はOKLCHからsRGBへ色域マッピングして出力する。色域外では明度・色相の維持を優先し、彩度を二分探索で下げる。元アルファは維持する。

このモデルは初期仮説であり、実際の髪・肌・衣装テクスチャでの目視確認を前提とする。

## 処理分離

- `RegionGradientColorMath`：OKLab / OKLCH変換、色相補間、色域マッピング。
- `RegionSelectionEngine`：領域拡張とマスクFeather。
- `OriginalTextureProfileAnalyzer`：元の色傾向・明度・彩度・局所差分の分析用プロファイル作成。
- `RegionGradientCompositor`：分析プロファイルとグラデーションを合成。
- `RegionGradientProcessor`：分析・マスク・合成の実行を調整するだけの入口。
- `RegionGradientMeshUtility`：Scene Ray / SubMesh / UV0 / 3D座標マップ。
- `RegionGradientTextureIO`：元画像読込・プレビュー・PNG出力・Importer設定引継ぎ。
- `RegionGradientPanel`：Editor UIとユーザー操作。

処理モジュールはTextureやMaterialのAssetを直接変更しない。UIがデータを渡し、結果データを受け取る。


## preview.13：複数の独立Gradient Region

- Gradient Regionは最大16件。各Regionは独立した設定（Start / Middle / End Color、Position X/Y、Angle、Scale、元色グラデーション保持、陰影・明度・彩度保持、Feather）を持つ。
- 各Texture TargetはRegion IDごとに独立したSelection Maskを保持する。同じRegionにMain / Sideなど複数Targetを選択すると、グラデーション設定は共有され、選択マスクと元画像解析プロファイルはTargetごとに独立する。
- 同じTexture内の別々の場所を異なる方向で変換する場合は、Regionを追加し、それぞれのRegionで範囲を選択してAngle / Position / Scaleを別々に設定する。
- Regionは有効 / 無効を切り替えられる。リスト順で適用し、後のRegionほど先に適用したRegionの上に合成される。上下ボタンで適用順を変更できる。
- Region追加時は現在選択中Regionのグラデーション設定を複製するが、選択マスクは複製しない。新しい領域は各Targetで改めて選択する。
- プレビュー生成では元Textureのピクセル配列を不変の解析元として保持し、各Regionの分析は常に元Textureから行う。合成のベースだけを直前Regionの出力にする。これにより、先行Regionの処理結果が後続Regionの元画像分析へ混入しない。
- Region同士の選択範囲が重なった場合、後順位のRegionが上書き方向で合成される。Feather境界では現在の合成結果と後順位のRegionの結果をマスク率でブレンドする。

## 初期版の制約

- 1つのTextureは4,194,304ピクセル（2048×2048相当）まで。
- Target Groupは最大12件。Gradient Regionは最大16件。
- BaseColor向けのsRGB Textureを対象とする。Linear / Normal / Mask用Textureには使用しない。
- 直接ファイル読込はPNG / JPG / JPEG。その他の形式や生成TextureはImport済みTexture2DのReadbackへフォールバックし、警告する。
- Model SpaceマッピングはUV0、登録RendererのMaterial Index/SubMesh、標準Tiling / Offsetを前提とする。
- UV0が0～1を大きく外れるケース、複雑なミラー・タイルUV、複数SubMeshで共有される特殊構成は未対応またはUVフォールバックとなる。
- Scene Viewの3Dクリックは登録済みRendererに限定する。Unity標準のRendererコライダーを追加・変更しない。
- SkinnedMeshRendererはクリック時にBakeMeshを使う。マッピングは明示的に再構築する。
- 元TextureのImporter設定は変更しない。出力PNGは新規作成し、可能な範囲で元Importer設定を引き継ぐ。
- 自動選択はヒューリスティックであり、複雑な髪束・似た色の隣接パーツではShift/Alt/Ctrl選択補正が必要になる。
- Unity Editor上のコンパイル・Scene View操作・実テクスチャの視覚品質はユーザー環境で確認が必要。

## Unity上での確認項目

1. 既存Color Conversionタブで単色・2点変換・プレビュー・PNG出力が従来どおり動く。
2. Region Gradientタブを開き、sRGBのBaseColor PNGを読み込める。
3. Texture Viewクリックで連続領域を選択し、Shift追加・Alt除外が動作する。
4. Feather幅を変更して境界の適用量が変わる。
5. Start / Middle / EndとX / Y / Angle / Scaleを変更し、ドラッグハンドルと連動する。
6. Original Gradient / Shading / Brightness / Saturationを個別に変更し、毛先色変化・局所陰影・明度・彩度の反映差を確認する。
7. Scene Viewで登録Rendererをクリックし、該当TextureのUV位置から選択される。
8. Main / SideのRendererとTextureを同じGroupへ登録し、Avatar Rootの3D座標マップを構築して共通グラデーションを確認する。
9. UV重複、Tiling / Offset、Renderer / Material Property不一致の警告を確認する。
10. PNG出力後、元Textureの画素・Importer設定・Material割当が変更されていないことを確認する。

## 検証状況

- C#ソースの括弧・文字列・コメントの静的整合性：未実行のUnityコンパイルの代替チェックとして実施予定。
- JSON / asmdef：静的パース対象。
- Unity Editor / C#コンパイラ：この制作環境にないため、実コンパイルとUnity Test Runnerは未実施。
- Scene ViewのRay選択、BakeMesh、UVマップ、GPU/CPU読込、プレビュー操作：未実機確認。
- 髪Main / Sideの連続性と元色グラデーション分離：実アバターでの目視確認が必要。
