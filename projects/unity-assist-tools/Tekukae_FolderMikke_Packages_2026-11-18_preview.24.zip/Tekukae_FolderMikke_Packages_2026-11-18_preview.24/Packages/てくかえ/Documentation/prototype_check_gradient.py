"""Numerical mirror for the neutral two-point selection corridor.

Usage:
  python prototype_check_gradient.py <texture.png> [<texture2.png> ...]

This is an offline Python analysis only; it is not a Unity/C# runtime test.
"""
import sys
from pathlib import Path
import numpy as np
from PIL import Image


def srgb_to_linear(x):
    return np.where(x <= 0.04045, x / 12.92, ((x + 0.055) / 1.055) ** 2.4)


def to_oklab(rgb):
    rgb = rgb.astype(np.float32) / 255.0
    linear = srgb_to_linear(rgb)
    r, g, b = linear[..., 0], linear[..., 1], linear[..., 2]
    l = 0.4122214708*r + 0.5363325363*g + 0.0514459929*b
    m = 0.2119034982*r + 0.6806995451*g + 0.1073969566*b
    s = 0.0883024619*r + 0.2817188376*g + 0.6299787005*b
    lr, mr, sr = np.cbrt(l), np.cbrt(m), np.cbrt(s)
    L = 0.2104542553*lr + 0.7936177850*mr - 0.0040720468*sr
    a = 1.9779984951*lr - 2.4285922050*mr + 0.4505937099*sr
    bb = 0.0259040371*lr + 0.7827717662*mr - 0.8086757660*sr
    return np.stack([L, a, bb], axis=-1)


def smoothstep(edge0, edge1, value):
    t = np.clip((value - edge0) / (edge1 - edge0), 0.0, 1.0)
    return t*t*(3.0 - 2.0*t)


def analyze(path, start_rgb, end_rgb):
    rgba = np.asarray(Image.open(path).convert('RGBA'))
    pixels = rgba.reshape(-1, 4)
    lab = to_oklab(pixels[:, :3])
    start = to_oklab(np.asarray(start_rgb, dtype=np.uint8).reshape(1, 3))[0]
    end = to_oklab(np.asarray(end_rgb, dtype=np.uint8).reshape(1, 3))[0]
    delta = end - start
    length_sq = float(np.dot(delta, delta))
    if length_sq <= 1e-7:
        raise ValueError('The two source colors are too close.')

    progress = np.clip(((lab - start) * delta).sum(axis=1) / length_sq, 0.0, 1.0)
    expected = start + progress[:, None] * delta
    ab_distance = np.linalg.norm(lab[:, 1:3] - expected[:, 1:3], axis=1)

    source_l = np.array([start[0], end[0]])
    light_min = source_l.min() - 0.065
    light_max = source_l.max() + 0.065
    light_weight = np.where(
        lab[:, 0] < light_min,
        smoothstep(light_min - 0.02, light_min, lab[:, 0]),
        np.where(lab[:, 0] > light_max,
                 1.0 - smoothstep(light_max, light_max + 0.02, lab[:, 0]), 1.0))

    start_c = float(np.linalg.norm(start[1:3]))
    end_c = float(np.linalg.norm(end[1:3]))
    old_tolerance = min(0.035, max(0.015, max(start_c, end_c) * 1.5 + 0.004))
    new_tolerance = min(0.045, max(0.03, max(start_c, end_c) * 1.5 + 0.004))
    old_weight = (1.0 - smoothstep(old_tolerance * 0.55, old_tolerance, ab_distance)) * light_weight
    new_weight = (1.0 - smoothstep(new_tolerance * 0.65, new_tolerance, ab_distance)) * light_weight

    candidate = (pixels[:, 3] >= 16) & (light_weight > 0.0)
    print(f'\n{Path(path).name}: size={rgba.shape[1]}x{rgba.shape[0]}, candidates={int(candidate.sum()):,}')
    print(f'anchor lightness delta={abs(start[0]-end[0]):.5f}, old a/b tolerance={old_tolerance:.5f}, new={new_tolerance:.5f}')
    for name, weight in (('preview.10', old_weight), ('candidate', new_weight)):
        values = weight[candidate]
        full = int(np.count_nonzero(values >= 0.999))
        partial = int(np.count_nonzero((values > 0.01) & (values < 0.999)))
        none = int(np.count_nonzero(values <= 0.01))
        print(f'  {name}: full={full:,}, partial={partial:,}, none={none:,}')


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Usage: python prototype_check_gradient.py <texture.png> [<texture2.png> ...]')
        raise SystemExit(2)
    for filename in sys.argv[1:]:
        analyze(filename, (253, 253, 253), (201, 196, 192))
