# Region Gradient Preview 0.1.0-preview.13 — 静的確認レポート

## 対象
- 基準として受領した `旧版の基準パッケージ`
- ZIP内のTexture Color Engineパッケージ：`0.1.0-preview.11_GradientContinuityTest`
- 追加機能：Region Gradient

## 実装した範囲
- 既存EditorWindowに `Color Conversion / Region Gradient` のタブ切替を追加
- 既存Color Conversionの実処理を呼び出さないRegion Gradient専用処理群
- Texture ViewのクリックによるSeeded Region Growing選択、追加・除外、Feather
- 登録Rendererを対象にしたScene Viewクリック、SubMesh/UV0取得
- Avatar Root基準のUV→3D座標マップと複数Texture Target Group
- OKLab / OKLCHでの色補間・分析・合成、3色グラデーション
- 元画像の低周波色変化、明度、彩度、局所的な色差（陰影候補）の別々の保持率
- Position X/Y、Angle、Scaleの調整、Texture Viewのグラデーションハンドル
- 元Textureを上書きしない新規PNG出力

## 既存機能の保護確認
次の既存コアファイルは、基準ZIP内のファイルとSHA-256が一致することを監査対象とする。
- `Runtime/ColorMath.cs`
- `Runtime/ColorTypes.cs`
- `Runtime/MaterialColorProfile.cs`
- `Runtime/TextureColorEngine.cs`
- `Runtime/Tekukae.TextureColorEngine.asmdef`
- `Editor/TextureSourceReader.cs`

既存EditorWindowの変更は、タブ切替・Region Gradientパネル保持・終了時Disposeの追加に限定。既存のColor Conversionの表示・処理コードは変更していない。

## 静的確認で行う項目
- ZIP CRC / 展開整合性
- package.json / asmdefのJSON構文
- C#の括弧・文字列・コメントの字句バランス
- `.meta` GUIDの重複有無
- 新規C#・Documentationファイルの`.meta`付与
- 既存コアファイルのSHA-256比較
- 既存のFolderMikke配下ファイルのSHA-256比較

## 未実施・実機確認が必要な項目
- Unity EditorによるC#コンパイル
- Unity Test Runner実行（テストコードは収録済み）
- Scene ViewクリックとSkinnedMeshRenderer.BakeMeshの実機動作
- 実際の髪Main / Sideでのモデル空間グラデーション連続性
- 自動選択が髪束・肌・衣装境界で適切に働くかの視覚評価
- OKLab / OKLCH合成による元グラデーション・陰影・明度・彩度保持の実素材評価
- 高解像度テクスチャでのメモリ・処理時間測定

## 初期版の制限
- 1テクスチャあたり4,194,304ピクセルまで、Targetは最大12件
- BaseColor向けsRGB Textureが対象。Linear / Normal / Mask用途は対象外
- Seeded Region Growing方式であり、意味認識AIではない。境界が曖昧な場合は追加・除外操作が必要
- 3D座標マップはRenderer / Material Index / Texture Property / UV0 / 標準Tiling・Offsetを前提とする
- UV重複部分では1つのテクスチャ画素を複数の3D位置に別々に出力できない
- Original GradientとShadingは低周波・局所差分による推定であり、意味的に完全分離する保証はない
- Materialへの自動割当は行わない

## 実機テストの推奨順
1. 既存Color Conversionの単色・2点変換・PNG保存が基準版と同じ動作か確認
2. 小さなsRGB BaseColor PNGでRegion Gradientタブを開く
3. Texture Viewクリック、Shift追加、Alt除外を確認
4. 元の色変化・陰影・明度・彩度の各保持率を個別に変更して比較
5. X/Y/Angle/ScaleスライダーとTexture Viewハンドルを確認
6. 髪Main・Sideを別々のTargetとして登録し、Avatar Rootを指定して3D座標マップを再構築
7. Scene Viewで両方をクリックして領域選択し、共通グラデーションを確認
8. PNG保存後、元Texture・元Material・Importer設定が変更されていないことを確認

本レポートは静的確認の記録であり、Unity上での動作保証を示すものではない。


## この制作環境での静的確認結果
- `package.json` と3つの`.asmdef`：JSONパース成功
- C#ソース19ファイル：Pygments C# Lexerによる文字列・コメントを除外した括弧対応チェックで問題なし
- `.meta`：46ファイル、GUID 46個、重複なし
- 既存色変換コア6ファイル：基準ZIPとSHA-256一致
- `FolderMikke`：基準ZIP内の全ファイルとSHA-256一致
- ZIP：展開テスト・CRC検査成功（85エントリー）
- 既存EditorWindowの差分：タブ切替、Region Gradient Panelの生成・終了時Disposeに限定

上記は静的監査の結果であり、C#コンパイラによる型解決やUnity Editor APIの実行時動作を保証しない。


## Compile Hotfix 1
- Corrected `RegionGradientPanel.DrawGradientColorField`: the selected `Color32` is compared with the prior value by its R/G/B/A byte channels instead of the unsupported `Color32 != Color32` operator.
- Re-scanned Region Gradient C# sources for `Color32` equality/inequality operator use; no remaining occurrences.
- This is a source-level correction for the reported CS0019 error. Unity Editor compilation still needs to be confirmed in the user's project.


## preview.13 複数領域対応

### 変更内容
- Gradient Regionを最大16件管理できるUIを追加。各Regionは独立した設定値と、各Targetごとの独立Selection Maskを持つ。
- 1つのTextureに複数の異なる範囲を作り、Regionごとに異なるAngle / Position / Scale / Colorを設定可能。
- 同じRegion内にMain / Sideなど複数Targetを登録すると、Region設定を共有しつつ、選択範囲と元Texture解析は個別に保持。
- Regionごとの有効・無効、追加・削除、適用順の変更を追加。
- 合成は順番に実行するが、元Texture解析は毎回未加工の原画像を参照するようProcessor / Compositorを分離。

### 追加したEditor Test
- `GradientProcessor_MultipleRegionsKeepMasksAndSettingsIndependent`：左領域と右領域に別々の設定を適用し、片方のRegionが他方の非選択画素を変更しないことを確認。
- `GradientProcessor_LaterOverlappingRegionCompositesAfterEarlierRegion`：重複領域でRegionの適用順により結果が変わり、後のRegionが後から合成されることを確認。

### 未実施
- Unity EditorでのC#コンパイルとTest Runner実行。
- 実アバターのMain / Side、および同一Texture内の複数方向の視覚確認。
- 16 Region × 12 Targetのメモリ・処理時間測定。
