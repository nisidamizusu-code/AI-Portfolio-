using NUnit.Framework;
using UnityEngine;
using Tekukae.TextureColorEngine.Editor.RegionGradient;

namespace Tekukae.TextureColorEngine.Tests
{
    public sealed class RegionGradientTests
    {
        [TestCase(230, 90, 120)]
        [TestCase(35, 60, 115)]
        [TestCase(190, 175, 150)]
        [TestCase(80, 80, 80)]
        public void PerceptualColor_RoundTripsSrgbWithinQuantization(int r, int g, int b)
        {
            Color32 input = new Color32((byte)r, (byte)g, (byte)b, 173);
            OklabColor lab = RegionGradientColorMath.ToOklab(input);
            OklchColor lch = RegionGradientColorMath.ToOklch(lab);
            Color32 output = RegionGradientColorMath.ToSrgb(lch, input.a);
            Assert.That(Mathf.Abs(output.r - input.r), Is.LessThanOrEqualTo(1));
            Assert.That(Mathf.Abs(output.g - input.g), Is.LessThanOrEqualTo(1));
            Assert.That(Mathf.Abs(output.b - input.b), Is.LessThanOrEqualTo(1));
            Assert.AreEqual(input.a, output.a);
        }

        [Test]
        public void HueInterpolation_UsesShortestPathAcrossZero()
        {
            OklchColor a = new OklchColor(0.7f, 0.1f, 350f);
            OklchColor b = new OklchColor(0.7f, 0.1f, 10f);
            OklchColor middle = RegionGradientColorMath.Lerp(a, b, 0.5f);
            Assert.That(Mathf.Abs(RegionGradientColorMath.HueDelta(0f, middle.H)), Is.LessThan(0.01f));
        }

        [Test]
        public void RegionSelection_StaysInsideConnectedColorRegion()
        {
            const int width = 6;
            const int height = 4;
            Color32[] pixels = new Color32[width * height];
            for (int y = 0; y < height; y++)
            for (int x = 0; x < width; x++)
                pixels[y * width + x] = x < 3 ? new Color32(170, 85, 95, 255) : new Color32(35, 40, 45, 255);

            byte[] mask = RegionSelectionEngine.Select(pixels, width, height, 0, 0, 0.40f, 0.75f, pixels.Length);
            int selectedLeft = 0;
            int selectedRight = 0;
            for (int y = 0; y < height; y++)
            for (int x = 0; x < width; x++)
                if (mask[y * width + x] > 0)
                {
                    if (x < 3) selectedLeft++; else selectedRight++;
                }
            Assert.That(selectedLeft, Is.GreaterThan(0));
            Assert.AreEqual(0, selectedRight);
        }

        [Test]
        public void GradientProcessor_PreservesUnselectedPixelsAndAlpha()
        {
            const int width = 8;
            const int height = 8;
            Color32[] source = new Color32[width * height];
            byte[] mask = new byte[source.Length];
            for (int y = 0; y < height; y++)
            for (int x = 0; x < width; x++)
            {
                int index = y * width + x;
                source[index] = new Color32((byte)(80 + y * 10), (byte)(90 + x * 5), 120, (byte)(200 + (x % 3) * 20));
                if (x < 4) mask[index] = 255;
            }
            var settings = new RegionGradientSettings
            {
                FeatherPixels = 0,
                OriginalGradientRetention = 0.6f,
                ShadingRetention = 0.8f,
                BrightnessRetention = 0.7f,
                SaturationRetention = 0.7f,
                PositionX = 0.5f,
                PositionY = 0.5f,
                Scale = 1f,
                AngleDegrees = 90f
            };
            RegionGradientResult result = RegionGradientProcessor.Apply(source, width, height, mask, null, settings);
            for (int i = 0; i < source.Length; i++)
            {
                Assert.AreEqual(source[i].a, result.Pixels[i].a, "Alpha changed at pixel " + i);
                if (mask[i] == 0)
                {
                    Assert.AreEqual(source[i], result.Pixels[i], "Unselected pixel changed at " + i);
                }
            }
        }

        [Test]
        public void GradientProcessor_MultipleRegionsKeepMasksAndSettingsIndependent()
        {
            const int width = 16;
            const int height = 16;
            Color32[] source = new Color32[width * height];
            byte[] leftMask = new byte[source.Length];
            byte[] rightMask = new byte[source.Length];
            for (int y = 0; y < height; y++)
            for (int x = 0; x < width; x++)
            {
                int index = y * width + x;
                source[index] = new Color32(128, 128, 128, 255);
                if (x < width / 2) leftMask[index] = 255;
                else rightMask[index] = 255;
            }

            var horizontal = new RegionGradientSettings
            {
                StartColor = new OklchColor(0.66f, 0.19f, 20f),
                MiddleColor = new OklchColor(0.66f, 0.19f, 85f),
                EndColor = new OklchColor(0.66f, 0.19f, 150f),
                PositionX = 0.25f, PositionY = 0.5f, AngleDegrees = 0f, Scale = 0.5f,
                OriginalGradientRetention = 0f, ShadingRetention = 0f,
                BrightnessRetention = 0f, SaturationRetention = 0f, FeatherPixels = 0
            };
            var vertical = new RegionGradientSettings
            {
                StartColor = new OklchColor(0.66f, 0.19f, 220f),
                MiddleColor = new OklchColor(0.66f, 0.19f, 270f),
                EndColor = new OklchColor(0.66f, 0.19f, 320f),
                PositionX = 0.75f, PositionY = 0.25f, AngleDegrees = 90f, Scale = 0.5f,
                OriginalGradientRetention = 0f, ShadingRetention = 0f,
                BrightnessRetention = 0f, SaturationRetention = 0f, FeatherPixels = 0
            };

            RegionGradientResult first = RegionGradientProcessor.Apply(source, source, width, height, leftMask, null, horizontal);
            RegionGradientResult combined = RegionGradientProcessor.Apply(source, first.Pixels, width, height, rightMask, null, vertical);

            int leftA = 8 * width + 1;
            int leftB = 8 * width + 6;
            int rightA = 1 * width + 12;
            int rightB = 14 * width + 12;
            Assert.That(PerceptualDistance(first.Pixels[leftA], first.Pixels[leftB]), Is.GreaterThan(0.02f),
                "Horizontal Region should vary across X.");
            Assert.That(PerceptualDistance(combined.Pixels[rightA], combined.Pixels[rightB]), Is.GreaterThan(0.02f),
                "Vertical Region should vary across Y.");
            Assert.AreEqual(source[rightA], first.Pixels[rightA], "First Region must not touch the second Region's pixels.");
            Assert.AreEqual(first.Pixels[leftA], combined.Pixels[leftA], "Second Region must not touch the first Region's unselected pixels.");
            Assert.AreEqual(source[0].a, combined.Pixels[0].a, "Alpha must remain unchanged.");
        }

        [Test]
        public void GradientProcessor_LaterOverlappingRegionCompositesAfterEarlierRegion()
        {
            const int width = 8;
            const int height = 8;
            Color32[] source = new Color32[width * height];
            byte[] mask = new byte[source.Length];
            for (int i = 0; i < source.Length; i++)
            {
                source[i] = new Color32(120, 120, 120, 255);
                mask[i] = 255;
            }
            var warm = new RegionGradientSettings
            {
                StartColor = new OklchColor(0.68f, 0.20f, 25f),
                MiddleColor = new OklchColor(0.68f, 0.20f, 45f),
                EndColor = new OklchColor(0.68f, 0.20f, 65f),
                PositionX = 0.5f, PositionY = 0.5f, AngleDegrees = 0f, Scale = 1f,
                OriginalGradientRetention = 0f, ShadingRetention = 0f,
                BrightnessRetention = 0f, SaturationRetention = 0f, FeatherPixels = 0
            };
            var cool = new RegionGradientSettings
            {
                StartColor = new OklchColor(0.68f, 0.20f, 210f),
                MiddleColor = new OklchColor(0.68f, 0.20f, 250f),
                EndColor = new OklchColor(0.68f, 0.20f, 290f),
                PositionX = 0.5f, PositionY = 0.5f, AngleDegrees = 90f, Scale = 1f,
                OriginalGradientRetention = 0f, ShadingRetention = 0f,
                BrightnessRetention = 0f, SaturationRetention = 0f, FeatherPixels = 0
            };

            RegionGradientResult warmThenCool = RegionGradientProcessor.Apply(source,
                RegionGradientProcessor.Apply(source, source, width, height, mask, null, warm).Pixels,
                width, height, mask, null, cool);
            RegionGradientResult coolThenWarm = RegionGradientProcessor.Apply(source,
                RegionGradientProcessor.Apply(source, source, width, height, mask, null, cool).Pixels,
                width, height, mask, null, warm);

            int sample = 4 * width + 4;
            Assert.That(PerceptualDistance(warmThenCool.Pixels[sample], coolThenWarm.Pixels[sample]), Is.GreaterThan(0.05f),
                "Changing Region order should change pixels where the selection masks overlap.");
        }

        private static float PerceptualDistance(Color32 a, Color32 b)
        {
            OklabColor labA = RegionGradientColorMath.ToOklab(a);
            OklabColor labB = RegionGradientColorMath.ToOklab(b);
            float dl = labA.L - labB.L;
            float da = labA.A - labB.A;
            float db = labA.B - labB.B;
            return Mathf.Sqrt(dl * dl + da * da + db * db);
        }

        [Test]
        public void Feather_ReturnsCopyWhenRadiusIsZero()
        {
            byte[] source = { 0, 255, 0, 255 };
            byte[] result = RegionSelectionEngine.Feather(source, 2, 2, 0);
            Assert.AreNotSame(source, result);
            CollectionAssert.AreEqual(source, result);
        }
    }
}
