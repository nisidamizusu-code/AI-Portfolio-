using NUnit.Framework;

namespace Tekukae.TextureColorEngine.Tests
{
    public sealed class TextureColorEngineTests
    {
        [Test]
        public void SingleColor_PreservesTransparentPixelsAndAlpha()
        {
            Rgba32[] pixels =
            {
                new Rgba32(170, 60, 45, 255),
                new Rgba32(170, 60, 45, 0),
                new Rgba32(130, 45, 35, 128),
                new Rgba32(20, 20, 20, 255)
            };
            TexturePixels image = new TexturePixels(2, 2, pixels, true);
            RecolorResult result = TextureColorEngine.RecolorSingle(image, 0, 0, new Rgba32(45, 90, 180, 255));

            Assert.AreEqual(0, result.Image.Pixels[1].A);
            Assert.AreEqual(128, result.Image.Pixels[2].A);
            Assert.AreEqual(pixels[1].R, result.Image.Pixels[1].R);
            Assert.AreEqual(pixels[1].G, result.Image.Pixels[1].G);
            Assert.AreEqual(pixels[1].B, result.Image.Pixels[1].B);
        }

        [Test]
        public void SingleColor_UsesColorFamilyAndRejectsNeutralBlack()
        {
            const int width = 64;
            const int height = 32;
            Rgba32[] pixels = new Rgba32[width * height];
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    if (x < 40)
                    {
                        float l = 0.28f + (y / (float)(height - 1)) * 0.46f;
                        float c = 0.075f + (y / (float)(height - 1)) * 0.045f;
                        float h = 250f + (y % 5 - 2) * 1.3f;
                        pixels[y * width + x] = ColorMath.ToSrgb(new Oklch(l, c, h), 255);
                    }
                    else if (x < 52)
                    {
                        pixels[y * width + x] = new Rgba32(8, 8, 10, 255);
                    }
                    else
                    {
                        pixels[y * width + x] = new Rgba32(130, 130, 130, 255);
                    }
                }
            }

            TexturePixels image = new TexturePixels(width, height, pixels, true);
            RecolorResult result = TextureColorEngine.RecolorSingle(image, 5, 15, new Rgba32(180, 45, 60, 255));

            Assert.Greater(result.MatchedPixels, 0);
            Assert.AreEqual(pixels[15 * width + 45].R, result.Image.Pixels[15 * width + 45].R);
            Assert.AreEqual(pixels[15 * width + 45].G, result.Image.Pixels[15 * width + 45].G);
            Assert.AreEqual(pixels[15 * width + 45].B, result.Image.Pixels[15 * width + 45].B);
            Assert.AreEqual(pixels[15 * width + 58].R, result.Image.Pixels[15 * width + 58].R);
        }

        [Test]
        public void TwoPointFlow_MapsBothEndpointsAndKeepsNeutralBlackOut()
        {
            const int width = 32;
            Rgba32[] pixels = new Rgba32[width];
            for (int x = 0; x < 20; x++)
            {
                float t = x / 19f;
                pixels[x] = ColorMath.ToSrgb(new Oklch(0.30f + 0.40f * t, 0.10f - 0.025f * t, 248f - 3f * t), 255);
            }
            for (int x = 20; x < width; x++) pixels[x] = new Rgba32(5, 5, 6, 255);

            TexturePixels image = new TexturePixels(width, 1, pixels, true);
            Rgba32 targetStart = new Rgba32(40, 70, 150, 255);
            Rgba32 targetEnd = new Rgba32(100, 160, 220, 255);
            RecolorResult result = TextureColorEngine.RecolorTwoPoint(image, 0, 0, 19, 0, targetStart, targetEnd);

            Assert.Greater(result.MatchedPixels, 0);
            Assert.AreEqual(pixels[25].R, result.Image.Pixels[25].R);
            Assert.AreEqual(pixels[25].G, result.Image.Pixels[25].G);
            Assert.AreEqual(pixels[25].B, result.Image.Pixels[25].B);
            Assert.AreEqual(targetStart.R, result.Image.Pixels[0].R);
            Assert.AreEqual(targetStart.G, result.Image.Pixels[0].G);
            Assert.AreEqual(targetStart.B, result.Image.Pixels[0].B);
            Assert.AreEqual(targetEnd.R, result.Image.Pixels[19].R);
            Assert.AreEqual(targetEnd.G, result.Image.Pixels[19].G);
            Assert.AreEqual(targetEnd.B, result.Image.Pixels[19].B);
        }




        [Test]
        public void TwoPointFlow_NearNeutralAnchorsDoNotUseUnstableHueToSelectWarmPixels()
        {
            Rgba32 nearWhite = new Rgba32(245, 244, 244, 255);
            Rgba32 warmGray = new Rgba32(201, 196, 192, 255);
            Oklab startLab = ColorMath.ToOklab(nearWhite);
            Oklab endLab = ColorMath.ToOklab(warmGray);
            Rgba32 neutralMiddle = ColorMath.ToSrgb(
                ColorMath.ToOklch(Oklab.Lerp(startLab, endLab, 0.5f)), 255);
            float middleLightness = ColorMath.ToOklab(neutralMiddle).L;
            Rgba32 warmDistractor = ColorMath.ToSrgb(
                new Oklch(middleLightness, 0.06f, 35f), 255);
            Rgba32 subtleNeutralVariation = ColorMath.ToSrgb(
                new Oklch(middleLightness, 0.014f, 55f), 255);

            TexturePixels image = new TexturePixels(5, 1, new[]
            {
                nearWhite,
                neutralMiddle,
                warmGray,
                warmDistractor,
                subtleNeutralVariation
            }, true);

            RecolorResult result = TextureColorEngine.RecolorTwoPoint(
                image, 0, 0, 2, 0,
                new Rgba32(64, 115, 184, 255),
                new Rgba32(115, 174, 221, 255));

            // The neutral gradient between the two selected anchors should be recolored.
            Assert.AreNotEqual(neutralMiddle.R, result.Image.Pixels[1].R);
            Assert.AreNotEqual(neutralMiddle.G, result.Image.Pixels[1].G);
            Assert.AreNotEqual(neutralMiddle.B, result.Image.Pixels[1].B);

            // This warm pixel has a hue inside the anchors' numerical hue interval and
            // matching lightness, but it is not part of the almost-neutral source flow.
            Assert.AreEqual(warmDistractor.R, result.Image.Pixels[3].R);
            Assert.AreEqual(warmDistractor.G, result.Image.Pixels[3].G);
            Assert.AreEqual(warmDistractor.B, result.Image.Pixels[3].B);

            // A subtle low-chroma material variation should still receive partial recoloring.
            Assert.AreNotEqual(subtleNeutralVariation.R, result.Image.Pixels[4].R);
            Assert.AreNotEqual(subtleNeutralVariation.G, result.Image.Pixels[4].G);
            Assert.AreNotEqual(subtleNeutralVariation.B, result.Image.Pixels[4].B);
        }

        [Test]
        public void SingleColor_NeutralWhiteToGrayGradientRemainsSelected()
        {
            Rgba32 white = new Rgba32(253, 253, 253, 255);
            Rgba32 warmGray = new Rgba32(201, 196, 192, 255);
            Oklab start = ColorMath.ToOklab(white);
            Oklab end = ColorMath.ToOklab(warmGray);
            const int gradientCount = 31;
            Rgba32[] pixels = new Rgba32[gradientCount + 2];

            for (int i = 0; i < gradientCount; i++)
            {
                float t = i / (float)(gradientCount - 1);
                pixels[i] = ColorMath.ToSrgb(ColorMath.ToOklch(Oklab.Lerp(start, end, t)), 255);
            }

            float middleL = ColorMath.ToOklab(pixels[gradientCount / 2]).L;
            Rgba32 vividWarmDistractor = ColorMath.ToSrgb(new Oklch(middleL, 0.06f, 35f), 255);
            Rgba32 farDarkNeutral = new Rgba32(45, 45, 45, 255);
            pixels[gradientCount] = vividWarmDistractor;
            pixels[gradientCount + 1] = farDarkNeutral;

            TexturePixels image = new TexturePixels(gradientCount + 2, 1, pixels, true);
            RecolorResult result = TextureColorEngine.RecolorSingle(
                image, 0, 0, new Rgba32(64, 115, 184, 255));

            // Both the bright and shaded ends of the same neutral gradient should convert.
            Assert.AreNotEqual(white.R, result.Image.Pixels[0].R);
            Assert.AreNotEqual(warmGray.R, result.Image.Pixels[gradientCount - 1].R);
            Assert.GreaterOrEqual(result.MatchedPixels, gradientCount - 1);

            // A vivid warm pixel and a far darker neutral object remain outside the selection.
            Assert.AreEqual(vividWarmDistractor.R, result.Image.Pixels[gradientCount].R);
            Assert.AreEqual(vividWarmDistractor.G, result.Image.Pixels[gradientCount].G);
            Assert.AreEqual(vividWarmDistractor.B, result.Image.Pixels[gradientCount].B);
            Assert.AreEqual(farDarkNeutral.R, result.Image.Pixels[gradientCount + 1].R);
            Assert.AreEqual(farDarkNeutral.G, result.Image.Pixels[gradientCount + 1].G);
            Assert.AreEqual(farDarkNeutral.B, result.Image.Pixels[gradientCount + 1].B);
        }

        [Test]
        public void TwoPointFlow_NeutralGradientWithSubtleTintVariationAvoidsPatchyPartialSelection()
        {
            Rgba32 white = new Rgba32(245, 244, 244, 255);
            Rgba32 warmGray = new Rgba32(201, 196, 192, 255);
            Oklab start = ColorMath.ToOklab(white);
            Oklab end = ColorMath.ToOklab(warmGray);
            const int gradientCount = 21;
            Rgba32[] pixels = new Rgba32[gradientCount + 1];

            for (int i = 0; i < gradientCount; i++)
            {
                float t = i / (float)(gradientCount - 1);
                Oklab point = Oklab.Lerp(start, end, t);
                float tint = (float)System.Math.Sin(t * System.Math.PI) * 0.014f;
                point.A += tint * 0.8f;
                point.B += tint * 0.6f;
                pixels[i] = ColorMath.ToSrgb(ColorMath.ToOklch(point), 255);
            }

            float middleL = ColorMath.ToOklab(pixels[gradientCount / 2]).L;
            pixels[gradientCount] = ColorMath.ToSrgb(new Oklch(middleL, 0.06f, 35f), 255);
            Rgba32 vividWarmDistractor = pixels[gradientCount];

            TexturePixels image = new TexturePixels(gradientCount + 1, 1, pixels, true);
            RecolorResult result = TextureColorEngine.RecolorTwoPoint(
                image, 0, 0, gradientCount - 1, 0,
                new Rgba32(64, 115, 184, 255),
                new Rgba32(115, 174, 221, 255));

            // Most subtly tinted pixels along the same neutral gradient should be fully applied,
            // rather than forming a checker of full/partial conversions.
            Assert.GreaterOrEqual(result.MatchedPixels, gradientCount - 2);
            Assert.AreEqual(vividWarmDistractor.R, result.Image.Pixels[gradientCount].R);
            Assert.AreEqual(vividWarmDistractor.G, result.Image.Pixels[gradientCount].G);
            Assert.AreEqual(vividWarmDistractor.B, result.Image.Pixels[gradientCount].B);
        }

        [Test]
        public void TwoPointFlow_UsesUnifiedPerceptualProgressForSmoothGradient()
        {
            const int width = 17;
            Rgba32[] pixels = new Rgba32[width];
            Oklab sourceStart = ColorMath.ToOklab(ColorMath.ToSrgb(new Oklch(0.36f, 0.10f, 28f), 255));
            Oklab sourceEnd = ColorMath.ToOklab(ColorMath.ToSrgb(new Oklch(0.72f, 0.15f, 96f), 255));

            for (int x = 0; x < width; x++)
            {
                float t = x / (float)(width - 1);
                pixels[x] = ColorMath.ToSrgb(ColorMath.ToOklch(Oklab.Lerp(sourceStart, sourceEnd, t)), 255);
            }

            Rgba32 targetStartColor = new Rgba32(43, 91, 151, 255);
            Rgba32 targetEndColor = new Rgba32(179, 126, 184, 255);
            Oklab targetStart = ColorMath.ToOklab(targetStartColor);
            Oklab targetEnd = ColorMath.ToOklab(targetEndColor);
            TexturePixels image = new TexturePixels(width, 1, pixels, true);

            RecolorResult result = TextureColorEngine.RecolorTwoPoint(
                image, 0, 0, width - 1, 0, targetStartColor, targetEndColor);

            for (int x = 1; x < width - 1; x++)
            {
                float t = x / (float)(width - 1);
                Oklab expected = Oklab.Lerp(targetStart, targetEnd, t);
                Oklab actual = ColorMath.ToOklab(result.Image.Pixels[x]);
                float dl = actual.L - expected.L;
                float da = actual.A - expected.A;
                float db = actual.B - expected.B;
                float error = (float)System.Math.Sqrt(dl * dl + da * da + db * db);
                Assert.Less(error, 0.018f, "Unexpected color-flow deviation at x=" + x);
            }

            Assert.AreEqual(targetStartColor.R, result.Image.Pixels[0].R);
            Assert.AreEqual(targetEndColor.R, result.Image.Pixels[width - 1].R);
        }

        [Test]
        public void TwoPointFlow_UsesBothHueEndpointsAcrossWrapAround()
        {
            const int width = 41;
            Rgba32[] pixels = new Rgba32[width];
            for (int x = 0; x < width; x++)
            {
                float t = x / (float)(width - 1);
                float hue = ColorMath.NormalizeHue(350f + 50f * t);
                pixels[x] = ColorMath.ToSrgb(new Oklch(0.58f, 0.12f, hue), 255);
            }
            TexturePixels image = new TexturePixels(width, 1, pixels, true);
            Rgba32 targetStart = new Rgba32(35, 130, 155, 255);
            Rgba32 targetEnd = new Rgba32(50, 150, 85, 255);

            RecolorResult result = TextureColorEngine.RecolorTwoPoint(
                image, 0, 0, width - 1, 0, targetStart, targetEnd);

            Assert.AreEqual(targetStart.R, result.Image.Pixels[0].R);
            Assert.AreEqual(targetStart.G, result.Image.Pixels[0].G);
            Assert.AreEqual(targetStart.B, result.Image.Pixels[0].B);
            Assert.AreEqual(targetEnd.R, result.Image.Pixels[width - 1].R);
            Assert.AreEqual(targetEnd.G, result.Image.Pixels[width - 1].G);
            Assert.AreEqual(targetEnd.B, result.Image.Pixels[width - 1].B);
            Assert.Greater(result.MatchedPixels, 0);
        }


        [Test]
        public void SingleColor_IncludesMutedDarkMaterialButRejectsNearBlack()
        {
            const int width = 32;
            Rgba32[] pixels = new Rgba32[width];
            for (int x = 0; x < 28; x++)
            {
                float t = x / 27f;
                float lightness = 0.22f + t * 0.5f;
                float chroma = 0.018f + t * 0.082f;
                pixels[x] = ColorMath.ToSrgb(new Oklch(lightness, chroma, 255f), 255);
            }
            pixels[28] = ColorMath.ToSrgb(new Oklch(0.22f, 0.002f, 0f), 255);
            pixels[29] = ColorMath.ToSrgb(new Oklch(0.35f, 0.004f, 0f), 255);
            pixels[30] = new Rgba32(95, 95, 95, 255);
            pixels[31] = new Rgba32(0, 0, 0, 255);

            TexturePixels image = new TexturePixels(width, 1, pixels, true);
            RecolorResult result = TextureColorEngine.RecolorSingle(image, 12, 0, new Rgba32(180, 70, 50, 255));

            Assert.Greater(result.MatchedPixels, 10);
            for (int x = 28; x < width; x++)
            {
                Assert.AreEqual(pixels[x].R, result.Image.Pixels[x].R, "Neutral pixel was recolored at x=" + x);
                Assert.AreEqual(pixels[x].G, result.Image.Pixels[x].G, "Neutral pixel was recolored at x=" + x);
                Assert.AreEqual(pixels[x].B, result.Image.Pixels[x].B, "Neutral pixel was recolored at x=" + x);
            }
        }

        [Test]
        public void TwoPointFlow_RejectsPixelsOutsideHueArcAndNeutralBlack()
        {
            const int width = 24;
            Rgba32[] pixels = new Rgba32[width];
            for (int x = 0; x < 21; x++)
            {
                float t = x / 20f;
                pixels[x] = ColorMath.ToSrgb(new Oklch(0.58f, 0.12f, ColorMath.NormalizeHue(350f + 50f * t)), 255);
            }
            pixels[21] = ColorMath.ToSrgb(new Oklch(0.58f, 0.12f, 180f), 255);
            pixels[22] = ColorMath.ToSrgb(new Oklch(0.58f, 0.003f, 0f), 255);
            pixels[23] = new Rgba32(110, 110, 110, 255);

            TexturePixels image = new TexturePixels(width, 1, pixels, true);
            RecolorResult result = TextureColorEngine.RecolorTwoPoint(
                image, 0, 0, 20, 0, new Rgba32(35, 130, 155, 255), new Rgba32(50, 150, 85, 255));

            for (int x = 21; x < width; x++)
            {
                Assert.AreEqual(pixels[x].R, result.Image.Pixels[x].R, "Out-of-family pixel recolored at x=" + x);
                Assert.AreEqual(pixels[x].G, result.Image.Pixels[x].G, "Out-of-family pixel recolored at x=" + x);
                Assert.AreEqual(pixels[x].B, result.Image.Pixels[x].B, "Out-of-family pixel recolored at x=" + x);
            }
        }

        [Test]
        public void TwoPointFlow_RejectsInvalidStartCoordinate()
        {
            TexturePixels image = new TexturePixels(2, 1, new[]
            {
                new Rgba32(170, 60, 45, 255),
                new Rgba32(130, 45, 35, 255)
            }, true);
            Assert.Throws<System.ArgumentOutOfRangeException>(() => TextureColorEngine.RecolorTwoPoint(
                image, -1, 0, 1, 0, new Rgba32(20, 80, 150, 255), new Rgba32(40, 100, 170, 255)));
        }

        [Test]
        public void GamutMapping_ReturnsValidByteRange()
        {
            Rgba32 result = ColorMath.ToSrgb(new Oklch(0.62f, 0.6f, 32f), 255);
            Assert.AreEqual(255, result.A);
            Assert.That(result.R, Is.InRange(0, 255));
            Assert.That(result.G, Is.InRange(0, 255));
            Assert.That(result.B, Is.InRange(0, 255));
        }

        private static float ColorDifference(Rgba32 a, Rgba32 b)
        {
            Oklab la = ColorMath.ToOklab(a);
            Oklab lb = ColorMath.ToOklab(b);
            float dl = la.L - lb.L;
            float da = la.A - lb.A;
            float db = la.B - lb.B;
            return (float)System.Math.Sqrt(dl * dl + da * da + db * db) * 255f;
        }
    }
}
