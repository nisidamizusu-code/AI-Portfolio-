using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace FolderMikke.ProjectFileColorizer
{
    /// <summary>
    /// Stores user-assigned asset colors separately from the legacy extension-based colors.
    /// The asset itself is never modified; tags are keyed by Unity asset GUID.
    /// </summary>
    [InitializeOnLoad]
    internal static class FolderMikkeColorTags
    {
        private const int CurrentDataVersion = 1;
        private const string SettingsFileName = "FolderMikke.ManualTags.json";
        private const string LegacySettingsFileName = "UnityAssist.ProjectFileColorizer.ManualTags.json";
        private static readonly Dictionary<string, Color> ColorsByGuid = new Dictionary<string, Color>();
        private static bool loaded;
        private static bool loadFailed;
        private static string lastError;

        internal static event Action TagsChanged;

        [Serializable]
        private sealed class SettingsData
        {
            public int version = CurrentDataVersion;
            public List<SettingsEntry> entries = new List<SettingsEntry>();
        }

        [Serializable]
        private sealed class SettingsEntry
        {
            public string guid;
            public Color color;
        }

        internal struct PaletteEntry
        {
            internal readonly string Name;
            internal readonly Color Color;

            internal PaletteEntry(string name, Color color)
            {
                Name = name;
                Color = color;
            }
        }

        // Fixed palette: all manually tagged assets converge on one of these 18 exact colors.
        // This prevents near-identical custom colors from fragmenting the color groups.
        private static readonly PaletteEntry[] Palette =
        {
            new PaletteEntry("ターコイズ", new Color32(47, 188, 178, 255)),
            new PaletteEntry("レッド", new Color32(213, 91, 91, 255)),
            new PaletteEntry("ピンク", new Color32(244, 157, 188, 255)),
            new PaletteEntry("マゼンタ", new Color32(187, 48, 125, 255)),
            new PaletteEntry("パープル", new Color32(153, 113, 202, 255)),
            new PaletteEntry("ネイビー", new Color32(39, 55, 92, 255)),
            new PaletteEntry("ブルー", new Color32(63, 136, 216, 255)),
            new PaletteEntry("スカイブルー", new Color32(119, 190, 235, 255)),
            new PaletteEntry("シアン", new Color32(66, 191, 212, 255)),
            new PaletteEntry("グリーン", new Color32(85, 175, 112, 255)),
            new PaletteEntry("ライム", new Color32(171, 205, 55, 255)),
            new PaletteEntry("イエロー", new Color32(230, 190, 70, 255)),
            new PaletteEntry("オレンジ", new Color32(225, 138, 64, 255)),
            new PaletteEntry("ブラウン", new Color32(133, 80, 46, 255)),
            new PaletteEntry("ベージュ", new Color32(216, 192, 144, 255)),
            new PaletteEntry("グレー", new Color32(135, 145, 155, 255)),
            new PaletteEntry("ブラック", new Color32(55, 55, 55, 255)),
            new PaletteEntry("ホワイト", new Color32(235, 235, 235, 255))
        };

        static FolderMikkeColorTags()
        {
            Load();
        }

        internal static string LastError
        {
            get
            {
                EnsureLoaded();
                return lastError;
            }
        }

        internal static bool HasLoadError
        {
            get
            {
                EnsureLoaded();
                return loadFailed;
            }
        }

        internal static PaletteEntry[] GetPalette()
        {
            var copy = new PaletteEntry[Palette.Length];
            Array.Copy(Palette, copy, Palette.Length);
            return copy;
        }

        internal static bool TryGetColor(string guid, out Color color)
        {
            EnsureLoaded();
            if (string.IsNullOrEmpty(guid))
            {
                color = Color.white;
                return false;
            }
            return ColorsByGuid.TryGetValue(guid, out color);
        }

        internal static Dictionary<string, Color> GetSnapshot()
        {
            EnsureLoaded();
            return new Dictionary<string, Color>(ColorsByGuid);
        }

        internal static string GetColorName(Color color)
        {
            var normalized = NormalizeColor(color);
            for (var i = 0; i < Palette.Length; i++)
            {
                if (ToColorKey(Palette[i].Color) == ToColorKey(normalized))
                {
                    return Palette[i].Name;
                }
            }

            return "ホワイト";
        }

        internal static string ToColorKey(Color color)
        {
            return ColorUtility.ToHtmlStringRGBA((Color32)color);
        }

        internal static string[] GetSelectedGuids()
        {
            // Selection.assetGUIDs is the Project-window-specific API and also handles
            // folders selected in the first column of the two-column Project Browser.
            var selectedGuids = Selection.assetGUIDs;
            if (selectedGuids == null || selectedGuids.Length == 0)
            {
                return new string[0];
            }

            var guids = new List<string>(selectedGuids.Length);
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var guid in selectedGuids)
            {
                if (!string.IsNullOrEmpty(guid) && seen.Add(guid))
                {
                    guids.Add(guid);
                }
            }

            return guids.ToArray();
        }

        internal static bool SetColors(string[] guids, Color color)
        {
            EnsureLoaded();
            if (loadFailed)
            {
                lastError = "手動カラー設定ファイルを読み込めないため、上書きを防止しました。設定ファイルを確認してください。";
                Debug.LogError("[ふぉるだーみっけ] " + lastError);
                return false;
            }

            if (guids == null || guids.Length == 0)
            {
                lastError = "色を設定するアセットが選択されていません。";
                return false;
            }

            var normalizedColor = NormalizeColor(color);
            var updated = new Dictionary<string, Color>(ColorsByGuid);
            foreach (var guid in guids)
            {
                if (!string.IsNullOrEmpty(guid))
                {
                    updated[guid] = normalizedColor;
                }
            }

            return Save(updated);
        }

        internal static bool RemoveColors(string[] guids)
        {
            EnsureLoaded();
            if (loadFailed)
            {
                lastError = "手動カラー設定ファイルを読み込めないため、変更を中止しました。設定ファイルを確認してください。";
                Debug.LogError("[ふぉるだーみっけ] " + lastError);
                return false;
            }

            if (guids == null || guids.Length == 0)
            {
                return false;
            }

            var updated = new Dictionary<string, Color>(ColorsByGuid);
            var changed = false;
            foreach (var guid in guids)
            {
                if (!string.IsNullOrEmpty(guid))
                {
                    changed |= updated.Remove(guid);
                }
            }

            return !changed || Save(updated);
        }

        internal static bool RemoveColor(string guid)
        {
            return RemoveColors(new[] { guid });
        }

        internal static void OpenColorGroups()
        {
            EditorWindow.GetWindow<FolderMikkeColorGroupsWindow>("ふぉるだーみっけ - 色別一覧");
        }

        internal static void OpenPaletteWindow()
        {
            var guids = GetSelectedGuids();
            if (guids.Length == 0)
            {
                Debug.LogWarning("[ふぉるだーみっけ] プロジェクトウィンドウでアセットを選択してから実行してください。");
                return;
            }

            var window = EditorWindow.GetWindow<FolderMikkeColorPickerWindow>(true, "ふぉるだーみっけ - 色を選択", true);
            window.SetTargets(guids);
            window.minSize = new Vector2(390f, 350f);
        }

        private static void EnsureLoaded()
        {
            if (!loaded)
            {
                Load();
            }
        }

        private static void Load()
        {
            loaded = true;
            loadFailed = false;
            lastError = null;
            ColorsByGuid.Clear();

            string path = null;
            string backupPath = null;
            try
            {
                path = GetSettingsPath();
                backupPath = path + ".backup";
                MigrateLegacySettingsFile(path, backupPath);

                // If the Editor was interrupted between replacing files, recover the last known-good copy.
                if (!File.Exists(path) && File.Exists(backupPath))
                {
                    File.Copy(backupPath, path, true);
                }

                if (!File.Exists(path))
                {
                    return;
                }

                SettingsData data;
                try
                {
                    data = ReadSettings(path);
                }
                catch (Exception primaryException)
                {
                    if (!File.Exists(backupPath))
                    {
                        throw;
                    }

                    data = ReadSettings(backupPath);
                    File.Copy(backupPath, path, true);
                    Debug.LogWarning(
                        "[ふぉるだーみっけ] 手動カラー設定の破損を検出したため、バックアップから復旧しました。\n" +
                        primaryException.Message);
                }

                foreach (var entry in data.entries)
                {
                    if (entry == null || string.IsNullOrEmpty(entry.guid))
                    {
                        continue;
                    }

                    ColorsByGuid[entry.guid] = NormalizeColor(entry.color);
                }
            }
            catch (Exception exception)
            {
                loadFailed = true;
                lastError = "手動カラー設定を読み込めませんでした。既存ファイルを上書きしないよう、変更を停止しました。";
                Debug.LogError("[ふぉるだーみっけ] " + lastError + "\n" + exception);
            }
        }

        private static SettingsData ReadSettings(string path)
        {
            var json = File.ReadAllText(path, Encoding.UTF8);
            var data = JsonUtility.FromJson<SettingsData>(json);
            if (data == null || data.version != CurrentDataVersion || data.entries == null)
            {
                throw new InvalidDataException("設定ファイルの形式またはバージョンが不正です。");
            }

            return data;
        }

        private static bool SettingsMatch(SettingsData actual, SettingsData expected)
        {
            if (actual == null || expected == null || actual.entries == null || expected.entries == null ||
                actual.entries.Count != expected.entries.Count)
            {
                return false;
            }

            var actualByGuid = new Dictionary<string, Color>(StringComparer.OrdinalIgnoreCase);
            foreach (var entry in actual.entries)
            {
                if (entry == null || string.IsNullOrEmpty(entry.guid) || actualByGuid.ContainsKey(entry.guid))
                {
                    return false;
                }
                actualByGuid.Add(entry.guid, NormalizeColor(entry.color));
            }

            foreach (var entry in expected.entries)
            {
                if (entry == null || string.IsNullOrEmpty(entry.guid))
                {
                    return false;
                }

                Color actualColor;
                if (!actualByGuid.TryGetValue(entry.guid, out actualColor))
                {
                    return false;
                }

                var expectedColor = NormalizeColor(entry.color);
                if (!Mathf.Approximately(actualColor.r, expectedColor.r) ||
                    !Mathf.Approximately(actualColor.g, expectedColor.g) ||
                    !Mathf.Approximately(actualColor.b, expectedColor.b) ||
                    !Mathf.Approximately(actualColor.a, expectedColor.a))
                {
                    return false;
                }
            }

            return true;
        }

        private static bool Save(Dictionary<string, Color> updated)
        {
            string path = null;
            string temporaryPath = null;
            string backupPath = null;
            var hadOriginal = false;
            var backupReady = false;

            try
            {
                path = GetSettingsPath();
                temporaryPath = path + ".tmp";
                backupPath = path + ".backup";
                hadOriginal = File.Exists(path);

                var data = new SettingsData();
                foreach (var pair in updated)
                {
                    data.entries.Add(new SettingsEntry { guid = pair.Key, color = pair.Value });
                }
                data.entries.Sort((left, right) => string.CompareOrdinal(left.guid, right.guid));

                var directory = Path.GetDirectoryName(path);
                if (!string.IsNullOrEmpty(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                // Write and validate a temporary file before touching the current settings.
                File.WriteAllText(temporaryPath, JsonUtility.ToJson(data, true), new UTF8Encoding(false));
                var temporaryData = ReadSettings(temporaryPath);
                if (!SettingsMatch(temporaryData, data))
                {
                    throw new InvalidDataException("一時設定ファイルの検証に失敗しました。");
                }

                // Keep the last known-good settings so a failed replacement can be rolled back.
                if (hadOriginal)
                {
                    File.Copy(path, backupPath, true);
                    backupReady = true;
                }

                // FileUtil.ReplaceFile is used only when a destination already exists.
                // For the first save, copy the validated temporary file to a new destination.
                if (hadOriginal)
                {
                    FileUtil.ReplaceFile(temporaryPath, path);
                }
                else
                {
                    File.Copy(temporaryPath, path);
                }

                var savedData = ReadSettings(path);
                if (!SettingsMatch(savedData, data))
                {
                    throw new InvalidDataException("保存後の設定ファイル検証に失敗しました。");
                }

                if (!hadOriginal)
                {
                    try
                    {
                        File.Copy(path, backupPath, true);
                    }
                    catch (Exception backupException)
                    {
                        Debug.LogWarning("[ふぉるだーみっけ] 初回保存後のバックアップ作成に失敗しました。設定本体は保存されています。\n" + backupException.Message);
                    }
                }

                if (File.Exists(temporaryPath))
                {
                    try
                    {
                        File.Delete(temporaryPath);
                    }
                    catch
                    {
                        // A stale temporary file is harmless; the validated destination is already saved.
                    }
                }

                ColorsByGuid.Clear();
                foreach (var pair in updated)
                {
                    ColorsByGuid.Add(pair.Key, pair.Value);
                }

                lastError = null;
                EditorApplication.RepaintProjectWindow();
                if (TagsChanged != null)
                {
                    try
                    {
                        TagsChanged();
                    }
                    catch (Exception callbackException)
                    {
                        Debug.LogException(callbackException);
                    }
                }

                return true;
            }
            catch (Exception exception)
            {
                // Restore the previous file if replacement or post-write validation failed.
                try
                {
                    if (backupReady && !string.IsNullOrEmpty(backupPath) && File.Exists(backupPath))
                    {
                        File.Copy(backupPath, path, true);
                    }
                    else if (!hadOriginal && !string.IsNullOrEmpty(path) && File.Exists(path))
                    {
                        File.Delete(path);
                    }
                }
                catch (Exception restoreException)
                {
                    Debug.LogError("[ふぉるだーみっけ] 手動カラー設定の復旧にも失敗しました。バックアップを保持しています。\n" + restoreException);
                }

                if (!string.IsNullOrEmpty(temporaryPath) && File.Exists(temporaryPath))
                {
                    try
                    {
                        File.Delete(temporaryPath);
                    }
                    catch
                    {
                        // Keep the original and backup files even if temporary-file cleanup fails.
                    }
                }

                lastError = "手動カラー設定を保存できませんでした。既存設定を復元し、今回の変更を取り消しました。";
                Debug.LogError("[ふぉるだーみっけ] " + lastError + "\n" + exception);
                return false;
            }
        }

        private static string GetSettingsPath()
        {
            var projectRoot = Directory.GetParent(Application.dataPath);
            if (projectRoot == null)
            {
                throw new DirectoryNotFoundException("Unityプロジェクトのルートを取得できません。");
            }

            return Path.Combine(projectRoot.FullName, "ProjectSettings", SettingsFileName);
        }

        private static void MigrateLegacySettingsFile(string newPath, string newBackupPath)
        {
            var projectRoot = Directory.GetParent(Application.dataPath);
            if (projectRoot == null) return;

            var legacyPath = Path.Combine(projectRoot.FullName, "ProjectSettings", LegacySettingsFileName);
            var legacyBackupPath = legacyPath + ".backup";

            // Copy, do not delete, the old file. This keeps a recoverable source until the user
            // confirms the migrated tags are present in the new version.
            if (!File.Exists(newPath) && File.Exists(legacyPath))
            {
                File.Copy(legacyPath, newPath, false);
            }
            if (!File.Exists(newBackupPath) && File.Exists(legacyBackupPath))
            {
                File.Copy(legacyBackupPath, newBackupPath, false);
            }
        }

        private static Color NormalizeColor(Color color)
        {
            if (float.IsNaN(color.r) || float.IsInfinity(color.r) ||
                float.IsNaN(color.g) || float.IsInfinity(color.g) ||
                float.IsNaN(color.b) || float.IsInfinity(color.b) ||
                float.IsNaN(color.a) || float.IsInfinity(color.a))
            {
                return Palette[Palette.Length - 1].Color;
            }

            // Older versions allowed arbitrary ColorField values. Snap those values to
            // the closest fixed swatch so visually similar colors share one group.
            var r = Mathf.Clamp01(color.r);
            var g = Mathf.Clamp01(color.g);
            var b = Mathf.Clamp01(color.b);
            var bestColor = Palette[0].Color;
            var bestDistance = float.MaxValue;

            for (var i = 0; i < Palette.Length; i++)
            {
                var candidate = Palette[i].Color;
                var dr = r - candidate.r;
                var dg = g - candidate.g;
                var db = b - candidate.b;
                // Weighted RGB distance gives green differences slightly more influence.
                var distance = 0.2126f * dr * dr + 0.7152f * dg * dg + 0.0722f * db * db;
                if (distance < bestDistance)
                {
                    bestDistance = distance;
                    bestColor = candidate;
                }
            }

            return bestColor;
        }

        [MenuItem("Assets/ふぉるだーみっけ/カラータグ/色を選択...", false, 120)]
        private static void SelectPaletteColor() { OpenPaletteWindow(); }

        [MenuItem("Assets/ふぉるだーみっけ/カラータグ/色を解除", false, 121)]
        private static void RemoveSelectedColor()
        {
            var guids = GetSelectedGuids();
            if (guids.Length == 0)
            {
                Debug.LogWarning("[ふぉるだーみっけ] プロジェクトウィンドウでアセットを選択してから実行してください。");
                return;
            }
            RemoveColors(guids);
        }
    }

    internal sealed class FolderMikkeColorPickerWindow : EditorWindow
    {
        private const int ColumnCount = 3;
        private string[] targetGuids = new string[0];

        internal void SetTargets(string[] guids)
        {
            targetGuids = guids ?? new string[0];
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("色を選択", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("対象: " + targetGuids.Length + " アセット", EditorStyles.miniLabel);
            EditorGUILayout.HelpBox(
                "固定パレットから色を選択します。同じ色を選んだアセットは、色別一覧で同じグループにまとまります。",
                MessageType.Info);
            EditorGUILayout.Space(4f);

            var palette = FolderMikkeColorTags.GetPalette();
            using (new EditorGUI.DisabledScope(targetGuids.Length == 0 || FolderMikkeColorTags.HasLoadError))
            {
                for (var row = 0; row < Mathf.CeilToInt(palette.Length / (float)ColumnCount); row++)
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        for (var column = 0; column < ColumnCount; column++)
                        {
                            var index = row * ColumnCount + column;
                            if (index >= palette.Length)
                            {
                                GUILayout.FlexibleSpace();
                                continue;
                            }

                            if (DrawPaletteButton(palette[index]))
                            {
                                if (FolderMikkeColorTags.SetColors(targetGuids, palette[index].Color))
                                {
                                    Close();
                                    GUIUtility.ExitGUI();
                                }
                            }
                        }
                    }
                }
            }

            if (!string.IsNullOrEmpty(FolderMikkeColorTags.LastError))
            {
                EditorGUILayout.HelpBox(FolderMikkeColorTags.LastError, MessageType.Error);
            }
        }

        private static bool DrawPaletteButton(FolderMikkeColorTags.PaletteEntry entry)
        {
            var rect = GUILayoutUtility.GetRect(104f, 34f, GUILayout.MinWidth(90f), GUILayout.ExpandWidth(true));
            var clicked = GUI.Button(rect, GUIContent.none, EditorStyles.helpBox);

            var swatch = new Rect(rect.x + 7f, rect.y + 8f, 18f, 18f);
            EditorGUI.DrawRect(swatch, entry.Color);
            var border = new Color(0f, 0f, 0f, 0.25f);
            EditorGUI.DrawRect(new Rect(swatch.x, swatch.y, swatch.width, 1f), border);
            EditorGUI.DrawRect(new Rect(swatch.x, swatch.yMax - 1f, swatch.width, 1f), border);
            EditorGUI.DrawRect(new Rect(swatch.x, swatch.y, 1f, swatch.height), border);
            EditorGUI.DrawRect(new Rect(swatch.xMax - 1f, swatch.y, 1f, swatch.height), border);

            var labelRect = new Rect(swatch.xMax + 7f, rect.y + 1f, rect.width - (swatch.width + 20f), rect.height - 2f);
            GUI.Label(labelRect, entry.Name, EditorStyles.label);
            return clicked;
        }
    }

    internal sealed class FolderMikkeColorGroupsWindow : EditorWindow
    {
        private sealed class AssetEntry
        {
            internal string Guid;
            internal string Path;
        }

        private sealed class ColorGroup
        {
            internal string Key;
            internal string Name;
            internal Color Color;
            internal readonly List<AssetEntry> Assets = new List<AssetEntry>();
            internal readonly List<AssetEntry> FilteredAssets = new List<AssetEntry>();
            internal bool Expanded;
        }

        private readonly List<ColorGroup> groups = new List<ColorGroup>();
        private Vector2 scrollPosition;
        private string searchText = string.Empty;

        private void OnEnable()
        {
            FolderMikkeColorTags.TagsChanged += RefreshGroups;
            EditorApplication.projectChanged += RefreshGroups;
            RefreshGroups();
        }

        private void OnDisable()
        {
            FolderMikkeColorTags.TagsChanged -= RefreshGroups;
            EditorApplication.projectChanged -= RefreshGroups;
        }

        private void OnGUI()
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                GUILayout.Label("色別アセット", EditorStyles.toolbarButton);
                GUILayout.FlexibleSpace();
                if (GUILayout.Button("更新", EditorStyles.toolbarButton, GUILayout.Width(48f)))
                {
                    RefreshGroups();
                }
            }

            EditorGUI.BeginChangeCheck();
            var nextSearchText = EditorGUILayout.TextField("検索", searchText ?? string.Empty);
            if (EditorGUI.EndChangeCheck())
            {
                searchText = nextSearchText;
                RefreshFilteredAssets();
            }
            EditorGUILayout.HelpBox("色を付けたアセットをグループ別に表示します。実際のファイルやフォルダは移動しません。", MessageType.Info);

            if (FolderMikkeColorTags.HasLoadError)
            {
                EditorGUILayout.HelpBox(FolderMikkeColorTags.LastError, MessageType.Error);
                return;
            }
            if (!string.IsNullOrEmpty(FolderMikkeColorTags.LastError))
            {
                EditorGUILayout.HelpBox(FolderMikkeColorTags.LastError, MessageType.Error);
            }

            scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);
            var visibleGroupCount = 0;
            foreach (var group in groups)
            {
                var matchingAssets = group.FilteredAssets;
                if (matchingAssets.Count == 0)
                {
                    continue;
                }

                visibleGroupCount++;
                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        var swatch = GUILayoutUtility.GetRect(16f, 16f, GUILayout.Width(16f), GUILayout.Height(16f));
                        EditorGUI.DrawRect(swatch, group.Color);
                        group.Expanded = EditorGUILayout.Foldout(
                            group.Expanded,
                            group.Name + "  (" + matchingAssets.Count + ")",
                            true);
                    }

                    if (group.Expanded || !string.IsNullOrEmpty(searchText))
                    {
                        foreach (var asset in matchingAssets)
                        {
                            using (new EditorGUILayout.HorizontalScope())
                            {
                                GUILayout.Label(Path.GetFileName(asset.Path), GUILayout.Width(130f));
                                GUILayout.Label(asset.Path, EditorStyles.miniLabel, GUILayout.ExpandWidth(true));
                                if (GUILayout.Button("表示", GUILayout.Width(48f)))
                                {
                                    SelectAndPing(asset.Path);
                                }
                                if (GUILayout.Button("解除", GUILayout.Width(48f)))
                                {
                                    FolderMikkeColorTags.RemoveColor(asset.Guid);
                                    GUIUtility.ExitGUI();
                                }
                            }
                        }
                    }
                }
            }

            if (visibleGroupCount == 0)
            {
                EditorGUILayout.HelpBox(
                    string.IsNullOrEmpty(searchText)
                        ? "手動カラーが設定されたアセットはありません。プロジェクトウィンドウで右クリックして色を設定してください。"
                        : "検索条件に一致するアセットはありません。",
                    MessageType.None);
            }

            EditorGUILayout.EndScrollView();
        }

        private void RefreshFilteredAssets()
        {
            var query = (searchText ?? string.Empty).Trim();
            foreach (var group in groups)
            {
                group.FilteredAssets.Clear();
                foreach (var asset in group.Assets)
                {
                    if (query.Length == 0 ||
                        asset.Path.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0 ||
                        group.Name.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        group.FilteredAssets.Add(asset);
                    }
                }
            }
        }

        private void RefreshGroups()
        {
            groups.Clear();
            var snapshot = FolderMikkeColorTags.GetSnapshot();
            var groupsByColor = new Dictionary<string, ColorGroup>();

            foreach (var pair in snapshot)
            {
                var path = AssetDatabase.GUIDToAssetPath(pair.Key);
                if (string.IsNullOrEmpty(path))
                {
                    continue;
                }

                var key = FolderMikkeColorTags.ToColorKey(pair.Value);
                if (!groupsByColor.TryGetValue(key, out var group))
                {
                    group = new ColorGroup
                    {
                        Key = key,
                        Name = FolderMikkeColorTags.GetColorName(pair.Value),
                        Color = pair.Value
                    };
                    groupsByColor.Add(key, group);
                    groups.Add(group);
                }

                group.Assets.Add(new AssetEntry { Guid = pair.Key, Path = path });
            }

            foreach (var group in groups)
            {
                group.Assets.Sort((left, right) => string.Compare(left.Path, right.Path, StringComparison.OrdinalIgnoreCase));
            }

            groups.Sort((left, right) => string.Compare(left.Name, right.Name, StringComparison.OrdinalIgnoreCase));
            RefreshFilteredAssets();
            Repaint();
        }

        private static void SelectAndPing(string path)
        {
            var asset = AssetDatabase.LoadMainAssetAtPath(path);
            if (asset == null)
            {
                Debug.LogWarning("[ふぉるだーみっけ] アセットを読み込めませんでした: " + path);
                return;
            }

            Selection.activeObject = asset;
            EditorGUIUtility.PingObject(asset);
        }

        [MenuItem("Tools/ふぉるだーみっけ/色別一覧", false, 2010)]
        private static void Open()
        {
            EditorWindow.GetWindow<FolderMikkeColorGroupsWindow>("ふぉるだーみっけ - 色別一覧");
        }
    }
}
