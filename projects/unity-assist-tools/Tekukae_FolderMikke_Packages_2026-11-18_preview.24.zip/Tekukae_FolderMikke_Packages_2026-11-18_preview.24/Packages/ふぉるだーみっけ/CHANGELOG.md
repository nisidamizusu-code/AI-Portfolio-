# ふぉるだーみっけ 1.1.7

- パッケージIDを `com.foldermikke.project-file-colorizer` に変更
- namespace / Assembly Definition名を `FolderMikke.ProjectFileColorizer` 系へ統一
- 設定ファイル名を `FolderMikke.ManualTags.json` に変更し、旧ファイルから自動コピー移行
- EditorPrefsキーを新名称へ移行（旧設定値を保持）
- 固定18色パレットとアセット色分け機能は維持

# ふぉるだーみっけ 更新履歴

## 1.1.6

- Unityメニュー、ウィンドウ名、右クリックメニューを「ふぉるだーみっけ」に統一
- 手動カラータグを自由入力から固定18色パレット選択へ変更
- 旧版で保存された任意色を、読み込み時に最も近い固定パレット色へ正規化
- 色別一覧のグループが固定色単位でまとまるよう変更
- C#ソースファイル名を `FolderMikke.cs` / `FolderMikkeColorTags.cs` に変更
- 既存のUPM Package ID、設定ファイル名、EditorPrefsキー、GUIDを維持
- 自動色分け9カテゴリの色設定機能は従来どおり維持
