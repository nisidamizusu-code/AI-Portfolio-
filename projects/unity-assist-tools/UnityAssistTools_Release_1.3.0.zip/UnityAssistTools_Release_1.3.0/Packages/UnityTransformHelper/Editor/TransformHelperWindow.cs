using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace UnityAssist.TransformTool
{
    internal sealed class TransformHelperWindow : EditorWindow
    {
        private Vector3 positionOffset;
        private float axisMoveStep = 1f;
        private Vector3 rotationOffset;
        private bool uniformScale = true;
        private float uniformScaleFactor = 1f;
        private Vector3 scaleFactors = Vector3.one;

        [MenuItem("Tools/Unity Transform Helper")]
        private static void Open()
        {
            GetWindow<TransformHelperWindow>("Transform Helper");
        }

        private void OnEnable()
        {
            Undo.undoRedoPerformed += Repaint;
        }

        private void OnDisable()
        {
            Undo.undoRedoPerformed -= Repaint;
        }

        private void OnSelectionChange()
        {
            Repaint();
        }

        private void OnGUI()
        {
            var selectedTransforms = Selection.transforms;
            var transforms = GetTopLevelSelection(selectedTransforms);
            EditorGUILayout.LabelField("選択オブジェクトの相対調整", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "位置の軸移動量は初期値1ローカル単位です。選択中の各オブジェクトに適用します。",
                MessageType.Info);

            DrawUndoButtons();
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("選択中: " + CountLiveTransforms(selectedTransforms) + " オブジェクト");
            if (transforms.Length != CountLiveTransforms(selectedTransforms))
            {
                EditorGUILayout.HelpBox(
                    "親子オブジェクトが同時に選択されています。親の変更による子への二重適用を避けるため、選択された親の子は個別調整の対象から除外します。",
                    MessageType.Warning);
            }
            EditorGUILayout.LabelField("今回の適用対象: " + transforms.Length + " オブジェクト", EditorStyles.miniLabel);

            using (new EditorGUI.DisabledScope(transforms.Length == 0))
            {
                DrawPositionControls(transforms);
                DrawRotationControls(transforms);
                DrawScaleControls(transforms);
            }

            if (transforms.Length == 0)
            {
                EditorGUILayout.HelpBox("HierarchyまたはSceneビューでオブジェクトを選択してください。", MessageType.Warning);
            }
        }

        private static void DrawUndoButtons()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button(new GUIContent("一つ戻る", "UnityのUndoを実行します。ショートカット: Ctrl+Z / Cmd+Z")))
                {
                    Undo.PerformUndo();
                }

                if (GUILayout.Button(new GUIContent("やり直す", "UnityのRedoを実行します。ショートカット: Ctrl+Y / Cmd+Shift+Z")))
                {
                    Undo.PerformRedo();
                }
            }

            EditorGUILayout.LabelField("ショートカット: Ctrl+Z / Ctrl+Y（Mac: Cmd+Z / Cmd+Shift+Z）", EditorStyles.miniLabel);
        }

        private void DrawPositionControls(Transform[] transforms)
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("位置", EditorStyles.boldLabel);
            positionOffset = EditorGUILayout.Vector3Field(
                new GUIContent("移動量（ローカル）", "選択中の各オブジェクトを、それぞれの親に対するローカル座標で移動します。"),
                positionOffset);
            if (!IsFinite(positionOffset))
            {
                positionOffset = Vector3.zero;
                EditorGUILayout.HelpBox("移動量に無効な数値が含まれていたため、0に戻しました。", MessageType.Warning);
            }

            axisMoveStep = EditorGUILayout.FloatField("軸移動量", axisMoveStep);
            if (!IsFinite(axisMoveStep))
            {
                axisMoveStep = 1f;
                EditorGUILayout.HelpBox("軸移動量には有限の数値を入力してください。1に戻しました。", MessageType.Warning);
            }
            axisMoveStep = Mathf.Abs(axisMoveStep);

            DrawAxisMoveButtons(transforms, "X", Vector3.right);
            DrawAxisMoveButtons(transforms, "Y", Vector3.up);
            DrawAxisMoveButtons(transforms, "Z", Vector3.forward);

            if (GUILayout.Button("入力した移動量を適用"))
            {
                ApplyPositionOffset(transforms, positionOffset);
            }
        }

        private void DrawAxisMoveButtons(Transform[] transforms, string axis, Vector3 direction)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField(axis, GUILayout.Width(18f));
                if (GUILayout.Button("−"))
                {
                    ApplyPositionOffset(transforms, direction * -axisMoveStep);
                }

                if (GUILayout.Button("+"))
                {
                    ApplyPositionOffset(transforms, direction * axisMoveStep);
                }
            }
        }

        private void DrawRotationControls(Transform[] transforms)
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("回転", EditorStyles.boldLabel);
            rotationOffset = EditorGUILayout.Vector3Field(
                new GUIContent("回転量（度）", "選択中の各オブジェクトのローカル回転に加算します。"),
                rotationOffset);
            if (!IsFinite(rotationOffset))
            {
                rotationOffset = Vector3.zero;
                EditorGUILayout.HelpBox("回転量に無効な数値が含まれていたため、0に戻しました。", MessageType.Warning);
            }
            if (GUILayout.Button("入力した回転量を適用"))
            {
                ApplyRotationOffset(transforms, rotationOffset);
            }
        }

        private void DrawScaleControls(Transform[] transforms)
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("サイズ", EditorStyles.boldLabel);
            uniformScale = EditorGUILayout.ToggleLeft("縦横奥行きを同じ倍率で変更", uniformScale);

            if (uniformScale)
            {
                uniformScaleFactor = EditorGUILayout.Slider(
                    new GUIContent("倍率", "1.0で変化なし、0.5で半分、2.0で2倍です。"),
                    uniformScaleFactor, 0.1f, 3f);
                EditorGUILayout.LabelField("適用後のサイズ: " + (uniformScaleFactor * 100f).ToString("0") + "%");
                if (GUILayout.Button("倍率を適用"))
                {
                    ApplyScale(transforms, Vector3.one * uniformScaleFactor);
                }
            }
            else
            {
                scaleFactors.x = EditorGUILayout.Slider("幅 (X)", scaleFactors.x, 0.1f, 3f);
                scaleFactors.y = EditorGUILayout.Slider("高さ (Y)", scaleFactors.y, 0.1f, 3f);
                scaleFactors.z = EditorGUILayout.Slider("奥行き (Z)", scaleFactors.z, 0.1f, 3f);
                if (GUILayout.Button("各軸の倍率を適用"))
                {
                    ApplyScale(transforms, scaleFactors);
                }
            }
        }

        private static void ApplyPositionOffset(Transform[] transforms, Vector3 offset)
        {
            ApplyToSelection(transforms, "位置を調整", transform => transform.localPosition += offset);
        }

        private static void ApplyRotationOffset(Transform[] transforms, Vector3 offset)
        {
            ApplyToSelection(transforms, "回転を調整", transform =>
                transform.localRotation = Quaternion.Euler(transform.localEulerAngles + offset));
        }

        private static void ApplyScale(Transform[] transforms, Vector3 factors)
        {
            ApplyToSelection(transforms, "サイズを調整", transform =>
            {
                var scale = transform.localScale;
                transform.localScale = new Vector3(scale.x * factors.x, scale.y * factors.y, scale.z * factors.z);
            });
        }

        private static void ApplyToSelection(Transform[] transforms, string undoName, System.Action<Transform> apply)
        {
            var liveTransforms = new List<Transform>();
            foreach (var transform in transforms)
            {
                if (transform != null)
                {
                    liveTransforms.Add(transform);
                }
            }

            if (liveTransforms.Count == 0)
            {
                return;
            }

            Undo.RecordObjects(liveTransforms.ToArray(), undoName);
            foreach (var transform in liveTransforms)
            {
                apply(transform);
                PrefabUtility.RecordPrefabInstancePropertyModifications(transform);
            }
        }

        private static Transform[] GetTopLevelSelection(Transform[] selectedTransforms)
        {
            var selectedSet = new HashSet<Transform>();
            foreach (var transform in selectedTransforms)
            {
                if (transform != null)
                {
                    selectedSet.Add(transform);
                }
            }

            var roots = new List<Transform>();
            foreach (var transform in selectedSet)
            {
                var hasSelectedAncestor = false;
                for (var parent = transform.parent; parent != null; parent = parent.parent)
                {
                    if (!selectedSet.Contains(parent))
                    {
                        continue;
                    }

                    hasSelectedAncestor = true;
                    break;
                }

                if (!hasSelectedAncestor)
                {
                    roots.Add(transform);
                }
            }

            return roots.ToArray();
        }

        private static int CountLiveTransforms(Transform[] transforms)
        {
            var count = 0;
            foreach (var transform in transforms)
            {
                if (transform != null)
                {
                    count++;
                }
            }
            return count;
        }

        private static bool IsFinite(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }

        private static bool IsFinite(Vector3 value)
        {
            return IsFinite(value.x) && IsFinite(value.y) && IsFinite(value.z);
        }
    }
}
