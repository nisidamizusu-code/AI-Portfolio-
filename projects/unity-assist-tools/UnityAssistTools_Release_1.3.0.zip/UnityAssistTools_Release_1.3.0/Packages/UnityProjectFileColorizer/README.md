# Unity Project File Colorizer

UnityのProjectウィンドウに、アセットの種類を示す色付きラインを表示するEditor拡張です。スクリプト、シーン、Prefab、マテリアル、テクスチャ、オーディオ、3Dモデル、シェーダー、データファイルを色分けします。

## 対応環境

- Unity 2021.3以降

## 導入

1. Unityで対象プロジェクトを開きます。
2. **Window > Package Manager** を開きます。
3. **＋ > Add package from disk...** を選びます。
4. このパッケージの `package.json` を選択します。

## 使い方

- **Tools > Unity File Colorizer** を開き、色分けの有効・無効とカテゴリごとの色を設定します。
- 色の設定はPCごとのUnity Editor設定（EditorPrefs）に保存され、プロジェクト内のアセットは変更しません。
- Projectウィンドウの各アセット左側に色付きラインを表示します。対象外の拡張子には表示しません。

## 変更点（1.0.1）

- UPM Editor専用Assembly Definitionを追加しました。
- 既存の表示・設定仕様は維持しています。
