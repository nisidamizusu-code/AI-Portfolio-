using System.IO;
using UnityEditor;
using UnityEngine;

namespace UnityAssist.ProjectFileColorizer
{
    [InitializeOnLoad]
    internal static class ProjectFileColorizer
    {
        private const string EnabledKey = "UnityAssist.ProjectFileColorizer.Enabled";
        private const string ColorKeyPrefix = "UnityAssist.ProjectFileColorizer.Color.";

        static ProjectFileColorizer()
        {
            EditorApplication.projectWindowItemOnGUI += DrawProjectItem;
        }

        internal static bool IsEnabled
        {
            get => EditorPrefs.GetBool(EnabledKey, true);
            set => EditorPrefs.SetBool(EnabledKey, value);
        }

        internal static Color GetColor(FileCategory category)
        {
            var defaults = GetDefaultColor(category);
            var key = ColorKeyPrefix + category;
            var color = new Color(
                EditorPrefs.GetFloat(key + ".r", defaults.r),
                EditorPrefs.GetFloat(key + ".g", defaults.g),
                EditorPrefs.GetFloat(key + ".b", defaults.b),
                EditorPrefs.GetFloat(key + ".a", defaults.a));
            return color;
        }

        internal static void SetColor(FileCategory category, Color color)
        {
            var key = ColorKeyPrefix + category;
            EditorPrefs.SetFloat(key + ".r", color.r);
            EditorPrefs.SetFloat(key + ".g", color.g);
            EditorPrefs.SetFloat(key + ".b", color.b);
            EditorPrefs.SetFloat(key + ".a", color.a);
        }

        internal static Color GetDefaultColor(FileCategory category)
        {
            switch (category)
            {
                case FileCategory.Script: return new Color(0.25f, 0.75f, 1f);
                case FileCategory.Scene: return new Color(1f, 0.65f, 0.2f);
                case FileCategory.Prefab: return new Color(0.75f, 0.45f, 1f);
                case FileCategory.Material: return new Color(1f, 0.4f, 0.55f);
                case FileCategory.Texture: return new Color(0.35f, 0.85f, 0.45f);
                case FileCategory.Audio: return new Color(1f, 0.8f, 0.25f);
                case FileCategory.Model: return new Color(0.25f, 0.85f, 0.8f);
                case FileCategory.Shader: return new Color(0.95f, 0.4f, 0.3f);
                case FileCategory.Data: return new Color(0.7f, 0.75f, 0.8f);
                default: return Color.white;
            }
        }

        private static void DrawProjectItem(string guid, Rect rect)
        {
            if (!IsEnabled || Event.current.type != EventType.Repaint)
            {
                return;
            }

            var path = AssetDatabase.GUIDToAssetPath(guid);
            var category = GetCategory(path);
            if (category == FileCategory.None)
            {
                return;
            }

            var marker = new Rect(rect.x, rect.y, Mathf.Min(3f, rect.width), rect.height);
            EditorGUI.DrawRect(marker, GetColor(category));
        }

        private static FileCategory GetCategory(string path)
        {
            var extension = Path.GetExtension(path).ToLowerInvariant();
            switch (extension)
            {
                case ".cs":
                case ".js":
                case ".asmdef":
                case ".asmref":
                    return FileCategory.Script;
                case ".unity":
                    return FileCategory.Scene;
                case ".prefab":
                    return FileCategory.Prefab;
                case ".mat":
                    return FileCategory.Material;
                case ".png":
                case ".jpg":
                case ".jpeg":
                case ".tga":
                case ".psd":
                case ".bmp":
                case ".tif":
                case ".tiff":
                case ".exr":
                case ".hdr":
                    return FileCategory.Texture;
                case ".wav":
                case ".mp3":
                case ".ogg":
                case ".aif":
                case ".aiff":
                    return FileCategory.Audio;
                case ".fbx":
                case ".obj":
                case ".blend":
                case ".dae":
                case ".3ds":
                case ".max":
                case ".ma":
                case ".mb":
                    return FileCategory.Model;
                case ".shader":
                case ".shadergraph":
                case ".shadersubgraph":
                case ".compute":
                case ".cginc":
                case ".hlsl":
                case ".glsl":
                    return FileCategory.Shader;
                case ".json":
                case ".xml":
                case ".txt":
                case ".bytes":
                case ".csv":
                    return FileCategory.Data;
                default:
                    return FileCategory.None;
            }
        }
    }

    internal enum FileCategory
    {
        None,
        Script,
        Scene,
        Prefab,
        Material,
        Texture,
        Audio,
        Model,
        Shader,
        Data
    }

    internal sealed class ProjectFileColorizerWindow : EditorWindow
    {
        private static readonly FileCategory[] Categories =
        {
            FileCategory.Script,
            FileCategory.Scene,
            FileCategory.Prefab,
            FileCategory.Material,
            FileCategory.Texture,
            FileCategory.Audio,
            FileCategory.Model,
            FileCategory.Shader,
            FileCategory.Data
        };

        [MenuItem("Tools/Unity File Colorizer")]
        private static void Open()
        {
            GetWindow<ProjectFileColorizerWindow>("File Colorizer");
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("Projectウィンドウのアセットを種類別に色分けします。", EditorStyles.wordWrappedLabel);
            EditorGUILayout.Space();

            var enabled = EditorGUILayout.Toggle("色分けを有効にする", ProjectFileColorizer.IsEnabled);
            if (enabled != ProjectFileColorizer.IsEnabled)
            {
                ProjectFileColorizer.IsEnabled = enabled;
                RepaintProjectWindow();
            }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("色の設定", EditorStyles.boldLabel);

            foreach (var category in Categories)
            {
                var color = EditorGUILayout.ColorField(GetDisplayName(category), ProjectFileColorizer.GetColor(category));
                if (color != ProjectFileColorizer.GetColor(category))
                {
                    ProjectFileColorizer.SetColor(category, color);
                    RepaintProjectWindow();
                }
            }

            EditorGUILayout.HelpBox("色はこのPCのUnity Editor設定に保存されます。色付きの細いラインが種類の目印です。", MessageType.Info);
        }

        private static string GetDisplayName(FileCategory category)
        {
            switch (category)
            {
                case FileCategory.Script: return "スクリプト";
                case FileCategory.Scene: return "シーン";
                case FileCategory.Prefab: return "Prefab";
                case FileCategory.Material: return "マテリアル";
                case FileCategory.Texture: return "テクスチャ";
                case FileCategory.Audio: return "オーディオ";
                case FileCategory.Model: return "3Dモデル";
                case FileCategory.Shader: return "シェーダー";
                case FileCategory.Data: return "データ";
                default: return category.ToString();
            }
        }

        private static void RepaintProjectWindow()
        {
            EditorApplication.RepaintProjectWindow();
        }
    }
}
