using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace UnityAssist.TextureColorReplacer
{
    internal sealed class TextureColorReplacerWindow : EditorWindow
    {
        private const long MaximumPixelCount = 16777216;
        private const int LinearToSrgbLutSize = 4096;
        private const int CubeRootLutSize = 65535;
        private const float MaximumSingleColorRadius = 0.12f;
        private const float MaximumRangeRadius = 0.32f;

        // Color32 values read from the sRGB render target are interpreted as sRGB.
        // Lookup tables avoid repeated power functions during the per-pixel loop.
        private static readonly float[] SrgbToLinearLut = CreateSrgbToLinearLut();
        private static readonly float[] CubeRootLut = CreateCubeRootLut();
        private static readonly float[] LinearToSrgbLut = CreateLinearToSrgbLut();

        private Texture2D sourceTexture;
        private Texture2D previewTexture;
        private Color32[] sourcePixels;
        private Color sourceColor = Color.white;
        private Color replacementColor = Color.red;
        private Color sourceEndColor = new Color(1f, 0.45f, 0.60f, 1f).linear;
        private Color replacementEndColor = new Color(0.40f, 0.80f, 1f, 1f).linear;
        private int tolerance = 4;
        private int previewMatchCount;
        private bool preserveShading = true;
        private bool ignoreTransparent = true;
        private bool useColorRange;
        private bool pickingSourceColor;
        private bool pickingSourceEndColor;
        private bool previewIsCurrent;
        private string errorMessage;
        private Vector2 scrollPosition;

        [MenuItem("Tools/Unity Texture Color Replacer")]
        private static void Open()
        {
            GetWindow<TextureColorReplacerWindow>("Texture Color Replacer");
        }

        private void OnDestroy()
        {
            DestroyPreview();
        }

        private void OnGUI()
        {
            scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);
            EditorGUILayout.LabelField("テクスチャの色を置き換えて、別のPNGとして保存します。", EditorStyles.wordWrappedLabel);
            EditorGUILayout.HelpBox("元のテクスチャは変更しません。置換後の画像はAssets内へ別ファイルで保存されます。",
                MessageType.Info);
            EditorGUILayout.Space();

            DrawSourceControls();
            if (sourceTexture != null)
            {
                DrawColorControls();
                DrawPreviews();
                DrawSaveControls();
            }

            if (!string.IsNullOrEmpty(errorMessage))
            {
                EditorGUILayout.HelpBox(errorMessage, MessageType.Error);
            }

            EditorGUILayout.EndScrollView();
        }

        private void DrawSourceControls()
        {
            EditorGUI.BeginChangeCheck();
            var selectedTexture = (Texture2D)EditorGUILayout.ObjectField(
                new GUIContent("元テクスチャ", "色を置き換えたいTexture2Dを選択します。"),
                sourceTexture,
                typeof(Texture2D),
                false);
            if (EditorGUI.EndChangeCheck())
            {
                sourceTexture = selectedTexture;
                sourcePixels = null;
                pickingSourceColor = false;
                pickingSourceEndColor = false;
                previewIsCurrent = false;
                errorMessage = null;
                DestroyPreview();
            }

            using (new EditorGUI.DisabledScope(sourceTexture == null))
            {
                if (GUILayout.Button("画像を読み込む"))
                {
                    LoadSourcePixels();
                }
            }

            if (sourceTexture != null)
            {
                EditorGUILayout.LabelField(
                    $"サイズ: {sourceTexture.width} × {sourceTexture.height}",
                    EditorStyles.miniLabel);
                if (sourcePixels == null)
                {
                    EditorGUILayout.HelpBox("スポイトとプレビューを使うには、先に画像を読み込んでください。",
                        MessageType.Warning);
                }
            }
        }

        private void DrawColorControls()
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("色の置き換え", EditorStyles.boldLabel);
            EditorGUI.BeginChangeCheck();

            using (new EditorGUILayout.HorizontalScope())
            {
                sourceColor = EditorGUILayout.ColorField(
                    new GUIContent("置換元の色"), sourceColor, true, true, true);
                using (new EditorGUI.DisabledScope(sourcePixels == null))
                {
                    var nextPicking = GUILayout.Toggle(
                        pickingSourceColor, "スポイト", "Button", GUILayout.Width(72f));
                    if (nextPicking)
                    {
                        pickingSourceEndColor = false;
                    }
                    pickingSourceColor = nextPicking;
                }
            }

            replacementColor = EditorGUILayout.ColorField(
                new GUIContent("置換先の色"), replacementColor, true, true, true);

            useColorRange = EditorGUILayout.ToggleLeft(
                new GUIContent("色の流れを維持して変換（終点を指定）",
                    "OFFでは1色を基準に変換します。ONでは元色と変換先の終点を指定し、色の流れを対応させます。"),
                useColorRange);
            if (!useColorRange)
            {
                pickingSourceEndColor = false;
            }

            if (useColorRange)
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    sourceEndColor = EditorGUILayout.ColorField(
                        new GUIContent("元画像の終点色"), sourceEndColor, true, true, true);
                    using (new EditorGUI.DisabledScope(sourcePixels == null))
                    {
                        var nextPicking = GUILayout.Toggle(
                            pickingSourceEndColor, "終点スポイト", "Button", GUILayout.Width(88f));
                        if (nextPicking)
                        {
                            pickingSourceColor = false;
                        }
                        pickingSourceEndColor = nextPicking;
                    }
                }

                replacementEndColor = EditorGUILayout.ColorField(
                    new GUIContent("変換先の終点色"), replacementEndColor, true, true, true);
            }

            tolerance = EditorGUILayout.IntSlider(
                new GUIContent("色差許容値",
                    "OKLabベースの知覚色差許容値です。小さいほど誤検出を抑えます。色の流れ変換では指定した色の線分からの距離にも適用します。"),
                tolerance,
                0,
                64);
            preserveShading = EditorGUILayout.ToggleLeft(
                new GUIContent("元の明るさ・陰影を保つ", "色の変換差分を適用し、元画像の細かな色の変化を残します。"),
                preserveShading);
            ignoreTransparent = EditorGUILayout.ToggleLeft(
                new GUIContent("透明ピクセルを変更しない"),
                ignoreTransparent);

            if (EditorGUI.EndChangeCheck())
            {
                previewIsCurrent = false;
            }

            if (pickingSourceColor)
            {
                EditorGUILayout.HelpBox("左の元画像をクリックして、置換元の色を選んでください。",
                    MessageType.Info);
            }
            else if (pickingSourceEndColor)
            {
                EditorGUILayout.HelpBox("左の元画像をクリックして、色の流れの終点色を選んでください。",
                    MessageType.Info);
            }
        }

        private void DrawPreviews()
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("プレビュー", EditorStyles.boldLabel);

            using (new EditorGUILayout.HorizontalScope())
            {
                DrawTexturePreview("元画像", sourceTexture, true);
                DrawTexturePreview("置換結果", previewTexture, false);
            }

            using (new EditorGUI.DisabledScope(sourcePixels == null))
            {
                if (GUILayout.Button(previewIsCurrent ? "プレビューを更新" : "置換をプレビュー"))
                {
                    BuildPreview();
                }

                if (previewIsCurrent)
                {
                    if (previewMatchCount == 0)
                    {
                        EditorGUILayout.HelpBox("一致するピクセルがありません。スポイトで色を選び直すか、色差許容値を少し上げてください。",
                            MessageType.Warning);
                    }
                    else
                    {
                        EditorGUILayout.LabelField($"置換対象: {previewMatchCount:N0} ピクセル", EditorStyles.miniLabel);
                    }
                }
            }

            if (!previewIsCurrent && previewTexture != null)
            {
                EditorGUILayout.HelpBox("設定が変更されています。最新の結果を確認するにはプレビューを更新してください。",
                    MessageType.Warning);
            }
        }

        private void DrawTexturePreview(string label, Texture2D texture, bool canPickColor)
        {
            using (new EditorGUILayout.VerticalScope(GUILayout.MinWidth(120f)))
            {
                EditorGUILayout.LabelField(label, EditorStyles.centeredGreyMiniLabel);
                var container = GUILayoutUtility.GetRect(120f, 160f, GUILayout.ExpandWidth(true));
                GUI.Box(container, GUIContent.none);

                if (texture == null)
                {
                    GUI.Label(container, "プレビューなし", EditorStyles.centeredGreyMiniLabel);
                    return;
                }

                var imageRect = GetAspectRect(container, texture.width, texture.height);
                GUI.DrawTexture(imageRect, texture, ScaleMode.StretchToFill, true);

                if (canPickColor && (pickingSourceColor || pickingSourceEndColor) &&
                    Event.current.type == EventType.MouseDown &&
                    Event.current.button == 0 &&
                    imageRect.Contains(Event.current.mousePosition))
                {
                    PickSourceColor(imageRect, Event.current.mousePosition);
                    Event.current.Use();
                }
            }
        }

        private static Rect GetAspectRect(Rect container, int width, int height)
        {
            var textureAspect = (float)width / height;
            var containerAspect = container.width / container.height;
            if (textureAspect > containerAspect)
            {
                var drawnHeight = container.width / textureAspect;
                return new Rect(container.x, container.y + (container.height - drawnHeight) * 0.5f,
                    container.width, drawnHeight);
            }

            var drawnWidth = container.height * textureAspect;
            return new Rect(container.x + (container.width - drawnWidth) * 0.5f, container.y,
                drawnWidth, container.height);
        }

        private void DrawSaveControls()
        {
            EditorGUILayout.Space();
            using (new EditorGUI.DisabledScope(previewTexture == null || !previewIsCurrent))
            {
                if (GUILayout.Button("PNGとして別名保存"))
                {
                    SavePreview();
                }
            }
        }

        private void LoadSourcePixels()
        {
            errorMessage = null;
            DestroyPreview();
            previewIsCurrent = false;
            previewMatchCount = 0;

            if (sourceTexture == null)
            {
                sourcePixels = null;
                return;
            }

            var pixelCount = (long)sourceTexture.width * sourceTexture.height;
            if (pixelCount > MaximumPixelCount)
            {
                sourcePixels = null;
                errorMessage = "テクスチャが大きすぎます（上限: 16,777,216ピクセル）。Unityで解像度を下げたコピーを作成してください。";
                return;
            }

            try
            {
                sourcePixels = ReadTexturePixels(sourceTexture);
                Repaint();
            }
            catch (Exception exception)
            {
                sourcePixels = null;
                errorMessage = $"画像を読み込めませんでした: {exception.Message}";
                Debug.LogException(exception);
            }
        }

        private static Color32[] ReadTexturePixels(Texture2D texture)
        {
            var previousActive = RenderTexture.active;
            RenderTexture renderTexture = null;
            Texture2D readableTexture = null;

            try
            {
                renderTexture = RenderTexture.GetTemporary(
                    texture.width,
                    texture.height,
                    0,
                    RenderTextureFormat.ARGB32,
                    RenderTextureReadWrite.sRGB);
                readableTexture = new Texture2D(
                    texture.width,
                    texture.height,
                    TextureFormat.RGBA32,
                    false,
                    false);
                Graphics.Blit(texture, renderTexture);
                RenderTexture.active = renderTexture;
                readableTexture.ReadPixels(new Rect(0, 0, texture.width, texture.height), 0, 0, false);
                readableTexture.Apply(false, false);
                return readableTexture.GetPixels32();
            }
            finally
            {
                RenderTexture.active = previousActive;
                if (renderTexture != null)
                {
                    RenderTexture.ReleaseTemporary(renderTexture);
                }
                if (readableTexture != null)
                {
                    DestroyImmediate(readableTexture);
                }
            }
        }

        private void PickSourceColor(Rect imageRect, Vector2 mousePosition)
        {
            var x = Mathf.Clamp(
                Mathf.FloorToInt((mousePosition.x - imageRect.x) / imageRect.width * sourceTexture.width),
                0,
                sourceTexture.width - 1);
            var y = Mathf.Clamp(
                Mathf.FloorToInt((imageRect.yMax - mousePosition.y) / imageRect.height * sourceTexture.height),
                0,
                sourceTexture.height - 1);
            var pickedColor = ((Color)sourcePixels[y * sourceTexture.width + x]).linear;

            if (pickingSourceEndColor)
            {
                sourceEndColor = pickedColor;
                pickingSourceEndColor = false;
            }
            else
            {
                sourceColor = pickedColor;
                pickingSourceColor = false;
            }

            previewIsCurrent = false;
            Repaint();
        }

        private void BuildPreview()
        {
            if (sourceTexture == null || sourcePixels == null)
            {
                errorMessage = "先に元画像を読み込んでください。";
                return;
            }

            try
            {
                var sourceStart = ToOklab(sourceColor);
                var targetStart = ToOklab(replacementColor);
                var sourceEnd = useColorRange ? ToOklab(sourceEndColor) : sourceStart;
                var targetEnd = useColorRange ? ToOklab(replacementEndColor) : targetStart;

                var sourceMetricStart = ToDistanceMetric(sourceStart);
                var sourceMetricEnd = ToDistanceMetric(sourceEnd);
                var sourceDirection = Subtract(sourceMetricEnd, sourceMetricStart);
                var sourceDirectionLengthSquared = Dot(sourceDirection, sourceDirection);

                if (useColorRange && sourceDirectionLengthSquared < 0.000001f)
                {
                    errorMessage = "元画像の始点色と終点色が近すぎます。異なる2色を指定してください。";
                    previewIsCurrent = false;
                    return;
                }

                var toleranceRadius = GetToleranceRadius(useColorRange, tolerance);
                var toleranceRadiusSquared = toleranceRadius * toleranceRadius;
                var singleColorOffset = Subtract(targetStart, sourceStart);
                var targetMetricStart = ToDistanceMetric(targetStart);
                var targetMetricEnd = ToDistanceMetric(targetEnd);

                var result = new Color32[sourcePixels.Length];
                var matchCount = 0;

                for (var index = 0; index < sourcePixels.Length; index++)
                {
                    var pixel = sourcePixels[index];
                    if (ignoreTransparent && pixel.a == 0)
                    {
                        result[index] = pixel;
                        continue;
                    }

                    var pixelLab = ToOklab(pixel);
                    Oklab outputLab;
                    bool matches;

                    if (useColorRange)
                    {
                        var pixelMetric = ToDistanceMetric(pixelLab);
                        var fromStart = Subtract(pixelMetric, sourceMetricStart);
                        var t = Dot(fromStart, sourceDirection) / sourceDirectionLengthSquared;

                        // The projection must stay between both user-selected endpoints.
                        // This prevents unrelated colors beyond either endpoint from being included.
                        if (t < 0f || t > 1f)
                        {
                            result[index] = pixel;
                            continue;
                        }

                        var residual = Subtract(fromStart, Multiply(sourceDirection, t));
                        matches = Dot(residual, residual) <= toleranceRadiusSquared;
                        if (!matches)
                        {
                            result[index] = pixel;
                            continue;
                        }

                        var sourceOnPath = FromDistanceMetric(Lerp(sourceMetricStart, sourceMetricEnd, t));
                        var targetOnPath = FromDistanceMetric(Lerp(targetMetricStart, targetMetricEnd, t));
                        outputLab = preserveShading
                            ? Add(pixelLab, Subtract(targetOnPath, sourceOnPath))
                            : targetOnPath;
                    }
                    else
                    {
                        var pixelMetric = ToDistanceMetric(pixelLab);
                        var sourceMetricDifference = Subtract(pixelMetric, sourceMetricStart);
                        matches = Dot(sourceMetricDifference, sourceMetricDifference) <= toleranceRadiusSquared;
                        if (!matches)
                        {
                            result[index] = pixel;
                            continue;
                        }

                        outputLab = preserveShading
                            ? Add(pixelLab, singleColorOffset)
                            : targetStart;
                    }

                    matchCount++;
                    result[index] = OklabToColor32(outputLab, pixel.a);
                }

                DestroyPreview();
                previewTexture = new Texture2D(
                    sourceTexture.width,
                    sourceTexture.height,
                    TextureFormat.RGBA32,
                    false,
                    false);
                previewTexture.name = sourceTexture.name + " Color Replacement Preview";
                previewTexture.SetPixels32(result);
                previewTexture.Apply(false, false);
                previewMatchCount = matchCount;
                previewIsCurrent = true;
                errorMessage = null;
            }
            catch (Exception exception)
            {
                previewIsCurrent = false;
                errorMessage = $"プレビューを作成できませんでした: {exception.Message}";
                Debug.LogException(exception);
            }
        }

        // A tolerance of 4 (the original default) maps to about 0.015 in strict mode
        // and 0.04 around a selected color path. The wider path radius accommodates
        // the slight curvature of common sRGB gradients while the segment direction
        // and endpoint checks keep unrelated hues out.
        private static float GetToleranceRadius(bool rangeMode, int value)
        {
            if (value <= 0)
            {
                return 0f;
            }

            var normalized = Mathf.Clamp01(value / 64f);
            var maximumRadius = rangeMode ? MaximumRangeRadius : MaximumSingleColorRadius;
            return maximumRadius * Mathf.Pow(normalized, 0.75f);
        }

        private static float[] CreateSrgbToLinearLut()
        {
            var table = new float[256];
            for (var i = 0; i < table.Length; i++)
            {
                var encoded = i / 255f;
                table[i] = encoded <= 0.04045f
                    ? encoded / 12.92f
                    : Mathf.Pow((encoded + 0.055f) / 1.055f, 2.4f);
            }
            return table;
        }

        private static float[] CreateCubeRootLut()
        {
            var table = new float[CubeRootLutSize + 1];
            for (var i = 0; i < table.Length; i++)
            {
                table[i] = Mathf.Pow(i / (float)CubeRootLutSize, 1f / 3f);
            }
            return table;
        }

        private static float[] CreateLinearToSrgbLut()
        {
            var table = new float[LinearToSrgbLutSize + 1];
            for (var i = 0; i < table.Length; i++)
            {
                var linear = i / (float)LinearToSrgbLutSize;
                var encoded = linear <= 0.0031308f
                    ? 12.92f * linear
                    : 1.055f * Mathf.Pow(linear, 1f / 2.4f) - 0.055f;
                table[i] = encoded * 255f;
            }
            return table;
        }

        // ColorField is kept in its HDR/linear working representation. Texture pixels
        // are read back as sRGB bytes, so the two input paths are converted separately.
        private static Oklab ToOklab(Color linearColor)
        {
            return ToOklabFromLinear(
                Mathf.Clamp01(linearColor.r),
                Mathf.Clamp01(linearColor.g),
                Mathf.Clamp01(linearColor.b));
        }

        private static Oklab ToOklab(Color32 srgbColor)
        {
            return ToOklabFromLinear(
                SrgbToLinearLut[srgbColor.r],
                SrgbToLinearLut[srgbColor.g],
                SrgbToLinearLut[srgbColor.b]);
        }

        private static Oklab ToOklabFromLinear(float r, float g, float b)
        {
            var l = 0.4122214708f * r + 0.5363325363f * g + 0.0514459929f * b;
            var m = 0.2119034982f * r + 0.6806995451f * g + 0.1073969566f * b;
            var s = 0.0883024619f * r + 0.2817188376f * g + 0.6299787005f * b;

            l = CubeRootLut[Mathf.Clamp(Mathf.RoundToInt(Mathf.Max(0f, l) * CubeRootLutSize), 0, CubeRootLutSize)];
            m = CubeRootLut[Mathf.Clamp(Mathf.RoundToInt(Mathf.Max(0f, m) * CubeRootLutSize), 0, CubeRootLutSize)];
            s = CubeRootLut[Mathf.Clamp(Mathf.RoundToInt(Mathf.Max(0f, s) * CubeRootLutSize), 0, CubeRootLutSize)];

            return new Oklab(
                0.2104542553f * l + 0.7936177850f * m - 0.0040720468f * s,
                1.9779984951f * l - 2.4285922050f * m + 0.4505937099f * s,
                0.0259040371f * l + 0.7827717662f * m - 0.8086757660f * s);
        }

        // W3C CSS Color 4 ΔEOKr2: toe-adjusted lightness and doubled a/b axes.
        private static Oklab ToDistanceMetric(Oklab color)
        {
            return new Oklab(Toe(color.L), 2f * color.A, 2f * color.B);
        }

        private static float Toe(float value)
        {
            const float k1 = 0.206f;
            const float k2 = 0.03f;
            const float k3 = (1f + k1) / (1f + k2);
            var valueTerm = k3 * value - k1;
            return 0.5f * (valueTerm + Mathf.Sqrt(valueTerm * valueTerm + 4f * k2 * k3 * value));
        }

        private static float ToeInverse(float value)
        {
            const float k1 = 0.206f;
            const float k2 = 0.03f;
            const float k3 = (1f + k1) / (1f + k2);
            return (value * value + k1 * value) / (k3 * (value + k2));
        }

        private static Oklab FromDistanceMetric(Oklab metric)
        {
            return new Oklab(ToeInverse(metric.L), metric.A * 0.5f, metric.B * 0.5f);
        }

        private static Color32 OklabToColor32(Oklab color, byte alpha)
        {
            var lightness = Mathf.Clamp01(color.L);
            var a = color.A;
            var b = color.B;
            var linear = OklabToLinearRgb(lightness, a, b);

            if (!IsInSrgbGamut(linear))
            {
                // Reduce chroma at fixed lightness and hue instead of clipping RGB
                // channels independently, which can shift the perceived hue.
                var chroma = Mathf.Sqrt(a * a + b * b);
                if (chroma > 0.000001f)
                {
                    var low = 0f;
                    var high = chroma;
                    for (var iteration = 0; iteration < 10; iteration++)
                    {
                        var middle = (low + high) * 0.5f;
                        var scale = middle / chroma;
                        var candidate = OklabToLinearRgb(lightness, a * scale, b * scale);
                        if (IsInSrgbGamut(candidate))
                        {
                            low = middle;
                        }
                        else
                        {
                            high = middle;
                        }
                    }

                    var scale = low / chroma;
                    linear = OklabToLinearRgb(lightness, a * scale, b * scale);
                }
            }

            return new Color32(
                LinearToSrgbByte(linear.R),
                LinearToSrgbByte(linear.G),
                LinearToSrgbByte(linear.B),
                alpha);
        }

        private static LinearRgb OklabToLinearRgb(float lightness, float a, float b)
        {
            var lRoot = lightness + 0.3963377774f * a + 0.2158037573f * b;
            var mRoot = lightness - 0.1055613458f * a - 0.0638541728f * b;
            var sRoot = lightness - 0.0894841775f * a - 1.2914855480f * b;

            var l = lRoot * lRoot * lRoot;
            var m = mRoot * mRoot * mRoot;
            var s = sRoot * sRoot * sRoot;

            return new LinearRgb(
                4.0767416621f * l - 3.3077115913f * m + 0.2309699292f * s,
                -1.2684380046f * l + 2.6097574011f * m - 0.3413193965f * s,
                -0.0041960863f * l - 0.7034186147f * m + 1.7076147010f * s);
        }

        private static bool IsInSrgbGamut(LinearRgb color)
        {
            const float epsilon = 0.00005f;
            return color.R >= -epsilon && color.R <= 1f + epsilon &&
                   color.G >= -epsilon && color.G <= 1f + epsilon &&
                   color.B >= -epsilon && color.B <= 1f + epsilon;
        }

        private static byte LinearToSrgbByte(float value)
        {
            value = Mathf.Clamp01(value);
            var position = value * LinearToSrgbLutSize;
            var index = Mathf.Min((int)position, LinearToSrgbLutSize - 1);
            var fraction = position - index;
            var encoded = Mathf.Lerp(LinearToSrgbLut[index], LinearToSrgbLut[index + 1], fraction);
            return (byte)Mathf.Clamp(Mathf.RoundToInt(encoded), 0, 255);
        }

        private static Oklab Add(Oklab left, Oklab right)
        {
            return new Oklab(left.L + right.L, left.A + right.A, left.B + right.B);
        }

        private static Oklab Subtract(Oklab left, Oklab right)
        {
            return new Oklab(left.L - right.L, left.A - right.A, left.B - right.B);
        }

        private static Oklab Multiply(Oklab value, float scale)
        {
            return new Oklab(value.L * scale, value.A * scale, value.B * scale);
        }

        private static Oklab Lerp(Oklab from, Oklab to, float t)
        {
            return new Oklab(
                Mathf.Lerp(from.L, to.L, t),
                Mathf.Lerp(from.A, to.A, t),
                Mathf.Lerp(from.B, to.B, t));
        }

        private static float Dot(Oklab left, Oklab right)
        {
            return left.L * right.L + left.A * right.A + left.B * right.B;
        }

        private void SavePreview()
        {
            if (previewTexture == null || !previewIsCurrent)
            {
                errorMessage = "最新のプレビューを作成してから保存してください。";
                return;
            }

            var sourcePath = AssetDatabase.GetAssetPath(sourceTexture);
            var sourceDirectory = sourcePath.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase)
                ? Path.GetDirectoryName(sourcePath)?.Replace('\\', '/') ?? "Assets"
                : "Assets";
            var defaultName = Path.GetFileNameWithoutExtension(sourceTexture.name) + "_recolored";
            var outputPath = EditorUtility.SaveFilePanelInProject(
                "置換後テクスチャを保存",
                defaultName,
                "png",
                "置換後のテクスチャをPNGとして別ファイルに保存します。",
                sourceDirectory);
            if (string.IsNullOrEmpty(outputPath))
            {
                return;
            }

            if (string.Equals(outputPath, sourcePath, StringComparison.OrdinalIgnoreCase))
            {
                errorMessage = "元のテクスチャは上書きできません。別のファイル名を指定してください。";
                return;
            }

            try
            {
                File.WriteAllBytes(outputPath, previewTexture.EncodeToPNG());
                AssetDatabase.ImportAsset(outputPath, ImportAssetOptions.ForceUpdate);
                AssetDatabase.Refresh();
                errorMessage = null;
                EditorUtility.DisplayDialog("保存しました", $"PNGを保存しました:\n{outputPath}", "OK");
            }
            catch (Exception exception)
            {
                errorMessage = $"PNGを保存できませんでした: {exception.Message}";
                Debug.LogException(exception);
            }
        }

        private void DestroyPreview()
        {
            if (previewTexture == null)
            {
                return;
            }

            DestroyImmediate(previewTexture);
            previewTexture = null;
        }

        private struct Oklab
        {
            public readonly float L;
            public readonly float A;
            public readonly float B;

            public Oklab(float l, float a, float b)
            {
                L = l;
                A = a;
                B = b;
            }
        }

        private struct LinearRgb
        {
            public readonly float R;
            public readonly float G;
            public readonly float B;

            public LinearRgb(float r, float g, float b)
            {
                R = r;
                G = g;
                B = b;
            }
        }
    }
}
