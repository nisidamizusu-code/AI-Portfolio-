using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace UnityAssist.TextureColorReplacer
{
    internal sealed class TextureColorReplacerWindow : EditorWindow
    {
        private const long MaximumPixelCount = 16777216;
        private const int PreviewChunkSize = 16384;
        private const int MaximumMaskOverlaySide = 512;
        private static readonly string[] MatchingModeLabels = { "同系色", "厳密" };
        private static readonly string[] MaskBrushLabels = { "塗り足し", "消しゴム" };
        private static readonly double[] SrgbLinearLookup = CreateSrgbLinearLookup();

        private enum ColorMatchingMode
        {
            SimilarColor,
            Precise
        }

        private Texture2D sourceTexture;
        private Texture2D previewTexture;
        private Color32[] sourcePixels;
        private Color32[] previewPixels;
        // 0 = 対象外、255 = 全面適用。マスクは元画像と同じ解像度で保持します。
        private byte[] selectionMask;
        // 画面表示用オーバーレイだけを縮小して保持し、メモリ使用量を抑えます。
        private Texture2D maskOverlayTexture;
        private Color sourceColor = Color.white;
        private Color replacementColor = Color.red;
        private ColorMatchingMode matchingMode = ColorMatchingMode.Precise;
        private float deltaEThreshold = 5f;
        private float hueTolerance = 18f;
        private float saturationTolerance = 45f;
        private int previewMatchCount;
        private bool preserveShading = true;
        private bool ignoreTransparent = true;
        private bool pickingSourceColor;
        private bool previewIsCurrent;
        private bool isBuildingPreview;
        private bool isBuildingMask;
        private bool previewWasCancelled;
        private bool maskWasCancelled;
        private bool maskEditing;
        private bool showMaskOverlay = true;
        private bool maskSettingsStale;
        private bool maskBrushAdds = true;
        private float maskBrushRadius = 24f;
        private Vector2 previousBrushPosition;
        private bool hasPreviousBrushPosition;
        private int maskBuildIndex;
        private int maskSelectedCount;
        private int processingIndex;
        private int buildingMatchCount;
        private ColorLab sourceLab;
        private ColorLab replacementLab;
        private Color32 sourceColor32;
        private Color32 replacementColor32;
        private float sourceHue;
        private float sourceSaturation;
        private string errorMessage;
        private Vector2 scrollPosition;

        [MenuItem("Tools/Unity Texture Color Replacer")]
        private static void Open()
        {
            GetWindow<TextureColorReplacerWindow>("Texture Color Replacer");
        }

        private void OnDisable()
        {
            StopPreviewBuild(false);
            var maskWasRunning = isBuildingMask;
            StopMaskBuild(false);
            if (maskWasRunning)
            {
                selectionMask = null;
                maskSelectedCount = 0;
                DestroyMaskOverlay();
            }
            if (hasPreviousBrushPosition)
            {
                GUIUtility.hotControl = 0;
                hasPreviousBrushPosition = false;
            }
        }

        private void OnDestroy()
        {
            StopPreviewBuild(false);
            StopMaskBuild(false);
            DestroyPreview();
            DestroyMaskOverlay();
            sourcePixels = null;
            previewPixels = null;
            selectionMask = null;
        }

        private void OnGUI()
        {
            scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);
            EditorGUILayout.LabelField("テクスチャの色を置き換えて、別のPNGとして保存します。", EditorStyles.wordWrappedLabel);
            EditorGUILayout.HelpBox("元のテクスチャは変更しません。置換後の画像はAssets内へ別ファイルで保存されます。",
                MessageType.Info);
            EditorGUILayout.Space();

            using (new EditorGUI.DisabledScope(IsBusy))
            {
                DrawSourceControls();
            }

            if (sourceTexture != null)
            {
                using (new EditorGUI.DisabledScope(IsBusy))
                {
                    DrawColorControls();
                }

                DrawMaskControls();
                DrawPreviews();
                DrawSaveControls();
            }

            if (!string.IsNullOrEmpty(errorMessage))
            {
                EditorGUILayout.HelpBox(errorMessage, MessageType.Error);
            }

            EditorGUILayout.EndScrollView();
        }

        private void DrawSourceControls()
        {
            EditorGUI.BeginChangeCheck();
            var selectedTexture = (Texture2D)EditorGUILayout.ObjectField(
                new GUIContent("元テクスチャ", "色を置き換えたいTexture2Dを選択します。"),
                sourceTexture,
                typeof(Texture2D),
                false);
            if (EditorGUI.EndChangeCheck())
            {
                sourceTexture = selectedTexture;
                sourcePixels = null;
                selectionMask = null;
                maskSelectedCount = 0;
                maskSettingsStale = false;
                maskEditing = false;
                hasPreviousBrushPosition = false;
                DestroyMaskOverlay();
                pickingSourceColor = false;
                previewIsCurrent = false;
                previewWasCancelled = false;
                maskWasCancelled = false;
                errorMessage = null;
                previewMatchCount = 0;
                DestroyPreview();
            }

            using (new EditorGUI.DisabledScope(sourceTexture == null))
            {
                if (GUILayout.Button("画像を読み込む"))
                {
                    LoadSourcePixels();
                }
            }

            if (sourceTexture != null)
            {
                EditorGUILayout.LabelField(
                    $"サイズ: {sourceTexture.width} × {sourceTexture.height}",
                    EditorStyles.miniLabel);
                var selectedPixelCount = (long)sourceTexture.width * sourceTexture.height;
                if (selectedPixelCount > 8388608)
                {
                    EditorGUILayout.HelpBox(
                        "大きな画像はメモリを多く使用します。処理は分割実行され、プレビュー中に中止できます。",
                        MessageType.Warning);
                }
                if (sourcePixels == null)
                {
                    EditorGUILayout.HelpBox("スポイトとプレビューを使うには、先に画像を読み込んでください。",
                        MessageType.Warning);
                }
            }
        }

        private void DrawColorControls()
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("色の置き換え", EditorStyles.boldLabel);
            var previousSourceColor = sourceColor;
            var previousMatchingMode = matchingMode;
            var previousDeltaEThreshold = deltaEThreshold;
            var previousHueTolerance = hueTolerance;
            var previousSaturationTolerance = saturationTolerance;
            var previousIgnoreTransparent = ignoreTransparent;
            EditorGUI.BeginChangeCheck();

            using (new EditorGUILayout.HorizontalScope())
            {
                sourceColor = EditorGUILayout.ColorField(new GUIContent("置換元の色"), sourceColor, true, true, true);
                using (new EditorGUI.DisabledScope(sourcePixels == null))
                {
                    if (GUILayout.Toggle(pickingSourceColor, "スポイト", "Button", GUILayout.Width(72f)) != pickingSourceColor)
                    {
                        pickingSourceColor = !pickingSourceColor;
                        if (pickingSourceColor)
                        {
                            maskEditing = false;
                            hasPreviousBrushPosition = false;
                        }
                    }
                }
            }

            replacementColor = EditorGUILayout.ColorField(
                new GUIContent("置換先の色"),
                replacementColor,
                true,
                true,
                true);

            matchingMode = (ColorMatchingMode)EditorGUILayout.Popup(
                new GUIContent("色の判定方式"), (int)matchingMode, MatchingModeLabels);

            if (matchingMode == ColorMatchingMode.SimilarColor)
            {
                EditorGUILayout.HelpBox(
                    "同系色モード：色相と彩度を中心に判定します。明るさの違いは判定に使わないため、明るい部分や影も拾いやすくなります。",
                    MessageType.Info);
                hueTolerance = EditorGUILayout.Slider(
                    new GUIContent("色相の許容範囲", "色相の差を度数で指定します。小さいほど近い色だけを選びます。"),
                    hueTolerance, 0f, 90f);
                saturationTolerance = EditorGUILayout.Slider(
                    new GUIContent("彩度差の許容範囲", "選択色と対象色の彩度差を指定します。"),
                    saturationTolerance, 0f, 100f);
            }
            else
            {
                EditorGUILayout.HelpBox(
                    "厳密モード：Lab色空間のΔE2000で見た目の色差を判定します。小さい値ほど指定色に近い部分だけを選びます。",
                    MessageType.Info);
                deltaEThreshold = EditorGUILayout.Slider(
                    new GUIContent("色差の許容範囲（ΔE）", "0に近いほど厳密です。値を上げると近似色も対象になります。"),
                    deltaEThreshold, 0f, 30f);
            }

            preserveShading = EditorGUILayout.ToggleLeft(
                new GUIContent("元の明るさ・陰影を保つ", "選択色と各ピクセルの明度差を、置換先の色に引き継ぎます。"),
                preserveShading);
            ignoreTransparent = EditorGUILayout.ToggleLeft(
                new GUIContent("透明ピクセルを変更しない"),
                ignoreTransparent);

            if (EditorGUI.EndChangeCheck())
            {
                previewIsCurrent = false;
                previewWasCancelled = false;
                var selectionRulesChanged = previousSourceColor != sourceColor ||
                                            previousMatchingMode != matchingMode ||
                                            !Mathf.Approximately(previousDeltaEThreshold, deltaEThreshold) ||
                                            !Mathf.Approximately(previousHueTolerance, hueTolerance) ||
                                            !Mathf.Approximately(previousSaturationTolerance, saturationTolerance) ||
                                            previousIgnoreTransparent != ignoreTransparent;
                if (selectionMask != null && selectionRulesChanged)
                {
                    maskSettingsStale = true;
                }
            }

            if (pickingSourceColor)
            {
                EditorGUILayout.HelpBox("左の元画像をクリックして、置換元の色を選んでください。",
                    MessageType.Info);
            }
        }

        private void DrawMaskControls()
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("選択マスク", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "色判定からマスクを自動生成し、元画像上をブラシで塗り足し・消去して対象範囲を調整できます。色変換はマスクの白い部分だけに適用されます。",
                MessageType.Info);

            using (new EditorGUI.DisabledScope(sourcePixels == null || IsBusy))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button(selectionMask == null ? "色判定からマスクを作成" : "色判定からマスクを再生成"))
                    {
                        BeginMaskBuild();
                    }
                    if (GUILayout.Button("空のマスクを作成"))
                    {
                        CreateEmptyMask();
                    }
                }
            }

            if (selectionMask == null)
            {
                EditorGUILayout.HelpBox("マスク未作成です。マスクを作成すると、色変換の対象範囲を直接編集できます。", MessageType.Warning);
                return;
            }

            using (new EditorGUI.DisabledScope(IsBusy))
            {
                EditorGUILayout.LabelField($"マスク対象: {maskSelectedCount:N0} / {selectionMask.Length:N0} ピクセル", EditorStyles.miniLabel);
                if (maskSettingsStale)
                {
                    EditorGUILayout.HelpBox("色判定の設定がマスク作成後に変更されています。現在のマスクを維持するか、再生成して最新の設定を反映してください。", MessageType.Warning);
                }

                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button("反転")) InvertMask();
                    if (GUILayout.Button("全消去")) ClearMask();
                    if (GUILayout.Button("マスクPNG保存")) SaveMask();
                }

                showMaskOverlay = EditorGUILayout.ToggleLeft("マスク範囲を元画像に重ねて表示", showMaskOverlay);
                var newMaskEditing = GUILayout.Toggle(maskEditing, "元画像上でマスクを編集", "Button");
                if (newMaskEditing != maskEditing)
                {
                    maskEditing = newMaskEditing;
                    hasPreviousBrushPosition = false;
                    if (maskEditing) pickingSourceColor = false;
                }
                if (maskEditing)
                {
                    maskBrushAdds = GUILayout.Toolbar(maskBrushAdds ? 0 : 1, MaskBrushLabels) == 0;
                    maskBrushRadius = EditorGUILayout.Slider(
                        new GUIContent("ブラシ半径", "元画像のピクセル単位です。表示サイズではありません。"),
                        maskBrushRadius, 1f, 200f);
                    EditorGUILayout.HelpBox(
                        "元画像の上を左ドラッグしてください。塗り足しはマスクを白く、消しゴムは黒くします。編集後に置換プレビューを更新してください。",
                        MessageType.None);
                }

                if (maskWasCancelled)
                {
                    EditorGUILayout.HelpBox("マスク生成を中止しました。マスクは未完成のため、再生成してください。", MessageType.Warning);
                }
            }
        }

        private bool IsBusy => isBuildingPreview || isBuildingMask;

        private void DrawPreviews()
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("プレビュー", EditorStyles.boldLabel);

            using (new EditorGUILayout.HorizontalScope())
            {
                DrawTexturePreview("元画像", sourceTexture, true);
                DrawTexturePreview("置換結果", previewTexture, false);
            }

            if (IsBusy)
            {
                var currentIndex = isBuildingMask ? maskBuildIndex : processingIndex;
                var progress = sourcePixels == null || sourcePixels.Length == 0
                    ? 0f
                    : (float)currentIndex / sourcePixels.Length;
                var operationLabel = isBuildingMask ? "マスクを生成中" : "色を判定中";
                EditorGUILayout.LabelField(
                    $"{operationLabel}: {currentIndex:N0} / {sourcePixels.Length:N0} ピクセル",
                    EditorStyles.miniLabel);
                EditorGUI.ProgressBar(EditorGUILayout.GetControlRect(false, 16f), progress,
                    $"{progress * 100f:0}%");
                if (GUILayout.Button("処理を中止"))
                {
                    if (isBuildingMask) StopMaskBuild(true);
                    else StopPreviewBuild(true);
                }
                return;
            }

            using (new EditorGUI.DisabledScope(sourcePixels == null || pickingSourceColor))
            {
                if (GUILayout.Button(previewIsCurrent ? "プレビューを更新" : "置換をプレビュー"))
                {
                    BeginPreviewBuild();
                }

                if (previewIsCurrent)
                {
                    if (previewMatchCount == 0)
                    {
                        EditorGUILayout.HelpBox("一致するピクセルがありません。スポイトで色を選び直すか、判定の許容範囲を調整してください。",
                            MessageType.Warning);
                    }
                    else
                    {
                        EditorGUILayout.LabelField($"置換対象: {previewMatchCount:N0} ピクセル", EditorStyles.miniLabel);
                    }
                }
            }

            if (previewWasCancelled)
            {
                EditorGUILayout.HelpBox("プレビューの作成を中止しました。設定を変更せずに再実行できます。", MessageType.Info);
            }
            else if (!previewIsCurrent && previewTexture != null)
            {
                EditorGUILayout.HelpBox("設定が変更されています。最新の結果を確認するにはプレビューを更新してください。",
                    MessageType.Warning);
            }
        }

        private void DrawTexturePreview(string label, Texture2D texture, bool canPickColor)
        {
            using (new EditorGUILayout.VerticalScope(GUILayout.MinWidth(120f)))
            {
                EditorGUILayout.LabelField(label, EditorStyles.centeredGreyMiniLabel);
                var container = GUILayoutUtility.GetRect(120f, 160f, GUILayout.ExpandWidth(true));
                GUI.Box(container, GUIContent.none);

                if (texture == null)
                {
                    GUI.Label(container, "プレビューなし", EditorStyles.centeredGreyMiniLabel);
                    return;
                }

                var imageRect = GetAspectRect(container, texture.width, texture.height);
                GUI.DrawTexture(imageRect, texture, ScaleMode.StretchToFill, true);

                if (canPickColor && showMaskOverlay && maskOverlayTexture != null && selectionMask != null)
                {
                    GUI.DrawTexture(imageRect, maskOverlayTexture, ScaleMode.StretchToFill, true);
                }

                var currentEvent = Event.current;
                var previewControlId = GUIUtility.GetControlID(
                    "TextureColorReplacerMaskBrush".GetHashCode(), FocusType.Passive, imageRect);
                if (!canPickColor || IsBusy || sourcePixels == null)
                {
                    return;
                }

                if (pickingSourceColor && currentEvent.type == EventType.MouseDown &&
                    currentEvent.button == 0 && imageRect.Contains(currentEvent.mousePosition))
                {
                    PickSourceColor(imageRect, currentEvent.mousePosition);
                    currentEvent.Use();
                    return;
                }

                if (maskEditing && selectionMask != null && currentEvent.type == EventType.MouseDown &&
                    currentEvent.button == 0 && imageRect.Contains(currentEvent.mousePosition))
                {
                    GUIUtility.hotControl = previewControlId;
                    PaintMaskFromGuiPosition(imageRect, currentEvent.mousePosition, true);
                    currentEvent.Use();
                    return;
                }

                if (maskEditing && selectionMask != null && currentEvent.type == EventType.MouseDrag &&
                    GUIUtility.hotControl == previewControlId)
                {
                    if (imageRect.Contains(currentEvent.mousePosition))
                    {
                        PaintMaskFromGuiPosition(imageRect, currentEvent.mousePosition, false);
                    }
                    else
                    {
                        hasPreviousBrushPosition = false;
                    }
                    currentEvent.Use();
                    return;
                }

                if (currentEvent.type == EventType.MouseUp && GUIUtility.hotControl == previewControlId)
                {
                    GUIUtility.hotControl = 0;
                    hasPreviousBrushPosition = false;
                    currentEvent.Use();
                }
            }
        }

        private static Rect GetAspectRect(Rect container, int width, int height)
        {
            var textureAspect = (float)width / height;
            var containerAspect = container.width / container.height;
            if (textureAspect > containerAspect)
            {
                var drawnHeight = container.width / textureAspect;
                return new Rect(container.x, container.y + (container.height - drawnHeight) * 0.5f,
                    container.width, drawnHeight);
            }

            var drawnWidth = container.height * textureAspect;
            return new Rect(container.x + (container.width - drawnWidth) * 0.5f, container.y,
                drawnWidth, container.height);
        }

        private void DrawSaveControls()
        {
            EditorGUILayout.Space();
            using (new EditorGUI.DisabledScope(previewTexture == null || !previewIsCurrent || IsBusy))
            {
                if (GUILayout.Button("PNGとして別名保存"))
                {
                    SavePreview();
                }
            }
        }

        private void LoadSourcePixels()
        {
            errorMessage = null;
            previewWasCancelled = false;
            DestroyPreview();
            DestroyMaskOverlay();
            selectionMask = null;
            maskSelectedCount = 0;
            maskSettingsStale = false;
            maskEditing = false;
            maskWasCancelled = false;
            previewIsCurrent = false;
            previewMatchCount = 0;

            if (sourceTexture == null)
            {
                sourcePixels = null;
                return;
            }

            var pixelCount = (long)sourceTexture.width * sourceTexture.height;
            if (pixelCount <= 0 || pixelCount > MaximumPixelCount)
            {
                sourcePixels = null;
                errorMessage = "テクスチャのサイズが対応範囲外です（上限: 16,777,216ピクセル）。Unityで解像度を下げたコピーを作成してください。";
                return;
            }

            try
            {
                sourcePixels = ReadTexturePixels(sourceTexture);
                if (sourcePixels == null || sourcePixels.Length != pixelCount)
                {
                    sourcePixels = null;
                    throw new InvalidOperationException("読み込んだピクセル数がテクスチャのサイズと一致しません。");
                }

                Repaint();
            }
            catch (Exception exception)
            {
                sourcePixels = null;
                errorMessage = $"画像を読み込めませんでした: {exception.Message}";
                Debug.LogException(exception);
            }
        }

        private static Color32[] ReadTexturePixels(Texture2D texture)
        {
            if (texture == null)
            {
                throw new ArgumentNullException(nameof(texture));
            }

            // ReadableなテクスチャはGPU転送を行わずに取得し、余分な一時メモリを抑えます。
            if (texture.isReadable)
            {
                var pixels = texture.GetPixels32();
                // Lab判定とPNG出力はsRGBを基準にするため、linearデータはsRGB値へ正規化します。
                if (!texture.isDataSRGB)
                {
                    ConvertLinearPixelsToSrgb(pixels);
                }

                return pixels;
            }

            var previousActive = RenderTexture.active;
            RenderTexture renderTexture = null;
            Texture2D readableTexture = null;

            try
            {
                renderTexture = RenderTexture.GetTemporary(
                    texture.width,
                    texture.height,
                    0,
                    RenderTextureFormat.ARGB32,
                    RenderTextureReadWrite.sRGB);
                if (renderTexture == null)
                {
                    throw new InvalidOperationException("一時RenderTextureを作成できませんでした。");
                }

                readableTexture = new Texture2D(
                    texture.width,
                    texture.height,
                    TextureFormat.RGBA32,
                    false,
                    false);
                Graphics.Blit(texture, renderTexture);
                RenderTexture.active = renderTexture;
                readableTexture.ReadPixels(new Rect(0, 0, texture.width, texture.height), 0, 0, false);
                readableTexture.Apply(false, false);
                var pixels = readableTexture.GetPixels32();
                // GammaプロジェクトではRenderTextureReadWriteの変換が行われないため、linear入力を明示変換します。
                if (!texture.isDataSRGB && QualitySettings.activeColorSpace == ColorSpace.Gamma)
                {
                    ConvertLinearPixelsToSrgb(pixels);
                }

                return pixels;
            }
            finally
            {
                RenderTexture.active = previousActive;
                if (renderTexture != null)
                {
                    RenderTexture.ReleaseTemporary(renderTexture);
                }
                if (readableTexture != null)
                {
                    DestroyImmediate(readableTexture);
                }
            }
        }

        private void PickSourceColor(Rect imageRect, Vector2 mousePosition)
        {
            var x = Mathf.Clamp(
                Mathf.FloorToInt((mousePosition.x - imageRect.x) / imageRect.width * sourceTexture.width),
                0,
                sourceTexture.width - 1);
            var y = Mathf.Clamp(
                Mathf.FloorToInt((imageRect.yMax - mousePosition.y) / imageRect.height * sourceTexture.height),
                0,
                sourceTexture.height - 1);
            sourceColor = sourcePixels[y * sourceTexture.width + x];
            pickingSourceColor = false;
            previewIsCurrent = false;
            if (selectionMask != null) maskSettingsStale = true;
            previewWasCancelled = false;
            Repaint();
        }

        private void BeginPreviewBuild()
        {
            if (sourceTexture == null || sourcePixels == null || sourcePixels.Length == 0)
            {
                errorMessage = "先に元画像を読み込んでください。";
                return;
            }

            StopPreviewBuild(false);
            try
            {
                previewPixels = new Color32[sourcePixels.Length];
                processingIndex = 0;
                buildingMatchCount = 0;
                sourceColor32 = (Color32)sourceColor;
                replacementColor32 = (Color32)replacementColor;
                sourceLab = RgbToLab(sourceColor32);
                replacementLab = RgbToLab(replacementColor32);
                Color.RGBToHSV((Color)sourceColor32, out sourceHue, out sourceSaturation, out _);
                previewIsCurrent = false;
                previewWasCancelled = false;
                errorMessage = null;
                isBuildingPreview = true;
                EditorApplication.update += ProcessPreviewChunk;
                Repaint();
            }
            catch (Exception exception)
            {
                previewPixels = null;
                isBuildingPreview = false;
                errorMessage = $"プレビューを開始できませんでした: {exception.Message}";
                Debug.LogException(exception);
            }
        }

        private void ProcessPreviewChunk()
        {
            if (!isBuildingPreview)
            {
                return;
            }

            try
            {
                var endIndex = Math.Min(processingIndex + PreviewChunkSize, sourcePixels.Length);
                for (; processingIndex < endIndex; processingIndex++)
                {
                    var pixel = sourcePixels[processingIndex];
                    if (ignoreTransparent && pixel.a == 0)
                    {
                        previewPixels[processingIndex] = pixel;
                        continue;
                    }

                    if (selectionMask != null)
                    {
                        var maskAmount = selectionMask[processingIndex] / 255f;
                        if (maskAmount <= 0f)
                        {
                            previewPixels[processingIndex] = pixel;
                            continue;
                        }

                        var recolored = ReplacePixelColor(pixel, default, false);
                        previewPixels[processingIndex] = BlendPixel(pixel, recolored, maskAmount);
                        buildingMatchCount++;
                        continue;
                    }

                    if (!IsPixelMatch(pixel, out var pixelLab, out var hasPixelLab))
                    {
                        previewPixels[processingIndex] = pixel;
                        continue;
                    }

                    buildingMatchCount++;
                    previewPixels[processingIndex] = ReplacePixelColor(pixel, pixelLab, hasPixelLab);
                }

                var progress = (float)processingIndex / sourcePixels.Length;
                if (EditorUtility.DisplayCancelableProgressBar(
                        "テクスチャの色を置き換え中",
                        $"{processingIndex:N0} / {sourcePixels.Length:N0} ピクセル",
                        progress))
                {
                    StopPreviewBuild(true);
                    return;
                }

                Repaint();
                if (processingIndex >= sourcePixels.Length)
                {
                    CompletePreviewBuild();
                }
            }
            catch (Exception exception)
            {
                StopPreviewBuild(false);
                previewPixels = null;
                previewIsCurrent = false;
                errorMessage = $"プレビューを作成できませんでした: {exception.Message}";
                Debug.LogException(exception);
                Repaint();
            }
        }

        private bool IsPixelMatch(Color32 pixel, out ColorLab pixelLab, out bool hasPixelLab)
        {
            pixelLab = default;
            hasPixelLab = false;
            if (matchingMode == ColorMatchingMode.Precise)
            {
                pixelLab = RgbToLab(pixel);
                hasPixelLab = true;
                return DeltaE2000(pixelLab, sourceLab) <= deltaEThreshold;
            }

            Color.RGBToHSV((Color)pixel, out var pixelHue, out var pixelSaturation, out _);
            var saturationDifference = Mathf.Abs(pixelSaturation - sourceSaturation) * 100f;
            if (saturationDifference > saturationTolerance)
            {
                return false;
            }

            // 彩度が非常に低い色では色相が不安定になるため、色相比較を省きます。
            const float minimumReliableSaturation = 0.05f;
            if (pixelSaturation < minimumReliableSaturation || sourceSaturation < minimumReliableSaturation)
            {
                return true;
            }

            var hueDifference = Mathf.Abs(pixelHue - sourceHue);
            hueDifference = Mathf.Min(hueDifference, 1f - hueDifference) * 360f;
            return hueDifference <= hueTolerance;
        }

        private Color32 ReplacePixelColor(Color32 pixel, ColorLab pixelLab, bool hasPixelLab)
        {
            if (!preserveShading)
            {
                return new Color32(
                    replacementColor32.r,
                    replacementColor32.g,
                    replacementColor32.b,
                    pixel.a);
            }

            if (!hasPixelLab)
            {
                pixelLab = RgbToLab(pixel);
            }

            var outputLab = new ColorLab(
                Clamp((float)(replacementLab.L + pixelLab.L - sourceLab.L), 0f, 100f),
                replacementLab.A,
                replacementLab.B);
            return LabToRgb(outputLab, pixel.a);
        }

        private void CompletePreviewBuild()
        {
            Texture2D newPreview = null;
            try
            {
                newPreview = new Texture2D(
                    sourceTexture.width,
                    sourceTexture.height,
                    TextureFormat.RGBA32,
                    false,
                    false);
                newPreview.name = sourceTexture.name + " Color Replacement Preview";
                newPreview.SetPixels32(previewPixels);
                newPreview.Apply(false, false);

                DestroyPreview();
                previewTexture = newPreview;
                newPreview = null;
                previewMatchCount = buildingMatchCount;
                previewIsCurrent = true;
                previewWasCancelled = false;
                errorMessage = null;
            }
            finally
            {
                if (newPreview != null)
                {
                    DestroyImmediate(newPreview);
                }

                StopPreviewBuild(false);
                previewPixels = null;
                Repaint();
            }
        }

        private void StopPreviewBuild(bool cancelled)
        {
            if (isBuildingPreview)
            {
                EditorApplication.update -= ProcessPreviewChunk;
                EditorUtility.ClearProgressBar();
            }

            isBuildingPreview = false;
            previewPixels = null;
            if (cancelled)
            {
                previewIsCurrent = false;
                previewWasCancelled = true;
                Repaint();
            }
        }


        private void BeginMaskBuild()
        {
            if (sourcePixels == null || sourcePixels.Length == 0)
            {
                errorMessage = "先に元画像を読み込んでください。";
                return;
            }

            StopPreviewBuild(false);
            StopMaskBuild(false);
            DestroyMaskOverlay();
            try
            {
                selectionMask = new byte[sourcePixels.Length];
                maskBuildIndex = 0;
                maskSelectedCount = 0;
                sourceColor32 = (Color32)sourceColor;
                replacementColor32 = (Color32)replacementColor;
                sourceLab = RgbToLab(sourceColor32);
                replacementLab = RgbToLab(replacementColor32);
                Color.RGBToHSV((Color)sourceColor32, out sourceHue, out sourceSaturation, out _);
                previewIsCurrent = false;
                maskWasCancelled = false;
                maskSettingsStale = false;
                maskEditing = false;
                hasPreviousBrushPosition = false;
                errorMessage = null;
                isBuildingMask = true;
                EditorApplication.update += ProcessMaskChunk;
                Repaint();
            }
            catch (Exception exception)
            {
                selectionMask = null;
                isBuildingMask = false;
                errorMessage = $"マスク生成を開始できませんでした: {exception.Message}";
                Debug.LogException(exception);
            }
        }

        private void ProcessMaskChunk()
        {
            if (!isBuildingMask)
            {
                return;
            }

            try
            {
                var endIndex = Math.Min(maskBuildIndex + PreviewChunkSize, sourcePixels.Length);
                for (; maskBuildIndex < endIndex; maskBuildIndex++)
                {
                    var pixel = sourcePixels[maskBuildIndex];
                    if (ignoreTransparent && pixel.a == 0)
                    {
                        selectionMask[maskBuildIndex] = 0;
                        continue;
                    }

                    var matches = IsPixelMatch(pixel, out _, out _);
                    selectionMask[maskBuildIndex] = matches ? (byte)255 : (byte)0;
                    if (matches) maskSelectedCount++;
                }

                var progress = (float)maskBuildIndex / sourcePixels.Length;
                if (EditorUtility.DisplayCancelableProgressBar(
                        "選択マスクを生成中",
                        $"{maskBuildIndex:N0} / {sourcePixels.Length:N0} ピクセル",
                        progress))
                {
                    StopMaskBuild(true);
                    selectionMask = null;
                    maskSelectedCount = 0;
                    return;
                }

                Repaint();
                if (maskBuildIndex >= sourcePixels.Length)
                {
                    CompleteMaskBuild();
                }
            }
            catch (Exception exception)
            {
                StopMaskBuild(false);
                selectionMask = null;
                maskSelectedCount = 0;
                errorMessage = $"マスクを生成できませんでした: {exception.Message}";
                Debug.LogException(exception);
                Repaint();
            }
        }

        private void CompleteMaskBuild()
        {
            try
            {
                RebuildMaskOverlay();
                maskSettingsStale = false;
                maskWasCancelled = false;
                previewIsCurrent = false;
                errorMessage = null;
            }
            catch (Exception exception)
            {
                selectionMask = null;
                maskSelectedCount = 0;
                DestroyMaskOverlay();
                errorMessage = $"マスク表示を作成できませんでした: {exception.Message}";
                Debug.LogException(exception);
            }
            finally
            {
                StopMaskBuild(false);
                Repaint();
            }
        }

        private void StopMaskBuild(bool cancelled)
        {
            if (isBuildingMask)
            {
                EditorApplication.update -= ProcessMaskChunk;
                EditorUtility.ClearProgressBar();
            }

            isBuildingMask = false;
            if (cancelled)
            {
                maskWasCancelled = true;
                previewIsCurrent = false;
                Repaint();
            }
        }

        private void RebuildMaskOverlay()
        {
            if (selectionMask == null || sourceTexture == null)
            {
                DestroyMaskOverlay();
                return;
            }

            var scale = Mathf.Min(1f, MaximumMaskOverlaySide / (float)Mathf.Max(sourceTexture.width, sourceTexture.height));
            var overlayWidth = Mathf.Max(1, Mathf.RoundToInt(sourceTexture.width * scale));
            var overlayHeight = Mathf.Max(1, Mathf.RoundToInt(sourceTexture.height * scale));
            var overlayPixels = new Color32[overlayWidth * overlayHeight];
            var selected = new Color32(30, 190, 255, 110);
            var transparent = new Color32(0, 0, 0, 0);

            for (var y = 0; y < overlayHeight; y++)
            {
                var sourceY = Mathf.Min(sourceTexture.height - 1, (int)((y + 0.5f) / overlayHeight * sourceTexture.height));
                for (var x = 0; x < overlayWidth; x++)
                {
                    var sourceX = Mathf.Min(sourceTexture.width - 1, (int)((x + 0.5f) / overlayWidth * sourceTexture.width));
                    overlayPixels[y * overlayWidth + x] = selectionMask[sourceY * sourceTexture.width + sourceX] > 0
                        ? selected
                        : transparent;
                }
            }

            if (maskOverlayTexture == null || maskOverlayTexture.width != overlayWidth || maskOverlayTexture.height != overlayHeight)
            {
                DestroyMaskOverlay();
                maskOverlayTexture = new Texture2D(overlayWidth, overlayHeight, TextureFormat.RGBA32, false, true)
                {
                    name = "Texture Color Replacer Mask Overlay",
                    hideFlags = HideFlags.HideAndDontSave
                };
            }

            maskOverlayTexture.SetPixels32(overlayPixels);
            maskOverlayTexture.Apply(false, false);
        }

        private void PaintMaskFromGuiPosition(Rect imageRect, Vector2 mousePosition, bool newStroke)
        {
            var pixelPosition = new Vector2(
                Mathf.Clamp((mousePosition.x - imageRect.x) / imageRect.width * sourceTexture.width, 0f, sourceTexture.width - 1f),
                Mathf.Clamp((imageRect.yMax - mousePosition.y) / imageRect.height * sourceTexture.height, 0f, sourceTexture.height - 1f));

            if (newStroke || !hasPreviousBrushPosition)
            {
                PaintMaskCircle(pixelPosition);
            }
            else
            {
                var distance = Vector2.Distance(previousBrushPosition, pixelPosition);
                var spacing = Mathf.Max(1f, maskBrushRadius * 0.35f);
                var steps = Mathf.Max(1, Mathf.CeilToInt(distance / spacing));
                for (var step = 1; step <= steps; step++)
                {
                    PaintMaskCircle(Vector2.Lerp(previousBrushPosition, pixelPosition, step / (float)steps));
                }
            }

            previousBrushPosition = pixelPosition;
            hasPreviousBrushPosition = true;
            RebuildMaskOverlay();
            previewIsCurrent = false;
            Repaint();
        }

        private void PaintMaskCircle(Vector2 center)
        {
            var radius = Mathf.Max(1, Mathf.RoundToInt(maskBrushRadius));
            var centerX = Mathf.RoundToInt(center.x);
            var centerY = Mathf.RoundToInt(center.y);
            var minX = Mathf.Max(0, centerX - radius);
            var maxX = Mathf.Min(sourceTexture.width - 1, centerX + radius);
            var minY = Mathf.Max(0, centerY - radius);
            var maxY = Mathf.Min(sourceTexture.height - 1, centerY + radius);
            var radiusSquared = radius * radius;
            var target = maskBrushAdds ? (byte)255 : (byte)0;

            for (var y = minY; y <= maxY; y++)
            {
                var dy = y - centerY;
                for (var x = minX; x <= maxX; x++)
                {
                    var dx = x - centerX;
                    if (dx * dx + dy * dy > radiusSquared) continue;
                    var index = y * sourceTexture.width + x;
                    var previous = selectionMask[index];
                    if (previous == target) continue;
                    if (previous == 0 && target > 0) maskSelectedCount++;
                    else if (previous > 0 && target == 0) maskSelectedCount--;
                    selectionMask[index] = target;
                }
            }
        }

        private void CreateEmptyMask()
        {
            if (sourcePixels == null || sourcePixels.Length == 0) return;
            try
            {
                selectionMask = new byte[sourcePixels.Length];
                maskSelectedCount = 0;
                maskSettingsStale = false;
                maskWasCancelled = false;
                maskEditing = true;
                pickingSourceColor = false;
                hasPreviousBrushPosition = false;
                previewIsCurrent = false;
                RebuildMaskOverlay();
                errorMessage = null;
            }
            catch (Exception exception)
            {
                selectionMask = null;
                maskSelectedCount = 0;
                DestroyMaskOverlay();
                errorMessage = $"空のマスクを作成できませんでした: {exception.Message}";
                Debug.LogException(exception);
            }
        }

        private void InvertMask()
        {
            if (selectionMask == null) return;
            maskSelectedCount = 0;
            for (var i = 0; i < selectionMask.Length; i++)
            {
                selectionMask[i] = selectionMask[i] == 0 ? (byte)255 : (byte)0;
                if (selectionMask[i] > 0) maskSelectedCount++;
            }
            RebuildMaskOverlay();
            previewIsCurrent = false;
        }

        private void ClearMask()
        {
            if (selectionMask == null) return;
            Array.Clear(selectionMask, 0, selectionMask.Length);
            maskSelectedCount = 0;
            RebuildMaskOverlay();
            previewIsCurrent = false;
        }

        private void SaveMask()
        {
            if (selectionMask == null || sourceTexture == null) return;
            var sourcePath = AssetDatabase.GetAssetPath(sourceTexture);
            var sourceDirectory = sourcePath.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase)
                ? Path.GetDirectoryName(sourcePath)?.Replace('\\', '/') ?? "Assets"
                : "Assets";
            var defaultName = Path.GetFileNameWithoutExtension(sourceTexture.name) + "_mask";
            var outputPath = EditorUtility.SaveFilePanelInProject(
                "選択マスクを保存", defaultName, "png", "白が選択範囲、黒が対象外のマスク画像を保存します。", sourceDirectory);
            if (string.IsNullOrEmpty(outputPath)) return;

            Texture2D maskTexture = null;
            try
            {
                maskTexture = new Texture2D(sourceTexture.width, sourceTexture.height, TextureFormat.RGBA32, false, true);
                var pixels = new Color32[selectionMask.Length];
                for (var i = 0; i < selectionMask.Length; i++)
                {
                    var value = selectionMask[i];
                    pixels[i] = new Color32(value, value, value, 255);
                }
                maskTexture.SetPixels32(pixels);
                maskTexture.Apply(false, false);
                File.WriteAllBytes(outputPath, maskTexture.EncodeToPNG());
                AssetDatabase.ImportAsset(outputPath, ImportAssetOptions.ForceUpdate);
                EditorUtility.DisplayDialog("保存しました", $"マスクPNGを保存しました:\n{outputPath}", "OK");
                errorMessage = null;
            }
            catch (Exception exception)
            {
                errorMessage = $"マスクを保存できませんでした: {exception.Message}";
                Debug.LogException(exception);
            }
            finally
            {
                if (maskTexture != null) DestroyImmediate(maskTexture);
            }
        }

        private void DestroyMaskOverlay()
        {
            if (maskOverlayTexture == null) return;
            DestroyImmediate(maskOverlayTexture);
            maskOverlayTexture = null;
        }

        private static Color32 BlendPixel(Color32 original, Color32 replacement, float amount)
        {
            amount = Mathf.Clamp01(amount);
            return new Color32(
                (byte)Mathf.RoundToInt(Mathf.Lerp(original.r, replacement.r, amount)),
                (byte)Mathf.RoundToInt(Mathf.Lerp(original.g, replacement.g, amount)),
                (byte)Mathf.RoundToInt(Mathf.Lerp(original.b, replacement.b, amount)),
                original.a);
        }

        private static void ConvertLinearPixelsToSrgb(Color32[] pixels)
        {
            for (var index = 0; index < pixels.Length; index++)
            {
                var pixel = pixels[index];
                pixel.r = ToByte(LinearToSrgb(pixel.r / 255.0) * 255.0);
                pixel.g = ToByte(LinearToSrgb(pixel.g / 255.0) * 255.0);
                pixel.b = ToByte(LinearToSrgb(pixel.b / 255.0) * 255.0);
                pixels[index] = pixel;
            }
        }

        private static ColorLab RgbToLab(Color32 color)
        {
            var red = SrgbLinearLookup[color.r];
            var green = SrgbLinearLookup[color.g];
            var blue = SrgbLinearLookup[color.b];

            var x = (0.4124564 * red + 0.3575761 * green + 0.1804375 * blue) / 0.95047;
            var y = 0.2126729 * red + 0.7151522 * green + 0.0721750 * blue;
            var z = (0.0193339 * red + 0.1191920 * green + 0.9503041 * blue) / 1.08883;

            var fx = LabPivot(x);
            var fy = LabPivot(y);
            var fz = LabPivot(z);
            return new ColorLab(116.0 * fy - 16.0, 500.0 * (fx - fy), 200.0 * (fy - fz));
        }

        private static Color32 LabToRgb(ColorLab lab, byte alpha)
        {
            var fy = (lab.L + 16.0) / 116.0;
            var fx = fy + lab.A / 500.0;
            var fz = fy - lab.B / 200.0;

            var x = 0.95047 * InverseLabPivot(fx);
            var y = InverseLabPivot(fy);
            var z = 1.08883 * InverseLabPivot(fz);

            var red = 3.2404542 * x - 1.5371385 * y - 0.4985314 * z;
            var green = -0.9692660 * x + 1.8760108 * y + 0.0415560 * z;
            var blue = 0.0556434 * x - 0.2040259 * y + 1.0572252 * z;

            return new Color32(
                ToByte(LinearToSrgb(red) * 255.0),
                ToByte(LinearToSrgb(green) * 255.0),
                ToByte(LinearToSrgb(blue) * 255.0),
                alpha);
        }

        private static double DeltaE2000(ColorLab first, ColorLab second)
        {
            const double twentyFiveToSeventh = 6103515625.0;
            var c1 = Math.Sqrt(first.A * first.A + first.B * first.B);
            var c2 = Math.Sqrt(second.A * second.A + second.B * second.B);
            var meanChroma = (c1 + c2) * 0.5;
            var meanChroma7 = Pow7(meanChroma);
            var g = 0.5 * (1.0 - Math.Sqrt(meanChroma7 / (meanChroma7 + twentyFiveToSeventh)));

            var a1Prime = (1.0 + g) * first.A;
            var a2Prime = (1.0 + g) * second.A;
            var c1Prime = Math.Sqrt(a1Prime * a1Prime + first.B * first.B);
            var c2Prime = Math.Sqrt(a2Prime * a2Prime + second.B * second.B);
            var h1Prime = HueAngle(a1Prime, first.B);
            var h2Prime = HueAngle(a2Prime, second.B);

            var deltaLPrime = second.L - first.L;
            var deltaCPrime = c2Prime - c1Prime;
            var deltaHuePrime = 0.0;
            if (c1Prime * c2Prime > 0.0)
            {
                deltaHuePrime = h2Prime - h1Prime;
                if (deltaHuePrime > 180.0) deltaHuePrime -= 360.0;
                else if (deltaHuePrime < -180.0) deltaHuePrime += 360.0;
            }

            var deltaHPrime = 2.0 * Math.Sqrt(c1Prime * c2Prime) *
                              Math.Sin(DegreesToRadians(deltaHuePrime * 0.5));
            var meanLPrime = (first.L + second.L) * 0.5;
            var meanCPrime = (c1Prime + c2Prime) * 0.5;

            double meanHuePrime;
            if (c1Prime * c2Prime == 0.0)
            {
                meanHuePrime = h1Prime + h2Prime;
            }
            else if (Math.Abs(h1Prime - h2Prime) <= 180.0)
            {
                meanHuePrime = (h1Prime + h2Prime) * 0.5;
            }
            else if (h1Prime + h2Prime < 360.0)
            {
                meanHuePrime = (h1Prime + h2Prime + 360.0) * 0.5;
            }
            else
            {
                meanHuePrime = (h1Prime + h2Prime - 360.0) * 0.5;
            }

            var t = 1.0
                    - 0.17 * Math.Cos(DegreesToRadians(meanHuePrime - 30.0))
                    + 0.24 * Math.Cos(DegreesToRadians(2.0 * meanHuePrime))
                    + 0.32 * Math.Cos(DegreesToRadians(3.0 * meanHuePrime + 6.0))
                    - 0.20 * Math.Cos(DegreesToRadians(4.0 * meanHuePrime - 63.0));

            var deltaThetaOffset = (meanHuePrime - 275.0) / 25.0;
            var deltaTheta = 30.0 * Math.Exp(-(deltaThetaOffset * deltaThetaOffset));
            var meanCPrime7 = Pow7(meanCPrime);
            var rotationC = 2.0 * Math.Sqrt(meanCPrime7 / (meanCPrime7 + twentyFiveToSeventh));
            var lightnessOffset = meanLPrime - 50.0;
            var sL = 1.0 + 0.015 * lightnessOffset * lightnessOffset /
                     Math.Sqrt(20.0 + lightnessOffset * lightnessOffset);
            var sC = 1.0 + 0.045 * meanCPrime;
            var sH = 1.0 + 0.015 * meanCPrime * t;
            var rotationT = -Math.Sin(DegreesToRadians(2.0 * deltaTheta)) * rotationC;

            var lTerm = deltaLPrime / sL;
            var cTerm = deltaCPrime / sC;
            var hTerm = deltaHPrime / sH;
            var squared = lTerm * lTerm + cTerm * cTerm + hTerm * hTerm + rotationT * cTerm * hTerm;
            return Math.Sqrt(Math.Max(0.0, squared));
        }

        private static double[] CreateSrgbLinearLookup()
        {
            var lookup = new double[256];
            for (var index = 0; index < lookup.Length; index++)
            {
                var value = index / 255.0;
                lookup[index] = value <= 0.04045
                    ? value / 12.92
                    : Math.Pow((value + 0.055) / 1.055, 2.4);
            }

            return lookup;
        }

        private static double Pow7(double value)
        {
            var squared = value * value;
            var fourth = squared * squared;
            return fourth * squared * value;
        }

        private static double LinearToSrgb(double value)
        {
            value = Math.Max(0.0, Math.Min(1.0, value));
            return value <= 0.0031308 ? value * 12.92 : 1.055 * Math.Pow(value, 1.0 / 2.4) - 0.055;
        }

        private static double LabPivot(double value)
        {
            const double delta = 6.0 / 29.0;
            var deltaCubed = delta * delta * delta;
            return value > deltaCubed
                ? Math.Pow(value, 1.0 / 3.0)
                : value / (3.0 * delta * delta) + 4.0 / 29.0;
        }

        private static double InverseLabPivot(double value)
        {
            const double delta = 6.0 / 29.0;
            return value > delta
                ? value * value * value
                : 3.0 * delta * delta * (value - 4.0 / 29.0);
        }

        private static double HueAngle(double a, double b)
        {
            if (a == 0.0 && b == 0.0)
            {
                return 0.0;
            }

            var angle = Math.Atan2(b, a) * 180.0 / Math.PI;
            return angle < 0.0 ? angle + 360.0 : angle;
        }

        private static double DegreesToRadians(double degrees)
        {
            return degrees * Math.PI / 180.0;
        }

        private static byte ToByte(double value)
        {
            return (byte)Math.Max(0.0, Math.Min(255.0, Math.Round(value)));
        }

        private static float Clamp(float value, float minimum, float maximum)
        {
            return Mathf.Max(minimum, Mathf.Min(maximum, value));
        }

        private void SavePreview()
        {
            if (previewTexture == null || !previewIsCurrent)
            {
                errorMessage = "最新のプレビューを作成してから保存してください。";
                return;
            }

            var sourcePath = AssetDatabase.GetAssetPath(sourceTexture);
            var sourceDirectory = sourcePath.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase)
                ? Path.GetDirectoryName(sourcePath)?.Replace('\\', '/') ?? "Assets"
                : "Assets";
            var defaultName = Path.GetFileNameWithoutExtension(sourceTexture.name) + "_recolored";
            var outputPath = EditorUtility.SaveFilePanelInProject(
                "置換後テクスチャを保存",
                defaultName,
                "png",
                "置換後のテクスチャをPNGとして別ファイルに保存します。",
                sourceDirectory);
            if (string.IsNullOrEmpty(outputPath))
            {
                return;
            }

            if (string.Equals(outputPath, sourcePath, StringComparison.OrdinalIgnoreCase))
            {
                errorMessage = "元のテクスチャは上書きできません。別のファイル名を指定してください。";
                return;
            }

            try
            {
                File.WriteAllBytes(outputPath, previewTexture.EncodeToPNG());
                AssetDatabase.ImportAsset(outputPath, ImportAssetOptions.ForceUpdate);
                errorMessage = null;
                EditorUtility.DisplayDialog("保存しました", $"PNGを保存しました:\n{outputPath}", "OK");
            }
            catch (Exception exception)
            {
                errorMessage = $"PNGを保存できませんでした: {exception.Message}";
                Debug.LogException(exception);
            }
        }

        private void DestroyPreview()
        {
            if (previewTexture == null)
            {
                return;
            }

            DestroyImmediate(previewTexture);
            previewTexture = null;
        }

        private struct ColorLab
        {
            public readonly double L;
            public readonly double A;
            public readonly double B;

            public ColorLab(double l, double a, double b)
            {
                L = l;
                A = a;
                B = b;
            }
        }
    }
}
