# CHANGELOG — Unity Assist Tools Release 1.3.0

## 共通
- 3つのツールを独立したUPMパッケージとして整理し、既存のpackage nameを維持。
- 各EditorフォルダーにEditor専用Assembly Definitionを追加。
- 空の `なんか.py` と、別パッケージ由来の誤配置 `.meta` を除去。
- 元のアップロードZIPと前回版の関連ソース／ZIPをRollbackフォルダーに保存。

## Project File Colorizer 1.0.1
- 既存のProjectウィンドウ色分け、カテゴリ色設定、EditorPrefs保存を維持。
- UPM Editor専用Assembly Definitionを追加。

## Transform Helper 1.0.2
- `OnSelectionChange` で選択数表示を更新。
- Undo/Redo実行後にウィンドウを再描画。
- 親と子を同時選択したとき、選択された親の子を個別適用対象から除外。
- NaN／Infinity入力の検査と既定値への復帰。

## Texture Color Replacer 1.3.0
- 前回のマスク編集機能を統合（色判定による自動マスク、空マスク、ブラシ、消しゴム、反転、全消去、マスクPNG出力、オーバーレイ）。
- OKLab色差判定を統合。
- 元画像の始点・終点色を変換先の始点・終点色に対応させる色の流れ変換を統合。
- 進捗・キャンセル可能なチャンク処理を維持。
- 元画像と同じパスへの保存を拒否。
- 読み込み上限16,777,216ピクセル。
