# Unity Assist Tools — Release 1.3.0

このリリースは、3つの独立したUnity UPMパッケージを更新したものです。既存のパッケージ名（UPM ID）は維持しているため、旧版から置き換えて導入できます。

## パッケージ一覧

| ツール | UPM ID | バージョン | 主な変更 |
|---|---|---:|---|
| Project File Colorizer | `com.unityassist.project-file-colorizer` | 1.0.1 | Editor専用Assembly Definition追加、既存機能維持 |
| Transform Helper | `com.unityassist.transform-tool` | 1.0.2 | 選択更新、親子二重適用防止、数値検査、Undo/Redo再描画 |
| Texture Color Replacer | `com.unityassist.texture-color-replacer` | 1.3.0 | OKLab判定・色の流れ変換とマスク編集を統合 |

## 導入方法

1. 作業中のUnityプロジェクトを複製するか、少なくとも `Assets` と `Packages/manifest.json` をバックアップします。
2. Unityの **Window > Package Manager > In Project** で、旧版の3パッケージを削除します。利用中のプロジェクトに旧版の同名パッケージが二重登録されないようにします。
3. Package Managerの **＋ > Add package from disk...** を選び、次の3つをそれぞれ追加します。
   - `Packages/UnityProjectFileColorizer/package.json`
   - `Packages/UnityTransformHelper/package.json`
   - `Packages/UnityTextureColorReplacer/package.json`
4. Unityのコンパイル完了後、`Tools` メニューに各ツールが表示されることを確認します。
5. まず複製したテスト用プロジェクトで操作し、問題がなければ本番プロジェクトへ導入してください。

## 不具合が出た場合の戻し方

### A. 今回の元ZIPに戻す（推奨）

1. Package Managerで今回の3パッケージを削除します。
2. `Rollback/unityツール軍_original_2026-11-10.zip` を別の場所に展開します。
3. 展開先の各フォルダーにある `package.json` を、Package Managerの **＋ > Add package from disk...** からそれぞれ再登録します。
4. コンパイルエラーが消え、以前のメニューと機能が戻ったことを確認します。

この元ZIPは今回の修正版作成時に内容を変更せず、そのまま保存しています。

### B. 前回の統合版へ戻す

`Rollback/PreviousChanges/UnityAssistTools_1_2_0.zip` を展開し、その中の `package.json` を指定して導入します。これは今回の元ZIPとパッケージ構成が異なる統合版です。Aの元ZIPへの復旧を優先してください。

### C. 前回のテクスチャ機能だけを参照する

`Rollback/PreviousChanges/` にマスク版と色精度版のソース／ZIPを同梱しています。個別機能の確認用であり、3ツール全体を戻すためのパッケージではありません。

## 注意点

- 元のZIPは更新・上書きしていません。
- 画像置換は元テクスチャを直接変更せず、別PNGへ保存します。
- Transformの親子同時選択時は、選択された親を優先し、選択された子には個別操作を重ねません。
- この環境ではUnity EditorとC#コンパイラを起動できないため、Unity上での実コンパイル・画面操作は未実施です。ZIP整合性、JSON、ソース構造、静的チェックを行っています。導入前に複製プロジェクトでの確認が必要です。
