# Build / Change Report — Unity Assist Texture Color Engine 0.1.0-preview.11 Neutral Gradient Continuity Experiment

## Base

- Base package: `0.1.0-preview.10`
- Stable baseline: `0.1.0-preview.10` (not overwritten)
- Scope: low-chroma / near-neutral gradients in single-color and two-point modes.

## Source findings

- In single-color neutral selection, the previous lightness gate was fully applied only through a 0.075 OKLab lightness delta and reached zero at 0.14. The white-to-warm-gray source colors shown in the user's earlier screenshot have an OKLab lightness delta of about 0.17085, so the darker end is excluded when only the bright point is sampled.
- In two-point near-neutral selection, those anchors yield an a/b corridor of about 0.01585, with full weight only through about 0.00872. Small tint variations in clothing textures can therefore become large areas of partial conversion.
- A previous experiment changed only the transition curve and did not widen these root constraints sufficiently.

## Runtime changes

- Single-color neutral path: lightness weight remains full through a 0.18 delta and fades to zero at 0.26; OKLab a/b proximity and chroma gates reject clearly tinted distractors.
- Two-point neutral path: a/b tolerance is at least 0.03 (maximum 0.045); full-weight threshold is 65% of that tolerance.
- Destination-color construction, shading residual formulas, OKLab projection, target interpolation, gamut mapping, Editor UI, and non-neutral selection paths are unchanged.

## Numerical checks

- Synthetic white-to-warm-gray single-color gradient using the screenshot's source RGB values: preview.10 selected 14/31 ramp pixels at full weight, 10 partially, and 7 not at all. The candidate selected all 31 ramp pixels at full weight. A vivid warm distractor and a far-dark neutral sample remained excluded in the numerical model.
- Synthetic near-neutral two-point gradient with a small a/b tint drift: preview.10 fully applied 10/21 gradient pixels; the candidate fully applied 21/21. The vivid warm distractor remains outside the candidate corridor in the constructed test.
- Python numerical mirror on the available Clothes1 / Clothes2 test textures using the screenshot's white / warm-gray anchors:

  | Texture | Candidate pixels in source-lightness corridor | preview.10 full / partial / none | Candidate full / partial / none |
  |---|---:|---:|---:|
  | Clothes1 | 1,091,797 | 107,330 / 588,968 / 395,499 | 891,712 / 184,908 / 15,177 |
  | Clothes2 | 971,153 | 9,624 / 535,438 / 426,091 | 912,283 / 52,726 / 6,144 |

  These counts include all opaque pixels within the source-lightness corridor, not a ground-truth material mask. They demonstrate that the candidate makes the neutral corridor much less patchy, but do not prove there is no color spill. Run `Documentation/prototype_check_gradient.py` for a repeatable comparison.

## Added tests

- `SingleColor_NeutralWhiteToGrayGradientRemainsSelected`
- `TwoPointFlow_NeutralGradientWithSubtleTintVariationAvoidsPatchyPartialSelection`

## Verification

- C# source structure, JSON parsing, and ZIP integrity checks are performed during packaging.
- Python numerical mirrors were run against synthetic gradients and the available texture files.

## Not performed

- Unity C# compilation and NUnit execution (Unity Editor / C# compiler unavailable in this environment).
- Visual confirmation in the user's Unity project and exact source texture; preview.10 remains the stable rollback target.


# Build / Change Report — 0.1.0-preview.13 Multi-Region Gradient

## Base
- Base archive: `UnityAssist_TextureColorEngine_preview12_ColorFieldFix.zip` (itself derived from the supplied `UnityAssistTools_Release_1.4.3.zip`).
- Existing Region Gradient color, selection, texture IO, and mesh utilities retained except for the multi-region selection/state orchestration and sequential composition described below.
- Existing Color Conversion Runtime core files are checked against the supplied 1.4.3 baseline.

## Changes
- Added up to 16 named Gradient Regions.
- Each Region owns independent `RegionGradientSettings`; every Texture Target stores a separate selection mask / overlay / seed for each Region ID.
- Multiple selections on one texture can now use different directions, positions, scales, and colors.
- Multiple Targets can share a Region's settings while keeping their masks and source analysis independent.
- Region enable/disable, remove, reorder, and selected-target counts are available in the UI.
- Sequential processing always analyzes immutable original texture pixels, while each pass composites over the accumulated working image.
- Added empty-mask protection and two Editor regression tests for independent masks/settings and order-dependent overlap composition.

## Intended behavior
- Non-overlapping regions are independent: one region's pass does not modify pixels outside its mask.
- Overlapping regions are ordered: later enabled regions composite after earlier regions.
- Each pass extracts original-gradient / shading / brightness / saturation information from the original source texture, not from prior pass output.

## Not performed
- Unity Editor C# compilation.
- Unity Test Runner execution.
- Visual validation in the user's VRC avatar project.
- Main / Side model-space continuity validation on actual avatar meshes.
