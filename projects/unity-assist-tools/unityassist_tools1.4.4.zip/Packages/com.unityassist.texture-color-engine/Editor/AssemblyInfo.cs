using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("UnityAssist.TextureColorEngine.Tests")]
