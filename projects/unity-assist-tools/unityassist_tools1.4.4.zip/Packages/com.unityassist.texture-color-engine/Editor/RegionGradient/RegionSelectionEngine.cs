using System;
using System.Collections.Generic;
using UnityEngine;

namespace UnityAssist.TextureColorEngine.Editor.RegionGradient
{
    internal static class RegionSelectionEngine
    {
        public static byte[] Select(Color32[] pixels, int width, int height, int seedX, int seedY,
            float colorTolerance, float edgeSensitivity, int maximumPixels)
        {
            if (pixels == null) throw new ArgumentNullException(nameof(pixels));
            if (width <= 0 || height <= 0 || pixels.Length != width * height) throw new ArgumentException("Invalid image buffer.");
            if (seedX < 0 || seedY < 0 || seedX >= width || seedY >= height) throw new ArgumentOutOfRangeException("Seed is outside the image.");

            int count = pixels.Length;
            var mask = new byte[count];
            if (pixels[seedY * width + seedX].a < 16) return mask;

            int seed = seedY * width + seedX;
            OklabColor seedColor = RegionGradientColorMath.ToOklab(pixels[seed]);
            var queue = new int[Math.Min(count, Math.Max(1024, maximumPixels))];
            int head = 0, tail = 0, selected = 0;
            queue[tail++] = seed;
            mask[seed] = 255;
            selected++;

            // The local threshold permits smooth shading/gradient transitions; the seed corridor
            // prevents unlimited color drift across a weak boundary.
            float localLimit = Mathf.Lerp(0.018f, 0.105f, Mathf.Clamp01(colorTolerance));
            float seedLimit = localLimit * Mathf.Lerp(2.2f, 5.0f, Mathf.Clamp01(colorTolerance));
            float neighborLimit = localLimit * Mathf.Lerp(1.65f, 0.48f, Mathf.Clamp01(edgeSensitivity));
            maximumPixels = Mathf.Clamp(maximumPixels, 1, count);

            while (head < tail && selected < maximumPixels)
            {
                int index = queue[head++];
                int x = index % width;
                int y = index / width;
                TryAdd(x - 1, y, index);
                TryAdd(x + 1, y, index);
                TryAdd(x, y - 1, index);
                TryAdd(x, y + 1, index);
            }
            return mask;

            void TryAdd(int x, int y, int from)
            {
                if (x < 0 || y < 0 || x >= width || y >= height) return;
                int index = y * width + x;
                if (mask[index] != 0 || pixels[index].a < 16) return;
                OklabColor fromColor = RegionGradientColorMath.ToOklab(pixels[from]);
                OklabColor candidateColor = RegionGradientColorMath.ToOklab(pixels[index]);
                float neighborDistance = RegionGradientColorMath.Distance(fromColor, candidateColor);
                float seedDistance = RegionGradientColorMath.Distance(seedColor, candidateColor);
                if (neighborDistance > neighborLimit || seedDistance > seedLimit) return;
                if (tail >= queue.Length || selected >= maximumPixels) return;
                mask[index] = 255;
                queue[tail++] = index;
                selected++;
            }
        }

        public static byte[] Feather(byte[] source, int width, int height, int radius)
        {
            if (source == null) return null;
            if (radius <= 0) return (byte[])source.Clone();
            radius = Mathf.Clamp(radius, 1, 32);
            float[] horizontal = new float[source.Length];
            byte[] result = new byte[source.Length];
            int window = radius * 2 + 1;

            for (int y = 0; y < height; y++)
            {
                int row = y * width;
                float sum = 0f;
                for (int x = -radius; x <= radius; x++)
                {
                    int sx = Mathf.Clamp(x, 0, width - 1);
                    sum += source[row + sx] / 255f;
                }
                for (int x = 0; x < width; x++)
                {
                    horizontal[row + x] = sum / window;
                    int removeX = Mathf.Clamp(x - radius, 0, width - 1);
                    int addX = Mathf.Clamp(x + radius + 1, 0, width - 1);
                    sum += source[row + addX] / 255f - source[row + removeX] / 255f;
                }
            }

            for (int x = 0; x < width; x++)
            {
                float sum = 0f;
                for (int y = -radius; y <= radius; y++)
                {
                    int sy = Mathf.Clamp(y, 0, height - 1);
                    sum += horizontal[sy * width + x];
                }
                for (int y = 0; y < height; y++)
                {
                    result[y * width + x] = (byte)Mathf.Clamp(Mathf.RoundToInt(sum / window * 255f), 0, 255);
                    int removeY = Mathf.Clamp(y - radius, 0, height - 1);
                    int addY = Mathf.Clamp(y + radius + 1, 0, height - 1);
                    sum += horizontal[addY * width + x] - horizontal[removeY * width + x];
                }
            }
            return result;
        }
    }
}
