using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace UnityAssist.TextureColorEngine.Editor.RegionGradient
{
    internal static class RegionGradientTextureIO
    {
        private const long MaximumPixelCount = 4194304L;

        public static RegionTextureData Load(Texture2D source)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            string assetPath = AssetDatabase.GetAssetPath(source);
            TextureImporter importer = string.IsNullOrEmpty(assetPath) ? null : AssetImporter.GetAtPath(assetPath) as TextureImporter;
            bool isSrgb = importer == null || importer.sRGBTexture;
            if (!isSrgb)
                throw new InvalidOperationException("対象テクスチャのsRGBが無効です。BaseColor向けのsRGBテクスチャを指定してください。Importer設定は変更していません。");

            string absolutePath = ToAbsolutePath(assetPath);
            if (!string.IsNullOrEmpty(absolutePath) && File.Exists(absolutePath))
            {
                string extension = Path.GetExtension(absolutePath).ToLowerInvariant();
                if (extension == ".png" || extension == ".jpg" || extension == ".jpeg")
                {
                    byte[] bytes = File.ReadAllBytes(absolutePath);
                    Texture2D decoded = new Texture2D(2, 2, TextureFormat.RGBA32, false, false);
                    try
                    {
                        if (!ImageConversion.LoadImage(decoded, bytes, false))
                            throw new InvalidDataException("元画像をデコードできませんでした。");
                        CheckSize(decoded.width, decoded.height);
                        return new RegionTextureData(decoded.width, decoded.height, decoded.GetPixels32(), assetPath, null, true);
                    }
                    finally { UnityEngine.Object.DestroyImmediate(decoded); }
                }
            }

            CheckSize(source.width, source.height);
            Color32[] readback = ReadImportedTexture(source);
            string warning = "元ファイルを直接デコードできなかったため、UnityのImport済みTexture2Dから読み込みました。Max Sizeや圧縮の影響が含まれる場合があります。";
            return new RegionTextureData(source.width, source.height, readback, assetPath, warning, isSrgb);
        }

        public static string ExportPng(RegionGradientTarget target, Color32[] pixels, string outputName)
        {
            if (target == null || target.Source == null || target.Settings == null)
                throw new ArgumentNullException(nameof(target));
            if (pixels == null || pixels.Length != target.Source.Width * target.Source.Height)
                throw new ArgumentException("出力ピクセル数が元画像と一致しません。", nameof(pixels));

            string folder = "Assets/RegionGradientOutput";
            string sourcePath = target.Source.AssetPath;
            if (!string.IsNullOrEmpty(sourcePath) && (sourcePath == "Assets" || sourcePath.StartsWith("Assets/", StringComparison.Ordinal)))
            {
                string sourceFolder = Path.GetDirectoryName(sourcePath)?.Replace('\\', '/');
                if (!string.IsNullOrEmpty(sourceFolder) && AssetDatabase.IsValidFolder(sourceFolder)) folder = sourceFolder;
            }
            EnsureFolder(folder);
            string stem = string.IsNullOrEmpty(outputName) ? "Texture_Gradient" : outputName;
            foreach (char invalid in Path.GetInvalidFileNameChars()) stem = stem.Replace(invalid, '_');
            string assetPath = AssetDatabase.GenerateUniqueAssetPath(folder.TrimEnd('/') + "/" + stem + ".png");
            string absolutePath = ToAbsolutePath(assetPath);

            Texture2D encoded = new Texture2D(target.Source.Width, target.Source.Height, TextureFormat.RGBA32, false, false);
            try
            {
                encoded.SetPixels32(pixels);
                encoded.Apply(false, false);
                File.WriteAllBytes(absolutePath, encoded.EncodeToPNG());
            }
            finally { UnityEngine.Object.DestroyImmediate(encoded); }

            AssetDatabase.ImportAsset(assetPath, ImportAssetOptions.ForceSynchronousImport | ImportAssetOptions.ForceUpdate);
            CopyImporterSettings(target.Settings.Texture, assetPath);
            return assetPath;
        }

        public static Texture2D CreatePreview(RegionTextureData data, Color32[] pixels)
        {
            if (data == null || pixels == null || pixels.Length != data.Width * data.Height)
                throw new ArgumentException("プレビュー画像データが不正です。");
            Texture2D preview = new Texture2D(data.Width, data.Height, TextureFormat.RGBA32, false, false);
            preview.SetPixels32(pixels);
            preview.Apply(false, false);
            preview.hideFlags = HideFlags.HideAndDontSave;
            return preview;
        }

        private static void CopyImporterSettings(Texture2D source, string destinationPath)
        {
            TextureImporter destination = AssetImporter.GetAtPath(destinationPath) as TextureImporter;
            if (destination == null) return;
            string sourcePath = source == null ? null : AssetDatabase.GetAssetPath(source);
            TextureImporter original = string.IsNullOrEmpty(sourcePath) ? null : AssetImporter.GetAtPath(sourcePath) as TextureImporter;
            if (original == null)
            {
                destination.sRGBTexture = true;
                destination.textureType = TextureImporterType.Default;
                destination.SaveAndReimport();
                return;
            }

            TextureImporterSettings settings = new TextureImporterSettings();
            original.ReadTextureSettings(settings);
            destination.SetTextureSettings(settings);
            destination.sRGBTexture = original.sRGBTexture;
            destination.mipmapEnabled = original.mipmapEnabled;
            destination.alphaIsTransparency = original.alphaIsTransparency;
            destination.alphaSource = original.alphaSource;
            destination.maxTextureSize = original.maxTextureSize;
            destination.textureCompression = original.textureCompression;
            destination.compressionQuality = original.compressionQuality;
            destination.crunchedCompression = original.crunchedCompression;
            destination.filterMode = original.filterMode;
            destination.wrapMode = original.wrapMode;
            destination.anisoLevel = original.anisoLevel;
            destination.mipMapBias = original.mipMapBias;
            destination.SaveAndReimport();
        }

        private static Color32[] ReadImportedTexture(Texture2D source)
        {
            RenderTexture previous = RenderTexture.active;
            bool previousSrgbWrite = GL.sRGBWrite;
            RenderTexture temporary = null;
            Texture2D readable = null;
            try
            {
                temporary = RenderTexture.GetTemporary(source.width, source.height, 0,
                    RenderTextureFormat.ARGB32, RenderTextureReadWrite.sRGB);
                GL.sRGBWrite = QualitySettings.activeColorSpace == ColorSpace.Linear;
                Graphics.Blit(source, temporary);
                RenderTexture.active = temporary;
                readable = new Texture2D(source.width, source.height, TextureFormat.RGBA32, false, false);
                readable.ReadPixels(new Rect(0, 0, source.width, source.height), 0, 0, false);
                readable.Apply(false, false);
                return readable.GetPixels32();
            }
            finally
            {
                RenderTexture.active = previous;
                GL.sRGBWrite = previousSrgbWrite;
                if (temporary != null) RenderTexture.ReleaseTemporary(temporary);
                if (readable != null) UnityEngine.Object.DestroyImmediate(readable);
            }
        }

        private static void CheckSize(int width, int height)
        {
            if (width <= 0 || height <= 0 || (long)width * height > MaximumPixelCount)
                throw new InvalidOperationException("Region Gradientの初期版は4,194,304ピクセルまでです。");
        }

        private static string ToAbsolutePath(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath)) return null;
            DirectoryInfo root = Directory.GetParent(Application.dataPath);
            if (root == null) throw new InvalidOperationException("Unityプロジェクトのルートを取得できません。");
            return Path.Combine(root.FullName, assetPath.Replace('/', Path.DirectorySeparatorChar));
        }

        private static void EnsureFolder(string assetFolder)
        {
            string[] parts = assetFolder.Split('/');
            string current = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                string next = current + "/" + parts[i];
                if (!AssetDatabase.IsValidFolder(next)) AssetDatabase.CreateFolder(current, parts[i]);
                current = next;
            }
        }
    }
}
