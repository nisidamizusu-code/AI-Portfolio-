using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace UnityAssist.TextureColorEngine.Editor.RegionGradient
{
    internal static class RegionGradientMeshUtility
    {
        public static bool TryGetTextureProperty(Material material, out string propertyName)
        {
            propertyName = null;
            if (material == null || material.shader == null) return false;
            Shader shader = material.shader;
            int count = ShaderUtil.GetPropertyCount(shader);
            for (int i = 0; i < count; i++)
            {
                if (ShaderUtil.GetPropertyType(shader, i) != ShaderUtil.ShaderPropertyType.TexEnv) continue;
                string candidate = ShaderUtil.GetPropertyName(shader, i);
                if (material.GetTexture(candidate) == null) continue;
                propertyName = candidate;
                return true;
            }
            return false;
        }

        public static bool TryFindTextureProperty(Material material, Texture texture, out string propertyName)
        {
            propertyName = null;
            if (material == null || material.shader == null || texture == null) return false;
            Shader shader = material.shader;
            int count = ShaderUtil.GetPropertyCount(shader);
            for (int i = 0; i < count; i++)
            {
                if (ShaderUtil.GetPropertyType(shader, i) != ShaderUtil.ShaderPropertyType.TexEnv) continue;
                string candidate = ShaderUtil.GetPropertyName(shader, i);
                if (material.GetTexture(candidate) != texture) continue;
                propertyName = candidate;
                return true;
            }
            return false;
        }

        public static bool TryPick(Renderer renderer, int materialIndex, Ray ray, out Vector2 uv, out float distance)
        {
            uv = Vector2.zero;
            distance = float.MaxValue;
            Mesh mesh = null;
            bool ownsMesh;
            if (!TryGetMesh(renderer, out mesh, out ownsMesh)) return false;
            try
            {
                if (materialIndex < 0 || materialIndex >= mesh.subMeshCount) return false;
                Vector2[] uvs = mesh.uv;
                Vector3[] vertices = mesh.vertices;
                if (uvs == null || uvs.Length != vertices.Length) return false;
                int[] triangles = mesh.GetTriangles(materialIndex);
                bool found = false;
                for (int i = 0; i + 2 < triangles.Length; i += 3)
                {
                    int ia = triangles[i], ib = triangles[i + 1], ic = triangles[i + 2];
                    Vector3 a = renderer.transform.TransformPoint(vertices[ia]);
                    Vector3 b = renderer.transform.TransformPoint(vertices[ib]);
                    Vector3 c = renderer.transform.TransformPoint(vertices[ic]);
                    float hitDistance, u, v;
                    if (!RayTriangle(ray, a, b, c, out hitDistance, out u, out v) || hitDistance >= distance) continue;
                    float w = 1f - u - v;
                    uv = uvs[ia] * w + uvs[ib] * u + uvs[ic] * v;
                    distance = hitDistance;
                    found = true;
                }
                return found;
            }
            finally { if (ownsMesh && mesh != null) UnityEngine.Object.DestroyImmediate(mesh); }
        }

        public static RegionUvWorldMap BuildWorldMap(Renderer renderer, int materialIndex, string textureProperty, Texture expectedTexture, Transform groupRoot,
            int textureWidth, int textureHeight, out string warning)
        {
            warning = null;
            Mesh mesh = null;
            bool ownsMesh;
            if (!TryGetMesh(renderer, out mesh, out ownsMesh))
            {
                warning = "RendererからMeshを取得できません。";
                return null;
            }
            try
            {
                if (materialIndex < 0 || materialIndex >= mesh.subMeshCount)
                {
                    warning = "Material IndexとMeshのSubMesh数が一致しません。";
                    return null;
                }
                Vector3[] vertices = mesh.vertices;
                Vector2[] uvs = mesh.uv;
                if (uvs == null || uvs.Length != vertices.Length)
                {
                    warning = "UV0が取得できません。";
                    return null;
                }

                Material[] materials = renderer.sharedMaterials;
                if (materialIndex >= materials.Length || materials[materialIndex] == null)
                {
                    warning = "対象Materialがありません。";
                    return null;
                }
                Material material = materials[materialIndex];
                string property = textureProperty;
                if (string.IsNullOrEmpty(property) || material.GetTexture(property) == null)
                {
                    if (!TryGetTextureProperty(material, out property))
                    {
                        warning = "Material内にTexture Propertyが見つかりません。";
                        return null;
                    }
                }
                if (expectedTexture != null && material.GetTexture(property) != expectedTexture)
                {
                    warning = "Texture Propertyと登録Textureが一致しません。Renderer / Material Index / Propertyを確認してください。";
                    return null;
                }
                Vector2 textureScale = material.GetTextureScale(property);
                Vector2 textureOffset = material.GetTextureOffset(property);
                if ((textureScale - Vector2.one).sqrMagnitude > 0.000001f || textureOffset.sqrMagnitude > 0.000001f)
                {
                    warning = "Texture Tiling / Offsetが標準値ではありません。初期版では3D座標マッピングを省略し、UV座標基準で処理します。";
                    return null;
                }

                Vector3[] localVertices = new Vector3[vertices.Length];
                for (int i = 0; i < vertices.Length; i++)
                {
                    Vector3 world = renderer.transform.TransformPoint(vertices[i]);
                    localVertices[i] = groupRoot != null ? groupRoot.InverseTransformPoint(world) : world;
                }

                int count = checked(textureWidth * textureHeight);
                Vector3[] positions = new Vector3[count];
                bool[] valid = new bool[count];
                int overlaps = 0;
                Bounds bounds = new Bounds();
                bool hasBounds = false;
                int[] triangles = mesh.GetTriangles(materialIndex);
                for (int i = 0; i + 2 < triangles.Length; i += 3)
                {
                    int ia = triangles[i], ib = triangles[i + 1], ic = triangles[i + 2];
                    Vector2 ua = uvs[ia], ub = uvs[ib], uc = uvs[ic];
                    if (!InUnitRange(ua) || !InUnitRange(ub) || !InUnitRange(uc)) continue;
                    Vector2 pa = new Vector2(ua.x * (textureWidth - 1), ua.y * (textureHeight - 1));
                    Vector2 pb = new Vector2(ub.x * (textureWidth - 1), ub.y * (textureHeight - 1));
                    Vector2 pc = new Vector2(uc.x * (textureWidth - 1), uc.y * (textureHeight - 1));
                    float area = Cross(pb - pa, pc - pa);
                    if (Mathf.Abs(area) < 0.00001f) continue;
                    int minX = Mathf.Clamp(Mathf.FloorToInt(Mathf.Min(pa.x, Mathf.Min(pb.x, pc.x))), 0, textureWidth - 1);
                    int maxX = Mathf.Clamp(Mathf.CeilToInt(Mathf.Max(pa.x, Mathf.Max(pb.x, pc.x))), 0, textureWidth - 1);
                    int minY = Mathf.Clamp(Mathf.FloorToInt(Mathf.Min(pa.y, Mathf.Min(pb.y, pc.y))), 0, textureHeight - 1);
                    int maxY = Mathf.Clamp(Mathf.CeilToInt(Mathf.Max(pa.y, Mathf.Max(pb.y, pc.y))), 0, textureHeight - 1);
                    for (int y = minY; y <= maxY; y++)
                    {
                        for (int x = minX; x <= maxX; x++)
                        {
                            Vector2 p = new Vector2(x + 0.5f, y + 0.5f);
                            float wa, wb, wc;
                            if (!Barycentric(p, pa, pb, pc, out wa, out wb, out wc)) continue;
                            Vector3 localPosition = localVertices[ia] * wa + localVertices[ib] * wb + localVertices[ic] * wc;
                            int index = y * textureWidth + x;
                            if (valid[index])
                            {
                                if ((positions[index] - localPosition).sqrMagnitude > 0.0001f) overlaps++;
                                continue;
                            }
                            valid[index] = true;
                            positions[index] = localPosition;
                            if (!hasBounds) { bounds = new Bounds(localPosition, Vector3.zero); hasBounds = true; }
                            else bounds.Encapsulate(localPosition);
                        }
                    }
                }
                if (!hasBounds)
                {
                    warning = "UV0の有効な領域をテクスチャ上に投影できませんでした。";
                    return null;
                }
                if (overlaps > 0)
                    warning = "UV重複を検出しました（" + overlaps.ToString("N0") + "画素）。重複位置では1つの3D座標に確定できません。";
                return new RegionUvWorldMap(positions, valid, overlaps, bounds);
            }
            finally { if (ownsMesh && mesh != null) UnityEngine.Object.DestroyImmediate(mesh); }
        }

        public static Vector2[] BuildNormalizedCoordinates(RegionGradientTarget[] targets, int activeIndex)
        {
            if (targets == null || activeIndex < 0 || activeIndex >= targets.Length) return null;
            RegionGradientTarget active = targets[activeIndex];
            if (active == null || active.Source == null) return null;

            Bounds combined = new Bounds();
            bool hasBounds = false;
            for (int i = 0; i < targets.Length; i++)
            {
                RegionUvWorldMap map = targets[i] == null ? null : targets[i].UvWorldMap;
                if (map == null) continue;
                if (!hasBounds) { combined = map.LocalBounds; hasBounds = true; }
                else { combined.Encapsulate(map.LocalBounds.min); combined.Encapsulate(map.LocalBounds.max); }
            }
            Vector2[] coords = new Vector2[active.Source.Width * active.Source.Height];
            Vector3 size = hasBounds ? combined.size : Vector3.one;
            if (Mathf.Abs(size.x) < 0.0001f) size.x = 1f;
            if (Mathf.Abs(size.y) < 0.0001f) size.y = 1f;
            for (int y = 0; y < active.Source.Height; y++)
            {
                for (int x = 0; x < active.Source.Width; x++)
                {
                    int index = y * active.Source.Width + x;
                    if (hasBounds && active.UvWorldMap != null && active.UvWorldMap.Valid[index])
                    {
                        Vector3 p = active.UvWorldMap.Positions[index];
                        coords[index] = new Vector2((p.x - combined.min.x) / size.x, (p.y - combined.min.y) / size.y);
                    }
                    else coords[index] = new Vector2((x + 0.5f) / active.Source.Width, (y + 0.5f) / active.Source.Height);
                }
            }
            return coords;
        }

        private static bool TryGetMesh(Renderer renderer, out Mesh mesh, out bool ownsMesh)
        {
            mesh = null;
            ownsMesh = false;
            if (renderer == null) return false;
            SkinnedMeshRenderer skinned = renderer as SkinnedMeshRenderer;
            if (skinned != null)
            {
                mesh = new Mesh { name = "RegionGradient_BakedMesh" };
                skinned.BakeMesh(mesh);
                ownsMesh = true;
                if (mesh.vertexCount > 0) return true;
                UnityEngine.Object.DestroyImmediate(mesh);
                mesh = null;
                ownsMesh = false;
                return false;
            }
            MeshFilter filter = renderer.GetComponent<MeshFilter>();
            if (filter == null || filter.sharedMesh == null) return false;
            mesh = filter.sharedMesh;
            return true;
        }

        private static bool RayTriangle(Ray ray, Vector3 a, Vector3 b, Vector3 c, out float distance, out float u, out float v)
        {
            const float epsilon = 0.000001f;
            Vector3 e1 = b - a;
            Vector3 e2 = c - a;
            Vector3 p = Vector3.Cross(ray.direction, e2);
            float det = Vector3.Dot(e1, p);
            if (Mathf.Abs(det) < epsilon) { distance = u = v = 0f; return false; }
            float inv = 1f / det;
            Vector3 t = ray.origin - a;
            u = Vector3.Dot(t, p) * inv;
            if (u < 0f || u > 1f) { distance = v = 0f; return false; }
            Vector3 q = Vector3.Cross(t, e1);
            v = Vector3.Dot(ray.direction, q) * inv;
            if (v < 0f || u + v > 1f) { distance = 0f; return false; }
            distance = Vector3.Dot(e2, q) * inv;
            return distance >= 0f;
        }

        private static bool Barycentric(Vector2 p, Vector2 a, Vector2 b, Vector2 c, out float wa, out float wb, out float wc)
        {
            float denominator = Cross(b - a, c - a);
            if (Mathf.Abs(denominator) < 0.000001f) { wa = wb = wc = 0f; return false; }
            wb = Cross(p - a, c - a) / denominator;
            wc = Cross(b - a, p - a) / denominator;
            wa = 1f - wb - wc;
            const float epsilon = -0.001f;
            return wa >= epsilon && wb >= epsilon && wc >= epsilon;
        }

        private static float Cross(Vector2 a, Vector2 b) { return a.x * b.y - a.y * b.x; }
        private static bool InUnitRange(Vector2 uv)
        {
            return uv.x >= 0f && uv.x <= 1f && uv.y >= 0f && uv.y <= 1f;
        }
    }
}
