## 0.1.0-preview.11 — Neutral Gradient Continuity Experiment

- Single-color neutral selection now supports a wider white-to-gray lightness span and uses OKLab a/b proximity plus chroma to reject vivid distractors.
- Two-point near-neutral flow widens its a/b corridor (0.03 minimum, 0.045 maximum) so subtle textile tint variation does not become a patchy partial-selection pattern.
- Destination-color construction, shading residual formulas, OKLab projection, gamut mapping, Editor UI, and non-neutral selection paths are unchanged.
- Added tests for a white-to-warm-gray single-color gradient, vivid distractor rejection, and subtle-tint two-point flow.
- Experimental only; preserve preview.10 until actual Unity texture comparison confirms improvement.

## 0.1.0-preview.10

- Expanded the source/result preview canvases from 250px to 440px high and widened each panel for more comfortable texture inspection.
- Centered the two-panel preview area within the Editor window, with a larger minimum window size.
- Made zoom and pan independent for the source and result canvases; movement in one panel no longer moves the other.
- Added per-panel zoom percentage, zoom in/out, Fit, and 100% controls.
- Kept Runtime color recognition, conversion, interpolation, and pixel processing unchanged from preview.8.
- Unity Editor compilation and interactive GUI behavior still require verification in the user's Unity environment.

## 0.1.0-preview.9

- Added synchronized zoom and pan for the source and result preview canvases. Mouse wheel zooms toward the pointer; middle-drag or Space+left-drag pans the view.
- Added Fit and 100% preview controls. Navigation changes presentation only and does not resample or alter the source texture pixels.
- Reorganized two-point anchor controls into separate start/end cards and automatically advances from start-point picking to end-point picking.
- Added a clear-selection action for the two-point anchors.
- Kept all Runtime color recognition, conversion, interpolation, and output pixel processing code unchanged from preview.8.
- Unity Editor compilation and interactive GUI behavior still require verification in the user's Unity environment.

## 0.1.0-preview.8

- Fixed two-point selection for near-neutral source anchors. OKLCH hue values are no longer treated as a valid flow axis unless both anchors have sufficient chroma.
- Added an OKLab a/b corridor gate for near-neutral flows so vivid warm/cool pixels with coincidentally matching hue and lightness are not selected.
- Kept the unified OKLab progress projection and target interpolation introduced in preview.7.
- Kept single-color conversion, image loading, UI, and PNG export paths unchanged.
- Added a regression test using the same near-neutral anchor RGB values shown in the user's screenshot and a warm distractor with matching lightness.

## 0.1.0-preview.7

- 2点変換の進行度を、OKLCHの明度・彩度・色相それぞれの進行度の加重平均から、OKLab空間の線分射影へ変更。
- 変換元・変換先の中間色をOKLabで補間し、複数の色成分が同時に変化する素材での色の流れの偏りを軽減。
- 低彩度画素では不安定な色相差分を陰影・色相残差として反映しないよう調整。
- 2点変換の滑らかな色流れに関する回帰テストを追加。
- 単色変換および既存の対象色判定ロジックは変更なし。

## 0.1.0-preview.6

- Removed development-only wording about the 1.4.1 UI from the editor window.
- Renamed the visible Unity menu item and window title to Texture Color Replacer.
- Simplified user-facing instructions and removed the technical read-method row.
- Kept the runtime color engine, image loading, recoloring, and export logic unchanged.

## 0.1.0-preview.5

- Replaced target-color HEX text fields with Unity's native visual Color Picker field.
- Kept single-color and two-point target color values as ordinary LDR colors; alpha and HDR controls are hidden.
- Left runtime color recognition, recoloring algorithms, source loading, and export code unchanged.

# Changelog

## 0.1.0-preview.4
- Fixed missing scalar `Lerp(float, float, float)` helper in `MaterialColorProfile`.
- Updated package version and build report.

## 0.1.0-preview.3
- Added hex sRGB target-color entry to the sandbox.
- Allowed sandbox PNG export into `Assets/` even when the source asset is under `Packages/`.
- Expanded research and license tracking.

