# Unity Assist Texture Color Engine

VRChatアバター向けテクスチャの色を選択して変換するUnity Editor拡張です。

- Package ID: `com.unityassist.texture-color-engine`
- Version: `0.1.0-preview.11`
- Minimum Unity: 2021.3
- Dependencies: Unity標準APIのみ
- AI / Sentis: 不使用
- 手動マスク編集UI: なし

## 技術資料

- [内部構造と処理フロー](./Documentation/02_INTERNAL_PROCESSING_FLOW.md)
- [OKLab・OKLCHを用いた色変換の仕組み](./Documentation/03_OKLAB_OKLCH_COLOR_CONVERSION.md)
- [ビルド・変更レポート](./Documentation/BUILD_REPORT.md)
- [調査・ライセンス記録](./Documentation/RESEARCH_AND_LICENSES.md)

## 構成

### Runtime core

- Unity UIに依存しないピクセル処理コア
- 変換先色はUnity標準Color Pickerの色相リングと中央の色選択フィールドで視覚的に指定
- エンジン内部の入力契約は従来どおりsRGB RGBA8
- sRGB RGBA8入力 / 出力
- sRGB -> Linear RGB -> OKLab / OKLCH
- sRGB変換LUTによるピクセル走査の負荷軽減
- OKLCH色域マッピング（色域外では彩度を下げ、明度と色相を優先して保持）
- 画像内の明度帯別に色相分布・彩度分布を推定する `MaterialColorProfile`
- 単色変換
- 2点色変換（明度・彩度・色相を判定し、低彩度の端点では色相を無効化してOKLab a/bの経路で対象を絞る）
- 元の透明度を保持

### Editor adapter

- PNG / JPG / JPEG: 元ファイルのバイト列を `ImageConversion.LoadImage` で直接デコード
- TGA: 非圧縮 / RLEのTrue Color 24/32bit、Grayscale 8bitを直接デコード
- 生成画像・非対応形式のみ、UnityのImport済みTexture2Dから読み込むフォールバック
- 元のTextureImporter設定（sRGB、Max Size、Compression、Mipmap、Alpha、Filter、Wrap等）を取得
- PNGとして別名保存し、取得したImporter設定を出力画像へ適用
- フォールバック時やsRGB無効時は警告を表示

### Texture Color Replacer

Unityメニュー `Tools > Unity Assist > Texture Color Replacer` から開けます。

- 元テクスチャの読み込み
- 単色変換 / 2点の色の流れ
- 元画像上をクリックしてスポイト選択
- マウスホイールによる拡大・縮小
- 中ドラッグまたはSpace＋左ドラッグによる表示位置の移動
- 全体表示 / 100%表示
- 元画像と変換結果の独立ズーム・パン（各画像の表示位置・倍率を別々に調整）
- 各プレビューに個別のズーム倍率表示、拡大・縮小、全体表示、100%表示
- 中央寄せの広いプレビュー領域（各キャンバス高さ440px）
- 2点変換の始点 / 終点カード、自動的な終点選択への移行
- 元画像と変換結果の比較
- 対象・部分適用ピクセル数の表示
- 新しいPNGとして保存

変換先の色はUnity標準Color Pickerの色相リングと中央の色選択フィールドで指定します。

## グラデーションの連続性（preview.11 実験）

- 単色変換の低彩度・無彩色選択で、白〜灰色の同一素材グラデーションが明度差だけで途中から除外されやすい問題を緩和
- サンプルからの明度差の完全適用範囲を 0.075 から 0.18 に拡大し、0.26 まで滑らかに減衰
- サンプルの OKLab a/b 差も併用し、鮮やかな色の誤選択を抑制
- 2点変換の低彩度フローでは a/b 許容値に 0.03 の下限を設け、布地に含まれる微妙な色味の違いによる部分適用のまだらを軽減
- 変換先の色計算、陰影保持式、OKLab進行度、色域マッピング、UIは変更していない
- この変更は白〜灰色など低彩度グラデーション向けの実験。preview.10を安定版として保持する

## 色判定の考え方

### 単色

- クリックした色を基準に、画像全体の色分布を明度帯ごとに解析
- 各明度帯の色相の最頻域を追跡し、布の影・中間色・ハイライトで生じる色相のずれを許容
- OKLCHの彩度分布を独立した内部ゲートとして使い、低彩度の黒・灰色が色相だけで混入するのを抑制
- 単純なRGB色差半径だけに依存せず、明度帯別の色相・彩度分布を組み合わせて判定

### 2点の色の流れ

- 1点目と2点目の両方を変換元の端点として使う
- 明度・彩度・色相の差から、対象判定に使う軸を選択
- OKLab空間の線分射影で進行度を一元的に求め、変換先の中間色もOKLabで補間する
- 両端点が十分な彩度を持つ場合だけ、色相差を有効な変化軸として扱う
- 片方でも低彩度の場合は色相を判定に使わず、OKLab a/b上の色の流れから外れた画素を除外する
- 有彩色で色相が変化軸でない場合は、画像から推定した明度別の素材色相プロファイルを使う
- 両端点のピクセルは、指定した変換先の端点色へ正確に対応させる

### 変換

- 色味は変換先へ移し、元の明度差を内部設定で残す
- 元の色相・彩度の細かな揺れは弱く保持
- 色域外ではRGB各チャンネルを単純に切り詰めず、OKLCHの彩度を下げてsRGB内に収める

## 既知の制約

- 同じ色・同じ色分布を持つ別パーツが同じ画像に存在する場合、色情報だけでは完全に区別できません。
- 非常に暗く彩度が低い有彩色と黒の境界は、元画像だけでは曖昧です。
- 直接デコードする画像形式はPNG/JPG/JPEG/TGAです。TGAは一般的な非圧縮/RLE True Color・Grayscale形式を対象にし、Color Map / interleaved / 16bitは非対応です。
- BaseColor向けのsRGB画像を前提にしています。Normal / Mask / Metallic等のLinearデータには使用しないでください。
- 大きなテクスチャはメモリ・処理時間を要します。現段階ではチャンク処理・キャンセル・並列化は未実装です。
- Irocaのようなメッシュ/UV領域識別やAIセグメンテーションは実装していません。

## 導入・確認

1. ZIPを展開します。
2. `UnityTextureColorEngine` フォルダーをUnityプロジェクトの `Packages/` に配置します。
3. Unity Editorでコンパイル結果を確認します。
4. `Tools > Unity Assist > Texture Color Replacer` を開き、BaseColorテクスチャで単色変換と2点変換を別々に試します。
5. `Tests/Editor` のUnity Test Frameworkテストを実行します。

## 追加調査で反映した設計参考

- Iroca: 素材の明暗帯プロファイル、境界クリーンアップの考え方（PolyForm Shieldの競合制限に従いコードは不使用）
- Color-Changer: 変更前後の色差分を転送する考え方（MITだが、このプレビューではコード不使用）
- Texture Color Adjuster / TexColorAdjuster: 明度別色合わせ、色分布、プレビューと保存の経路を一致させる考え方
- Color Matcher / Miyabix: 元画像ファイルを読むこと、Read/Write設定に依存しない読み込み
- TexStack / Click Recolor: 将来のUV・メッシュ文脈の参考。今回のサンドボックスには手動マスク・Scene選択を追加していない

詳細とライセンス判断は `Documentation/RESEARCH_AND_LICENSES.md` を参照してください。

## 検証状況

- JSON構文・ファイル構成・ソースの括弧整合性: 静的検査
- Pythonによる数値モデル: 過去に共有されたClothes1 / Clothes2テクスチャで色選択傾向を確認
- C# NUnitテスト: 12件を収録（新規2件）。Unity Test Runnerでは未実行
- preview.11では低彩度グラデーションの選択重みを実験的に変更。Unityコンパイル・Test Runner・実テクスチャの目視比較は未実施。preview.10を安定版として保持
- Unity C#コンパイル: 未実施（この制作環境にUnity Editor / C#コンパイラがないため）
- Unity上のスポイト操作、プレビュー、PNG出力: 未実施
- 帽子・デニム等のユーザー実素材の目視検証: 未完了

**本パッケージはプレビュー版です。Unity上での実動作は利用環境で確認してください。**


### 変換先の色の指定

変換先の色はHEXコード入力ではなく、Unity標準のColor Pickerで選択します。色見本をクリックすると、色相リングと中央の色選択フィールドが開きます。単色方式では1色、2点方式では始点・終点それぞれの変換先色を指定します。HDRとアルファ指定は無効で、元画像の透明度は維持されます。ランタイムエンジンの色入力形式・判定・変換ロジックは変更していません。
