using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace UnityAssist.TextureColorEngine.Editor
{
    public sealed class TextureImportSettingsSnapshot
    {
        public bool IsSrgb = true;
        public bool MipMapEnabled;
        public bool AlphaIsTransparency;
        public bool CrunchCompression;
        public int MaxTextureSize = 2048;
        public TextureImporterCompression Compression = TextureImporterCompression.Compressed;
        public int CompressionQuality = 50;
        public FilterMode FilterMode = FilterMode.Bilinear;
        public TextureWrapMode WrapMode = TextureWrapMode.Repeat;
        public int AnisoLevel = 1;
        public TextureImporterType TextureType = TextureImporterType.Default;
        public TextureImporterNPOTScale NpotScale = TextureImporterNPOTScale.None;
        public bool IsReadable;
        public TextureImporterAlphaSource AlphaSource = TextureImporterAlphaSource.FromInput;
        public float MipMapBias;
        public string ColorSpaceWarning;

        public static TextureImportSettingsSnapshot Capture(string assetPath)
        {
            var snapshot = new TextureImportSettingsSnapshot();
            var importer = AssetImporter.GetAtPath(assetPath) as TextureImporter;
            if (importer == null) return snapshot;
            snapshot.IsSrgb = importer.sRGBTexture;
            snapshot.MipMapEnabled = importer.mipmapEnabled;
            snapshot.AlphaIsTransparency = importer.alphaIsTransparency;
            snapshot.CrunchCompression = importer.crunchedCompression;
            snapshot.MaxTextureSize = importer.maxTextureSize;
            snapshot.Compression = importer.textureCompression;
            snapshot.CompressionQuality = importer.compressionQuality;
            snapshot.FilterMode = importer.filterMode;
            snapshot.WrapMode = importer.wrapMode;
            snapshot.AnisoLevel = importer.anisoLevel;
            snapshot.TextureType = importer.textureType;
            snapshot.NpotScale = importer.npotScale;
            snapshot.IsReadable = importer.isReadable;
            snapshot.AlphaSource = importer.alphaSource;
            snapshot.MipMapBias = importer.mipMapBias;
            return snapshot;
        }

        public void ApplyTo(TextureImporter importer)
        {
            if (importer == null) throw new ArgumentNullException(nameof(importer));
            importer.sRGBTexture = IsSrgb;
            importer.mipmapEnabled = MipMapEnabled;
            importer.alphaIsTransparency = AlphaIsTransparency;
            importer.crunchedCompression = CrunchCompression;
            importer.maxTextureSize = MaxTextureSize;
            importer.textureCompression = Compression;
            importer.compressionQuality = CompressionQuality;
            importer.filterMode = FilterMode;
            importer.wrapMode = WrapMode;
            importer.anisoLevel = AnisoLevel;
            importer.textureType = TextureType;
            importer.npotScale = NpotScale;
            importer.isReadable = IsReadable;
            importer.alphaSource = AlphaSource;
            importer.mipMapBias = MipMapBias;
        }
    }

    public sealed class LoadedTextureSource
    {
        public TexturePixels Pixels { get; private set; }
        public TextureImportSettingsSnapshot ImportSettings { get; private set; }
        public string AssetPath { get; private set; }
        public bool UsedImportedTextureFallback { get; private set; }
        public string ReadMethod { get; private set; }
        public string Warning { get; private set; }

        internal LoadedTextureSource(TexturePixels pixels, TextureImportSettingsSnapshot settings, string path, bool fallback, string method, string warning)
        {
            Pixels = pixels;
            ImportSettings = settings;
            AssetPath = path;
            UsedImportedTextureFallback = fallback;
            ReadMethod = method;
            Warning = warning;
        }
    }

    /// <summary>
    /// Reads the original asset bytes for PNG/JPEG/TGA where possible, instead of using imported, possibly resized/compressed pixels.
    /// Pixel array order is Unity's bottom-left row-major order for consistent Editor preview integration.
    /// </summary>
    public static class TextureSourceReader
    {
        private const long MaximumPixelCount = 16777216L;

        public static LoadedTextureSource Load(Texture2D source)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            string path = AssetDatabase.GetAssetPath(source);
            TextureImportSettingsSnapshot settings = TextureImportSettingsSnapshot.Capture(path);

            string absoluteSourcePath = ToAbsoluteAssetPath(path);
            if (!string.IsNullOrEmpty(path) && File.Exists(absoluteSourcePath))
            {
                string extension = Path.GetExtension(path).ToLowerInvariant();
                byte[] bytes = File.ReadAllBytes(absoluteSourcePath);
                if (extension == ".png" || extension == ".jpg" || extension == ".jpeg")
                {
                    TexturePixels pixels = DecodeWithUnity(bytes);
                    return new LoadedTextureSource(pixels, settings, path, false, "Original file bytes via ImageConversion.LoadImage", BuildColorSpaceWarning(settings));
                }
                if (extension == ".tga")
                {
                    TexturePixels pixels = DecodeTga(bytes);
                    return new LoadedTextureSource(pixels, settings, path, false, "Original TGA file bytes via built-in decoder", BuildColorSpaceWarning(settings));
                }
            }

            // Fallback for generated or unsupported imported textures. This may reflect importer resizing/compression.
            if ((long)source.width * source.height > MaximumPixelCount)
                throw new InvalidOperationException("テクスチャサイズが上限を超えています（16,777,216ピクセル）。");
            TexturePixels fallbackPixels = ReadImportedTexture(source);
            string warning = BuildColorSpaceWarning(settings);
            warning = string.IsNullOrEmpty(warning) ? "元ファイルを直接デコードできず、UnityのImport済みTexture2Dから読み込みました。圧縮・Max Sizeの影響が残る場合があります。" : warning + " 元ファイルを直接デコードできず、Import後の画素を使用しています。";
            return new LoadedTextureSource(fallbackPixels, settings, path, true, "Imported Texture2D readback fallback", warning);
        }

        private static string BuildColorSpaceWarning(TextureImportSettingsSnapshot settings)
        {
            return settings != null && !settings.IsSrgb
                ? "このTextureImporterはsRGBが無効です。色変換エンジンはBaseColor向けのsRGB画素として処理するため、Normal/Mask/Linearデータには使用しないでください。"
                : null;
        }

        public static string ExportPng(LoadedTextureSource source, TexturePixels pixels, string assetFolder, string fileStem)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (pixels == null) throw new ArgumentNullException(nameof(pixels));
            if (string.IsNullOrEmpty(assetFolder) ||
                !(assetFolder == "Assets" || assetFolder.StartsWith("Assets/", StringComparison.Ordinal)))
                throw new ArgumentException("出力先はAssetsフォルダー配下を指定してください。", nameof(assetFolder));
            if (!AssetDatabase.IsValidFolder(assetFolder))
                throw new DirectoryNotFoundException("出力先フォルダーが存在しません: " + assetFolder);

            string safeStem = string.IsNullOrEmpty(fileStem) ? "RecoloredTexture" : fileStem;
            foreach (char invalid in Path.GetInvalidFileNameChars()) safeStem = safeStem.Replace(invalid, '_');
            string assetPath = AssetDatabase.GenerateUniqueAssetPath(assetFolder.TrimEnd('/') + "/" + safeStem + ".png");
            string absolutePath = ToAbsoluteAssetPath(assetPath);
            Texture2D exportTexture = new Texture2D(pixels.Width, pixels.Height, TextureFormat.RGBA32, false, false);
            try
            {
                Color32[] colors = new Color32[pixels.Pixels.Length];
                for (int i = 0; i < colors.Length; i++)
                {
                    Rgba32 p = pixels.Pixels[i];
                    colors[i] = new Color32(p.R, p.G, p.B, p.A);
                }
                exportTexture.SetPixels32(colors);
                exportTexture.Apply(false, false);
                File.WriteAllBytes(absolutePath, exportTexture.EncodeToPNG());
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(exportTexture);
            }

            AssetDatabase.ImportAsset(assetPath, ImportAssetOptions.ForceSynchronousImport | ImportAssetOptions.ForceUpdate);
            TextureImporter importer = AssetImporter.GetAtPath(assetPath) as TextureImporter;
            if (importer != null && source.ImportSettings != null)
            {
                source.ImportSettings.ApplyTo(importer);
                importer.SaveAndReimport();
            }
            return assetPath;
        }

        private static string ToAbsoluteAssetPath(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath)) return null;
            DirectoryInfo projectDirectory = Directory.GetParent(Application.dataPath);
            if (projectDirectory == null) throw new InvalidOperationException("Unityプロジェクトのルートフォルダーを取得できません。");
            return Path.Combine(projectDirectory.FullName, assetPath.Replace('/', Path.DirectorySeparatorChar));
        }

        private static TexturePixels DecodeWithUnity(byte[] bytes)
        {
            Texture2D decoded = new Texture2D(2, 2, TextureFormat.RGBA32, false, false);
            try
            {
                if (!ImageConversion.LoadImage(decoded, bytes, false))
                    throw new InvalidDataException("PNG/JPEGをデコードできませんでした。");
                if ((long)decoded.width * decoded.height > MaximumPixelCount)
                    throw new InvalidDataException("画像サイズが上限を超えています（16,777,216ピクセル）。");
                Color32[] colors = decoded.GetPixels32();
                Rgba32[] pixels = new Rgba32[colors.Length];
                for (int i = 0; i < colors.Length; i++)
                    pixels[i] = new Rgba32(colors[i].r, colors[i].g, colors[i].b, colors[i].a);
                return new TexturePixels(decoded.width, decoded.height, pixels, true);
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(decoded);
            }
        }

        private static TexturePixels DecodeTga(byte[] bytes)
        {
            if (bytes == null || bytes.Length < 18) throw new InvalidDataException("TGAヘッダーが不正です。");
            int idLength = bytes[0];
            int colorMapType = bytes[1];
            int imageType = bytes[2];
            int width = bytes[12] | (bytes[13] << 8);
            int height = bytes[14] | (bytes[15] << 8);
            int bitsPerPixel = bytes[16];
            byte descriptor = bytes[17];
            bool useAlpha = bitsPerPixel == 32 && (descriptor & 0x0F) > 0;
            if ((descriptor & 0xC0) != 0) throw new NotSupportedException("インターリーブ形式のTGAには対応していません。");
            if (colorMapType != 0) throw new NotSupportedException("カラーマップ形式のTGAには対応していません。");
            bool grayscale = imageType == 3 || imageType == 11;
            bool rle = imageType == 10 || imageType == 11;
            if (!(imageType == 2 || imageType == 3 || imageType == 10 || imageType == 11))
                throw new NotSupportedException("TGAは非圧縮/ RLEのTrue ColorまたはGrayscale形式に対応しています。");
            if (width <= 0 || height <= 0 || (long)width * height > 16777216L)
                throw new InvalidDataException("TGAの画像サイズが対応範囲外です。");
            if (grayscale && bitsPerPixel != 8) throw new NotSupportedException("Grayscale TGAは8bitのみ対応しています。");
            if (!grayscale && bitsPerPixel != 24 && bitsPerPixel != 32)
                throw new NotSupportedException("True Color TGAは24bit/32bitのみ対応しています。");

            int bytesPerPixel = bitsPerPixel / 8;
            int cursor = 18 + idLength;
            if (cursor > bytes.Length) throw new InvalidDataException("TGAの画像データがありません。");
            int pixelCount = width * height;
            Rgba32[] result = new Rgba32[pixelCount];
            int written = 0;
            while (written < pixelCount)
            {
                int runLength = 1;
                bool repeated = false;
                if (rle)
                {
                    if (cursor >= bytes.Length) throw new InvalidDataException("TGAのRLEデータが途中で終わっています。");
                    byte packet = bytes[cursor++];
                    repeated = (packet & 0x80) != 0;
                    runLength = (packet & 0x7F) + 1;
                    if (runLength > pixelCount - written)
                        throw new InvalidDataException("TGAのRLEパケットが画像の画素数を超えています。");
                }

                Rgba32 repeatedPixel = default(Rgba32);
                if (repeated) repeatedPixel = ReadTgaPixel(bytes, ref cursor, bytesPerPixel, grayscale, useAlpha);
                for (int j = 0; j < runLength && written < pixelCount; j++)
                {
                    Rgba32 pixel = repeated ? repeatedPixel : ReadTgaPixel(bytes, ref cursor, bytesPerPixel, grayscale, useAlpha);
                    int fileRow = written / width;
                    int fileColumn = written % width;
                    bool topOrigin = (descriptor & 0x20) != 0;
                    bool rightOrigin = (descriptor & 0x10) != 0;
                    int x = rightOrigin ? width - 1 - fileColumn : fileColumn;
                    int y = topOrigin ? height - 1 - fileRow : fileRow;
                    result[y * width + x] = pixel;
                    written++;
                }
            }
            return new TexturePixels(width, height, result, true);
        }

        private static Rgba32 ReadTgaPixel(byte[] bytes, ref int cursor, int bytesPerPixel, bool grayscale, bool useAlpha)
        {
            if (cursor + bytesPerPixel > bytes.Length) throw new InvalidDataException("TGAのピクセルデータが途中で終わっています。");
            if (grayscale)
            {
                byte value = bytes[cursor++];
                return new Rgba32(value, value, value, 255);
            }
            byte b = bytes[cursor++];
            byte g = bytes[cursor++];
            byte r = bytes[cursor++];
            byte a = bytesPerPixel == 4 ? bytes[cursor++] : (byte)255;
            if (!useAlpha) a = 255;
            return new Rgba32(r, g, b, a);
        }

        private static TexturePixels ReadImportedTexture(Texture2D source)
        {
            RenderTexture previous = RenderTexture.active;
            bool previousSrgbWrite = GL.sRGBWrite;
            RenderTexture temporary = null;
            Texture2D readable = null;
            try
            {
                temporary = RenderTexture.GetTemporary(source.width, source.height, 0, RenderTextureFormat.ARGB32, RenderTextureReadWrite.sRGB);
                // Graphics.Blit depends on the previous render state in Linear projects. Explicitly
                // write sRGB to this sRGB RenderTexture, then restore the caller's GL state.
                GL.sRGBWrite = QualitySettings.activeColorSpace == ColorSpace.Linear;
                Graphics.Blit(source, temporary);
                RenderTexture.active = temporary;
                readable = new Texture2D(source.width, source.height, TextureFormat.RGBA32, false, false);
                readable.ReadPixels(new Rect(0, 0, source.width, source.height), 0, 0, false);
                readable.Apply(false, false);
                Color32[] colors = readable.GetPixels32();
                Rgba32[] pixels = new Rgba32[colors.Length];
                for (int i = 0; i < colors.Length; i++)
                    pixels[i] = new Rgba32(colors[i].r, colors[i].g, colors[i].b, colors[i].a);
                return new TexturePixels(source.width, source.height, pixels, true);
            }
            finally
            {
                RenderTexture.active = previous;
                GL.sRGBWrite = previousSrgbWrite;
                if (temporary != null) RenderTexture.ReleaseTemporary(temporary);
                if (readable != null) UnityEngine.Object.DestroyImmediate(readable);
            }
        }
    }
}
