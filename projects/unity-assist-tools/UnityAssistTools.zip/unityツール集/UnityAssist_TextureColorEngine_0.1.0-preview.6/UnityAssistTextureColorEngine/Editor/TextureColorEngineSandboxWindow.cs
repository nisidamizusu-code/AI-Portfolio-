using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace UnityAssist.TextureColorEngine.Editor
{
    /// <summary>
    /// Small verification UI for the independent engine. This is not the final 1.4.1 UI.
    /// It intentionally exposes only source selection, 1/2-point picking, target colors, preview and export.
    /// </summary>
    internal sealed class TextureColorEngineSandboxWindow : EditorWindow
    {
        private Texture2D sourceAsset;
        private LoadedTextureSource loadedSource;
        private Texture2D sourcePreview;
        private Texture2D resultPreview;
        private RecolorResult lastResult;
        private RecolorMode mode = RecolorMode.SingleColor;
        // Target colors are selected visually with Unity's native Color Picker.
        // The engine input remains unchanged: selected LDR colors are converted to sRGB RGBA8.
        private Color targetColor = new Color32(64, 115, 184, 255);
        private Color targetStartColor = new Color32(64, 115, 184, 255);
        private Color targetEndColor = new Color32(115, 174, 221, 255);
        private int firstX = -1;
        private int firstY = -1;
        private int secondX = -1;
        private int secondY = -1;
        private int activePoint;
        private string outputName = "";
        private string statusMessage;
        private Vector2 scrollPosition;

        [MenuItem("Tools/Unity Assist/Texture Color Replacer")]
        private static void Open()
        {
            GetWindow<TextureColorEngineSandboxWindow>("Texture Color Replacer");
        }

        private void OnDisable()
        {
            DestroyPreviewTextures();
            loadedSource = null;
            lastResult = null;
        }

        private void OnGUI()
        {
            scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);
            EditorGUILayout.HelpBox("元画像をクリックして変換元の色を選択します。元画像は変更せず、変換結果をPNGで別名保存します。", MessageType.Info);

            EditorGUI.BeginChangeCheck();
            Texture2D newAsset = (Texture2D)EditorGUILayout.ObjectField(
                new GUIContent("元テクスチャ", "Project内のBaseColorテクスチャを指定します。"),
                sourceAsset, typeof(Texture2D), false);
            if (EditorGUI.EndChangeCheck() && newAsset != sourceAsset)
            {
                sourceAsset = newAsset;
                ClearLoadedSource();
            }

            using (new EditorGUI.DisabledScope(sourceAsset == null))
            {
                if (GUILayout.Button("元画像を読み込む")) LoadSource();
            }

            if (loadedSource == null || sourcePreview == null)
            {
                EditorGUILayout.HelpBox("テクスチャを指定して「元画像を読み込む」を押してください。", MessageType.Warning);
                EditorGUILayout.EndScrollView();
                return;
            }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("画像情報", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("サイズ", loadedSource.Pixels.Width + " × " + loadedSource.Pixels.Height);
            if (!string.IsNullOrEmpty(loadedSource.Warning))
                EditorGUILayout.HelpBox(loadedSource.Warning, MessageType.Warning);
            if (loadedSource.Pixels.Pixels.Length > 4194304)
                EditorGUILayout.HelpBox("高解像度画像です。プレビュー計算に時間とメモリを使用する場合があります。", MessageType.Warning);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("変換設定", EditorStyles.boldLabel);
            int nextModeIndex = EditorGUILayout.Popup("変換方式", (int)mode, new[] { "単色変換", "2点の色の流れ" });
            RecolorMode nextMode = (RecolorMode)nextModeIndex;
            if (nextMode != mode)
            {
                mode = nextMode;
                lastResult = null;
                DestroyResultPreview();
                activePoint = 0;
            }

            EditorGUI.BeginChangeCheck();
            if (mode == RecolorMode.SingleColor)
            {
                targetColor = DrawTargetColorField("変換先の色", targetColor);
                DrawSampleLabel("変換元", firstX, firstY);
                EditorGUILayout.HelpBox("下の元画像をクリックして変換元の色を1つ選択してください。明暗の範囲はエンジンが画像内の分布から推定します。", MessageType.None);
            }
            else
            {
                activePoint = GUILayout.Toolbar(activePoint, new[] { "1点目を選択", "2点目を選択" });
                DrawSampleLabel("1点目", firstX, firstY);
                DrawSampleLabel("2点目", secondX, secondY);
                targetStartColor = DrawTargetColorField("変換先・1点目", targetStartColor);
                targetEndColor = DrawTargetColorField("変換先・2点目", targetEndColor);
                EditorGUILayout.HelpBox(activePoint == 0
                    ? "元画像をクリックして1点目を選択してください。"
                    : "元画像をクリックして2点目を選択してください。", MessageType.None);
            }

            if (EditorGUI.EndChangeCheck())
            {
                lastResult = null;
                DestroyResultPreview();
            }

            EditorGUILayout.Space();
            EditorGUILayout.BeginHorizontal();
            DrawSourcePreview();
            DrawResultPreview();
            EditorGUILayout.EndHorizontal();

            bool hasSamples = firstX >= 0 && firstY >= 0 &&
                              (mode == RecolorMode.SingleColor || (secondX >= 0 && secondY >= 0));
            using (new EditorGUI.DisabledScope(!hasSamples))
            {
                if (GUILayout.Button("変換プレビューを作成")) BuildPreview();
            }

            if (lastResult != null)
            {
                EditorGUILayout.LabelField(
                    "対象ピクセル: " + lastResult.MatchedPixels.ToString("N0") +
                    " / 部分適用: " + lastResult.PartiallyMatchedPixels.ToString("N0") +
                    " / 不透明: " + lastResult.OpaquePixels.ToString("N0"),
                    EditorStyles.miniLabel);
                outputName = EditorGUILayout.TextField("保存名", string.IsNullOrEmpty(outputName) ? sourceAsset.name + "_Recolored" : outputName);
                if (GUILayout.Button("PNGとして別名保存")) SaveResult();
            }

            if (!string.IsNullOrEmpty(statusMessage))
                EditorGUILayout.HelpBox(statusMessage, MessageType.Info);

            EditorGUILayout.EndScrollView();
        }

        private void DrawSourcePreview()
        {
            using (new EditorGUILayout.VerticalScope(GUILayout.MinWidth(150f)))
            {
                EditorGUILayout.LabelField("元画像（クリックして色を選択）", EditorStyles.centeredGreyMiniLabel);
                Rect container = GUILayoutUtility.GetRect(150f, 220f, GUILayout.ExpandWidth(true));
                GUI.Box(container, GUIContent.none);
                Rect imageRect = GetAspectRect(container, sourcePreview.width, sourcePreview.height);
                GUI.DrawTexture(imageRect, sourcePreview, ScaleMode.StretchToFill, true);
                DrawMarker(imageRect, firstX, firstY, loadedSource.Pixels.Width, loadedSource.Pixels.Height, new Color(1f, 0.25f, 0.2f, 1f));
                if (mode == RecolorMode.TwoPointFlow)
                    DrawMarker(imageRect, secondX, secondY, loadedSource.Pixels.Width, loadedSource.Pixels.Height, new Color(0.2f, 0.85f, 1f, 1f));

                Event current = Event.current;
                if (current.type == EventType.MouseDown && current.button == 0 && imageRect.Contains(current.mousePosition))
                {
                    int x = Mathf.Clamp(Mathf.FloorToInt((current.mousePosition.x - imageRect.x) / imageRect.width * loadedSource.Pixels.Width), 0, loadedSource.Pixels.Width - 1);
                    int y = Mathf.Clamp(Mathf.FloorToInt((imageRect.yMax - current.mousePosition.y) / imageRect.height * loadedSource.Pixels.Height), 0, loadedSource.Pixels.Height - 1);
                    if (mode == RecolorMode.SingleColor || activePoint == 0)
                    {
                        firstX = x;
                        firstY = y;
                    }
                    else
                    {
                        secondX = x;
                        secondY = y;
                    }
                    lastResult = null;
                    DestroyResultPreview();
                    statusMessage = "スポイト位置を更新しました。";
                    current.Use();
                    Repaint();
                }
            }
        }

        private void DrawResultPreview()
        {
            using (new EditorGUILayout.VerticalScope(GUILayout.MinWidth(150f)))
            {
                EditorGUILayout.LabelField("変換結果", EditorStyles.centeredGreyMiniLabel);
                Rect container = GUILayoutUtility.GetRect(150f, 220f, GUILayout.ExpandWidth(true));
                GUI.Box(container, GUIContent.none);
                if (resultPreview == null)
                {
                    GUI.Label(container, "プレビューなし", EditorStyles.centeredGreyMiniLabel);
                    return;
                }
                Rect imageRect = GetAspectRect(container, resultPreview.width, resultPreview.height);
                GUI.DrawTexture(imageRect, resultPreview, ScaleMode.StretchToFill, true);
            }
        }

        private void LoadSource()
        {
            try
            {
                ClearLoadedSource();
                loadedSource = TextureSourceReader.Load(sourceAsset);
                sourcePreview = CreateViewTexture(loadedSource.Pixels);
                outputName = sourceAsset.name + "_Recolored";
                statusMessage = "元画像を読み込みました。";
            }
            catch (Exception exception)
            {
                ClearLoadedSource();
                statusMessage = "読み込みに失敗しました: " + exception.Message;
                Debug.LogException(exception);
            }
        }

        private void BuildPreview()
        {
            try
            {
                if (mode == RecolorMode.SingleColor)
                {
                    lastResult = TextureColorEngine.RecolorSingle(
                        loadedSource.Pixels, firstX, firstY, ToSrgbRgba(targetColor));
                }
                else
                {
                    lastResult = TextureColorEngine.RecolorTwoPoint(
                        loadedSource.Pixels, firstX, firstY, secondX, secondY,
                        ToSrgbRgba(targetStartColor), ToSrgbRgba(targetEndColor));
                }

                DestroyResultPreview();
                resultPreview = CreateViewTexture(lastResult.Image);
                statusMessage = "プレビューを作成しました。保存画像も同じエンジン結果を使用します。";
            }
            catch (Exception exception)
            {
                lastResult = null;
                DestroyResultPreview();
                statusMessage = "変換に失敗しました: " + exception.Message;
                Debug.LogException(exception);
            }
        }

        private void SaveResult()
        {
            try
            {
                string folder = string.IsNullOrEmpty(loadedSource.AssetPath)
                    ? "Assets"
                    : Path.GetDirectoryName(loadedSource.AssetPath).Replace('\\', '/');
                // Package assets and generated textures may not live under Assets/. Export user output
                // into Assets instead of attempting to write into a read-only Packages directory.
                if (!(folder == "Assets" || folder.StartsWith("Assets/", StringComparison.Ordinal)))
                    folder = "Assets";
                string savedPath = TextureSourceReader.ExportPng(loadedSource, lastResult.Image, folder, outputName);
                UnityEngine.Object saved = AssetDatabase.LoadAssetAtPath<Texture2D>(savedPath);
                if (saved != null) EditorGUIUtility.PingObject(saved);
                statusMessage = "PNGを保存しました: " + savedPath;
            }
            catch (Exception exception)
            {
                statusMessage = "保存に失敗しました: " + exception.Message;
                Debug.LogException(exception);
            }
        }

        private void DrawSampleLabel(string label, int x, int y)
        {
            if (x < 0 || y < 0)
            {
                EditorGUILayout.LabelField(label, "未選択", EditorStyles.miniLabel);
                return;
            }
            Rgba32 pixel = loadedSource.Pixels.Pixels[y * loadedSource.Pixels.Width + x];
            EditorGUILayout.LabelField(label,
                "(" + x + ", " + y + ")  RGBA(" + pixel.R + ", " + pixel.G + ", " + pixel.B + ", " + pixel.A + ")",
                EditorStyles.miniLabel);
        }

        private static void DrawMarker(Rect imageRect, int x, int y, int textureWidth, int textureHeight, Color color)
        {
            if (x < 0 || y < 0 || textureWidth <= 0 || textureHeight <= 0) return;
            float px = imageRect.x + (x + 0.5f) / textureWidth * imageRect.width;
            float py = imageRect.yMax - (y + 0.5f) / textureHeight * imageRect.height;
            EditorGUI.DrawRect(new Rect(px - 5f, py - 0.75f, 10f, 1.5f), color);
            EditorGUI.DrawRect(new Rect(px - 0.75f, py - 5f, 1.5f, 10f), color);
        }

        private static Rect GetAspectRect(Rect container, int width, int height)
        {
            float aspect = (float)width / height;
            float containerAspect = container.width / container.height;
            if (aspect > containerAspect)
            {
                float drawnHeight = container.width / aspect;
                return new Rect(container.x, container.y + (container.height - drawnHeight) * 0.5f, container.width, drawnHeight);
            }
            float drawnWidth = container.height * aspect;
            return new Rect(container.x + (container.width - drawnWidth) * 0.5f, container.y, drawnWidth, container.height);
        }

        private static Color DrawTargetColorField(string label, Color value)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.PrefixLabel(new GUIContent(label, "色の見本をクリックして、色相リングとカラーフィールドから変換先の色を選択します。"));
                // Unity's native Color Picker provides visual hue / saturation / value selection.
                // Alpha and HDR are disabled because the recolor engine accepts ordinary LDR colors
                // and preserves the source pixel alpha channel.
                return EditorGUILayout.ColorField(GUIContent.none, value, false, false, false, GUILayout.MinWidth(88f));
            }
        }

        private static Rgba32 ToSrgbRgba(Color color)
        {
            // ColorField returns the selected LDR color through Unity's standard Color API.
            // The engine contract remains sRGB RGBA8; the original texture alpha is preserved
            // later by the engine, so the selected target alpha is deliberately opaque.
            Color32 bytes = color;
            return new Rgba32(bytes.r, bytes.g, bytes.b, 255);
        }

        private static Texture2D CreateViewTexture(TexturePixels pixels)
        {
            Texture2D texture = new Texture2D(pixels.Width, pixels.Height, TextureFormat.RGBA32, false, false);
            Color32[] colors = new Color32[pixels.Pixels.Length];
            for (int i = 0; i < colors.Length; i++)
            {
                Rgba32 p = pixels.Pixels[i];
                colors[i] = new Color32(p.R, p.G, p.B, p.A);
            }
            texture.SetPixels32(colors);
            texture.Apply(false, false);
            return texture;
        }

        private void ClearLoadedSource()
        {
            DestroyPreviewTextures();
            loadedSource = null;
            lastResult = null;
            firstX = firstY = secondX = secondY = -1;
            statusMessage = null;
        }

        private void DestroyPreviewTextures()
        {
            DestroyTexture(ref sourcePreview);
            DestroyTexture(ref resultPreview);
        }

        private void DestroyResultPreview()
        {
            DestroyTexture(ref resultPreview);
        }

        private static void DestroyTexture(ref Texture2D texture)
        {
            if (texture == null) return;
            UnityEngine.Object.DestroyImmediate(texture);
            texture = null;
        }
    }
}
