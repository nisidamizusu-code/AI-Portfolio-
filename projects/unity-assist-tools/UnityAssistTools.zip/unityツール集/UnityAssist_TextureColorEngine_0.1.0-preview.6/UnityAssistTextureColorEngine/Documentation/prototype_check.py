# Independent Python mirror used only to inspect the prototype's selection model against bundled sample textures.
# This is not a Unity/C# runtime test.
import numpy as np
from PIL import Image
from pathlib import Path


def srgb_to_linear(x):
    return np.where(x <= 0.04045, x / 12.92, ((x + 0.055) / 1.055) ** 2.4)


def to_oklch(rgba):
    rgb = srgb_to_linear(rgba[:, :3].astype(np.float32) / 255.0)
    r, g, b = rgb[:, 0], rgb[:, 1], rgb[:, 2]
    l = 0.4122214708*r + 0.5363325363*g + 0.0514459929*b
    m = 0.2119034982*r + 0.6806995451*g + 0.1073969566*b
    s = 0.0883024619*r + 0.2817188376*g + 0.6299787005*b
    lr, mr, sr = np.cbrt(l), np.cbrt(m), np.cbrt(s)
    L = 0.2104542553*lr + 0.7936177850*mr - 0.0040720468*sr
    a = 1.9779984951*lr - 2.4285922050*mr + 0.4505937099*sr
    bb = 0.0259040371*lr + 0.7827717662*mr - 0.8086757660*sr
    C = np.sqrt(a*a + bb*bb)
    H = np.mod(np.degrees(np.arctan2(bb, a)), 360.0)
    return np.stack([L, C, H], axis=1)


def hue_diff(a,b):
    d = np.abs(a-b)
    return np.minimum(d, 360-d)


def profile_for(image_path, sample_xy):
    rgba = np.asarray(Image.open(image_path).convert('RGBA'))
    h,w,_ = rgba.shape
    sx,sy = sample_xy
    sample_rgba = rgba[sy,sx].reshape(1,4)
    sample = to_oklch(sample_rgba)[0]
    print('sample RGBA', sample_rgba[0].tolist(), 'OKLCH', sample.tolist())
    all_rgba = rgba.reshape(-1,4)
    all_lch = to_oklch(all_rgba)
    alpha = all_rgba[:,3]
    if sample[1] < 0.008:
        return rgba, all_lch, sample, None
    Lbin_count=16
    hueBins=360
    chromaBins=128
    hhist=np.zeros((Lbin_count,hueBins),dtype=np.float32)
    L=all_lch[:,0]; C=all_lch[:,1]; H=all_lch[:,2]
    lbin=np.clip(np.floor(np.clip(L,0,1)*Lbin_count).astype(int),0,Lbin_count-1)
    hbin=np.rint(H).astype(int)%hueBins
    cand=(alpha>=16)&(C>=0.012)&(hue_diff(sample[2],H)<=52)
    ids=lbin[cand]*hueBins+hbin[cand]
    w0=1.0+np.minimum(C[cand],0.25)
    hhist=np.bincount(ids,weights=w0,minlength=Lbin_count*hueBins).reshape(Lbin_count,hueBins).astype(np.float32)
    bcounts=np.bincount(lbin[cand],minlength=Lbin_count)
    hues=np.full(Lbin_count, sample[2], dtype=np.float32)
    htol=np.full(Lbin_count,12.0,dtype=np.float32)
    populated=bcounts>0
    for lb in range(Lbin_count):
        if not populated[lb]: continue
        bestHue=int(round(sample[2]))%hueBins
        bestScore=-1
        for hbin0 in range(hueBins):
            if hue_diff(sample[2],hbin0)>52: continue
            score=sum(hhist[lb,(hbin0+off)%hueBins]*(4-abs(off)) for off in range(-3,4))
            score/=1+hue_diff(sample[2],hbin0)*0.018
            if score>bestScore:
                bestScore=score; bestHue=hbin0
        hues[lb]=bestHue
    for lb in range(Lbin_count):
        if populated[lb]: continue
        nearest=None
        for radius in range(1,Lbin_count):
            for candbin in [lb-radius,lb+radius]:
                if 0<=candbin<Lbin_count and populated[candbin]:
                    nearest=candbin;break
            if nearest is not None:break
        if nearest is not None: hues[lb]=hues[nearest]
    hd=hue_diff(hues[lbin],H)
    valid=(alpha>=16)&(C>=0.006)&populated[lbin]&(hd<=18)
    cb=np.clip((C/0.004).astype(int),0,chromaBins-1)
    hb=np.clip(np.rint(hd).astype(int),0,90)
    chist=np.bincount(lbin[valid]*chromaBins+cb[valid],minlength=Lbin_count*chromaBins).reshape(Lbin_count,chromaBins)
    hspread=np.bincount(lbin[valid]*91+hb[valid],minlength=Lbin_count*91).reshape(Lbin_count,91)
    pcounts=np.bincount(lbin[valid],minlength=Lbin_count)
    med=np.zeros(Lbin_count);minc=np.zeros(Lbin_count);maxc=np.zeros(Lbin_count)
    for lb in range(Lbin_count):
        if not populated[lb]:
            near=None
            for radius in range(1,Lbin_count):
                for bb in [lb-radius,lb+radius]:
                    if 0<=bb<Lbin_count and populated[bb]: near=bb;break
                if near is not None:break
            if near is not None: med[lb],minc[lb],maxc[lb],htol[lb]=med[near],minc[near],maxc[near],htol[near]
            else: med[lb]=max(sample[1],.02);minc[lb]=med[lb]*.22;maxc[lb]=med[lb]*2.2+.03
            continue
        cnt=pcounts[lb]
        def perc(hist,p):
            target=max(1,int(np.ceil(cnt*p)))
            return min(len(hist)-1,int(np.searchsorted(np.cumsum(hist),target,side='left')))
        medc=perc(chist[lb],.5)*.004
        p10=perc(chist[lb],.1)*.004
        p95=perc(chist[lb],.95)*.004
        p80=perc(hspread[lb],.8)
        med[lb]=max(.008,medc)
        minc[lb]=max(.006,medc*.22,p10*.65)
        maxc[lb]=max(medc*1.8,p95*1.25)+.018
        htol[lb]=np.clip(7.5+p80*.35,8,20)
    for lb in range(Lbin_count):
        if populated[lb]: continue
        nearest=None
        for radius in range(1,Lbin_count):
            for candbin in [lb-radius,lb+radius]:
                if 0<=candbin<Lbin_count and populated[candbin]: nearest=candbin;break
            if nearest is not None: break
        if nearest is not None:
            hues[lb],htol[lb],med[lb],minc[lb],maxc[lb] = hues[nearest],htol[nearest],med[nearest],minc[nearest],maxc[nearest]
    profile=(hues,htol,med,minc,maxc)
    return rgba,all_lch,sample,profile


def weights(all_lch, sample, profile):
    hues,htol,med,minc,maxc=profile
    L=all_lch[:,0]; C=all_lch[:,1]; H=all_lch[:,2]
    lb=np.clip(np.floor(np.clip(L,0,1)*16).astype(int),0,15)
    # Interpolate bin values like runtime code
    pos=np.clip(L,0,1)*15
    lo=np.floor(pos).astype(int); hi=np.minimum(15,lo+1);t=pos-lo
    center=(hues[lo]+((hues[hi]-hues[lo]+180)%360-180)*t)%360
    tol=htol[lo]*(1-t)+htol[hi]*t
    medc=med[lo]*(1-t)+med[hi]*t
    mincc=minc[lo]*(1-t)+minc[hi]*t
    maxcc=maxc[lo]*(1-t)+maxc[hi]*t
    hd=hue_diff(center,H)
    def smooth(e0,e1,x):
        e0=np.asarray(e0); e1=np.asarray(e1); x=np.asarray(x)
        valid=e1>e0
        denom=np.where(valid,e1-e0,1.0)
        z=np.clip((x-e0)/denom,0,1)
        normal=z*z*(3-2*z)
        return np.where(valid,normal,np.where(x>=e1,1.0,0.0))
    hw=1-smooth(tol,tol+4,hd)
    reliability=smooth(.006,.016,C)
    cw=smooth(mincc*.62,mincc*1.18,C)*(1-smooth(maxcc,maxcc*1.22+.012,C))
    return hw*reliability*cw

if __name__=='__main__':
    root=Path('/mnt/data/files')
    cases=[('Clothes1_BaseColor.png',(1500,300)),('Clothes2_BaseColor.png',(50,40)),('Clothes2_BaseColor.png',(700,500))]
    for fn,xy in cases:
        rgba,all_lch,sample,profile=profile_for(root/fn,xy)
        if profile is None: continue
        w=weights(all_lch,sample,profile)
        w=np.where(w > 0.01, w, 0.0)  # match Runtime's MinimumApplyWeight
        opaque=rgba.reshape(-1,4)[:,3]>=16
        print(fn,xy,'matched full',int(np.sum((w>=.999)&opaque)),'partial',int(np.sum((w>.001)&(w<.999)&opaque)),'opaque',int(opaque.sum()),'fraction',round(float(np.sum(w*opaque)/opaque.sum()),3))
        # Samples from known non-selected colors in the same texture
        for p in [(1300,1300),(1500,100),(100,100),(100,1500),(1700,1500)]:
            if p[0]<rgba.shape[1] and p[1]<rgba.shape[0]:
                pix=rgba[p[1],p[0]].reshape(1,4); lch=to_oklch(pix)[0]
                wt=float(weights(lch.reshape(1,3),sample,profile)[0])
                print(' ',p,pix[0].tolist(),'OKLCH',np.round(lch,3).tolist(),'w',round(wt,3))
