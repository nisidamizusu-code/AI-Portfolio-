# Numerical mirror of the independent two-point selector; this does not execute Unity/C#.
import numpy as np
from pathlib import Path
from PIL import Image
from prototype_check import to_oklch, profile_for, hue_diff, weights


def smooth(e0, e1, x):
    e0 = np.asarray(e0); e1 = np.asarray(e1); x = np.asarray(x)
    valid = e1 > e0
    denom = np.where(valid, e1-e0, 1.0)
    t = np.clip((x-e0)/denom, 0, 1)
    val = t*t*(3-2*t)
    return np.where(valid, val, np.where(x >= e1, 1.0, 0.0))


def signed_hue_delta(a, b):
    d = (b-a+180.0) % 360.0 - 180.0
    return d


def hue_arc_weight(h, start_h, delta_h, margin_deg):
    progress = signed_hue_delta(start_h, h) / delta_h
    margin = margin_deg / max(5.0, abs(delta_h))
    return np.where(progress < 0, smooth(-margin, 0.0, progress),
                    np.where(progress > 1, 1-smooth(1.0, 1.0+margin, progress), 1.0))


def range_weight(v, lo, hi, softness):
    return np.where(v < lo, smooth(lo-softness, lo, v),
                    np.where(v > hi, 1-smooth(hi, hi+softness, v), 1.0))


def two_point_weights(img_rgba, p0, p1, profile):
    H,W,_=img_rgba.shape
    pixels=img_rgba.reshape(-1,4)
    lch=to_oklch(pixels)
    x0,y0=p0; x1,y1=p1
    a=to_oklch(img_rgba[y0,x0].reshape(1,4))[0]
    b=to_oklch(img_rgba[y1,x1].reshape(1,4))[0]
    dl=b[0]-a[0]; dc=b[1]-a[1]; dh=signed_hue_delta(a[2],b[2])
    useL=abs(dl)>=.045; useC=abs(dc)>=.025; useH=abs(dh)>=5
    L,C,Hh=lch[:,0],lch[:,1],lch[:,2]
    w=np.ones(len(pixels),dtype=np.float32)
    if useL:
        lo=min(a[0],b[0])-.065; hi=max(a[0],b[0])+.065
        w*=range_weight(L,lo,hi,.02)
    minc=min(a[1],b[1]); maxc=max(a[1],b[1])
    if useC:
        adapt=min(.025,max(.006,minc*.35))
        lo=max(0,minc-adapt); hi=maxc+.025
        w*=range_weight(C,lo,hi,.01)
    elif maxc>=.012:
        floor=minc*.24; low=max(.006,floor*.45); high=max(.014,floor)
        w*=smooth(low,high,C)
    if useH:
        w*=hue_arc_weight(Hh,a[2],dh,9.0)
    else:
        hues,htol,med,minv,maxv=profile
        pos=np.clip(L,0,1)*15
        lo=np.floor(pos).astype(int); hi=np.minimum(15,lo+1); t=pos-lo
        center=(hues[lo]+((hues[hi]-hues[lo]+180)%360-180)*t)%360
        tol=htol[lo]*(1-t)+htol[hi]*t
        limit=np.maximum(tol,9)
        w*=1-smooth(limit,limit+5,hue_diff(center,Hh))
    w[pixels[:,3] < 16]=0
    w[w <= 0.01] = 0
    w[y0*W+x0]=1; w[y1*W+x1]=1
    return w,a,b,(useL,useC,useH)


if __name__=='__main__':
    path=Path('/mnt/data/files/Clothes2_BaseColor.png')
    img=np.asarray(Image.open(path).convert('RGBA'))
    # Build start profile from a sampled point; coordinates here use PIL top-left solely for this offline model.
    _,_,sample,profile=profile_for(path,(50,40))
    w,a,b,axes=two_point_weights(img,(50,40),(700,500),profile)
    alpha=img[:,:,3].reshape(-1)>=16
    print('actual sample two-point case: start/end OKLCH',np.round(a,4).tolist(),np.round(b,4).tolist(),'active axes',axes)
    print('coverage full/partial/opaque/ratio',int(np.sum((w>=.999)&alpha)),int(np.sum((w>.001)&(w<.999)&alpha)),int(alpha.sum()),round(float(w[alpha].sum()/alpha.sum()),4))
    for p in [(1300,1300),(100,1500),(1700,1500),(100,100),(700,500),(50,40)]:
        x,y=p; pix=img[y,x].reshape(1,4); lch=to_oklch(pix)[0]; wt=float(w[y*img.shape[1]+x])
        print('sample',p,'RGBA',pix[0].tolist(),'OKLCH',np.round(lch,4).tolist(),'weight',round(wt,4))

    # Synthetic hue wrap-around and out-of-arc guard.
    hs=np.array([350,355,0,5,10,15,20,25,30,35,40,180],dtype=float)
    vals=hue_arc_weight(hs,350,50,9)
    print('hue arc wrap samples',list(zip(hs.tolist(),np.round(vals,3).tolist())))
