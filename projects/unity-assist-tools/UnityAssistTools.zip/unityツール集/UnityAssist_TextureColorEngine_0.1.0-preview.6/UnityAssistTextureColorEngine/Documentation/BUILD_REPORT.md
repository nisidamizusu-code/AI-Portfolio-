# Build / Change Report — Unity Assist Texture Color Engine 0.1.0-preview.6

## Requested change

変換先の色指定をHEXテキスト入力から、Unity標準Color Pickerによる視覚的な色指定へ変更。

## UI changes

- 単色方式: 変換先色の入力を `EditorGUILayout.ColorField` に変更。
- 2点方式: 変換先1点目・2点目をそれぞれ `EditorGUILayout.ColorField` に変更。
- 色見本をクリックするとUnity標準Color Pickerが開き、色相リングと中央の色選択フィールドで色を指定できる。
- HDRとアルファ指定は非表示。画像のアルファは従来どおりエンジン側で保持。
- HEX文字列入力欄およびHEXパース処理をEditor UIから削除。

## Scope control

- 変更対象: `Editor/TextureColorEngineSandboxWindow.cs`、`package.json`、README、CHANGELOG、BUILD_REPORT。
- `Runtime/` 以下の色認識・単色変換・2点変換・色空間変換コードは変更していない。
- `TextureSourceReader.cs`、テストコード、Assembly Definitionは変更していない。
- 変換先の色はColorFieldからsRGB RGBA8へ変換して、従来と同じ `Rgba32` エンジン引数に渡す。

## Static verification

- package.json と全Assembly DefinitionをJSONとして解析。
- HEX UI用フィールド・HEX入力ヘルパーの残存がないことを確認。
- ColorField helperを単色・2点方式の3か所で使用していることを確認。
- RuntimeおよびテストコードのSHA-256がpreview.4と一致することを確認。
- ZIP CRC / 展開テストを実施。

## Not performed

- Unity Editorでの実コンパイル
- Unity 2021.3上でのColor Picker操作確認
- Linear/Gamma双方でのGUI選択値とsRGB byte値の実測確認
- 変換アルゴリズムの動作確認（今回変更対象外）

Unity公式ドキュメントでは `EditorGUILayout.ColorField` がColor Pickerを開くColorフィールドとして説明されている。UnityのColor Pickerは色相リングと中央の色選択領域を備える。ただし、Unity Editor実機上での最終確認は必要。


## Preview 6 UI cleanup

- Removed unnecessary version-dependency explanation from the visible window.
- Renamed menu and window title to Texture Color Replacer.
- Removed the technical read-method row from the user-facing UI.
- Runtime source files were not modified.
