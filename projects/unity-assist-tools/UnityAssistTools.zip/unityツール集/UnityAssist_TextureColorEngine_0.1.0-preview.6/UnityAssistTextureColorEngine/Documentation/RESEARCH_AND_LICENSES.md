# Research Notes and License Record

このエンジンは、既存製品のコードを無断コピーせず、公開されている仕様・変更履歴・技術資料を比較して独立実装する方針です。コードを実際に採用する場合は、その時点で対象リポジトリのLICENSE、NOTICE、依存ライブラリ、配布条件を再確認し、採用ファイルと由来を記録します。

## Reference projects and products

### Iroca / いろか
- Repository: https://github.com/yukkuri-aoba/Iroca
- Changelog: https://github.com/yukkuri-aoba/Iroca/blob/main/CHANGELOG.md
- Manual: https://yukkuri-aoba.github.io/Iroca/manual/
- BOOTH: https://booth.pm/ja/items/8169184
- License: PolyForm Shield License 1.0.0.
- Reviewed ideas: material-color selection from one sample, lightness-conditioned hue/chroma distribution, shadow/highlight expansion, edge AA cleanup, alpha decontamination, UV/material context, parallel processing.
- Restriction: PolyForm Shield contains a competitive-use restriction. Iroca source code, implementation code, assets, and derived code are not copied or ported into this competing color-replacement package. Only public-facing feature descriptions and high-level product behavior are considered as independent design references.

### Avenix Studio (formerly IroKae Studio)
- BOOTH: https://booth.pm/ja/items/9036560
- Reviewed ideas: selection by UV island / similar color / full material; additive and subtractive picking; OKLab recolor while retaining shade and pattern; hue/saturation/luminance/contrast adjustments; emission recolor; non-destructive preview and output settings preservation.
- Code status: no source code or assets copied. Product terms do not establish a general code-reuse permission; treat as specification-only unless the creator grants permission.

### Color-Changer
- Repository: https://github.com/puk06/Color-Changer
- License: MIT (Copyright 2025 pukorufu; verify the current LICENSE before each source import).
- Reviewed ideas: source-to-target color-difference transfer, alternate transfer calculations, optional partial application, alpha preservation.
- Code status: no external code copied in preview.4. MIT permits reuse subject to retaining copyright and license notices, but no code has been imported yet.

### Color-Changer-For-Unity
- Repository: https://github.com/puk06/Color-Changer-For-Unity
- License: MIT (Copyright 2025 pukorufu; verify the current LICENSE before each source import).
- Reviewed ideas: Runtime / Editor separation, non-destructive preview, export from a derived texture, Unity color-space handling.
- Code status: no external code copied in preview.4.

### Texture Color Adjuster / TexColorAdjuster
- Repository: https://github.com/nekoare/texture-color-adjuster
- BOOTH: https://booth.pm/ja/items/7182575
- License: MIT (check current repository LICENSE and notices before reuse).
- Reviewed ideas: LAB histogram and color-distribution matching, lightness-conditioned matching, hue transfer, luminance preservation, dual-color selection. Changelog also documents a preview/export path mismatch fix, which is a useful regression-test lesson.
- Code status: no external code copied in preview.4.

### TexRecolor
- BOOTH: https://booth.pm/ja/items/9083135
- Reviewed ideas: OKLab lightness preservation, independent color-family selection, exclusion colors, UV-island option, edge feathering, direct original PNG reading, importer settings copied to output.
- Product notes: its page reports Unity 6 testing and notes Unity 2022.3 was not verified at the time of the listing. Product claims are not treated as independent test evidence.
- Code status: closed / no reusable source license identified; public specification only.

### TexColorAdjuster
- BOOTH: https://booth.pm/ja/items/7182575
- Reviewed ideas: reference/target texture comparison, color distribution analysis, per-lightness color matching.
- Code status: MIT is stated for the associated project; no source code copied in preview.4.

### Color Matcher
- BOOTH: https://booth.pm/ja/items/8963911
- Reviewed ideas: direct PNG/JPG source-file read, average-color and shading preservation, importer settings copied to the generated PNG.
- Code status: product implementation is not publicly licensed for reuse; specification only.

### Click Recolor
- BOOTH: https://booth.pm/ja/items/9065378
- Reviewed ideas: scene click and UV-island-based selection when color-only selection cannot distinguish separate parts.
- Code status: product source reuse permission not established; specification only. Current user direction does not call for a manual mask / Scene-selection UI in this prototype.

### TexStack
- BOOTH: https://booth.pm/ja/items/8596019
- Repository: https://github.com/puk06/TexStackEditor
- Reviewed ideas: mesh and UV context, normals, curvature, layers, non-destructive editing.
- License handling: repository and BOOTH terms must be interpreted separately. The BOOTH product terms restrict redistribution of the tool's code/shaders/docs; this package therefore uses feature descriptions only and copies no TexStack code, shaders, or assets.

### Miyabix Tool
- BOOTH: https://booth.pm/ja/items/9132637
- Reviewed ideas: sampled-color replacement, preserving lightness gradients, temporary readable copy for non-Read/Write textures, separate PNG export.
- Product notes: listing discloses that not all Unity checks were completed. This is a design reference, not a validated implementation.
- Code status: no source license established; specification only.

### Kalon Texture Color Changer
- BOOTH: https://booth.pm/ja/items/7912605
- Reviewed ideas: relative color, HSV/Gamma/Tint compositing, Normal/Multiply/Add/Overlay blending, threshold/near-color selection, lightweight preview and full-resolution export.
- Code status: no clear source-reuse license established; specification only.

### Shiwasu Texture Harmonizer
- BOOTH: https://booth.pm/ja/items/8944105
- Reviewed ideas: reference / target / result comparison, reference-based texture color matching.
- Code status: specification only.

### VRC Color Changer
- BOOTH: https://booth.pm/ja/items/6519471
- Repository: https://github.com/puk06/Color-Changer
- Reviewed ideas: source-to-target color-difference transfer, preserving color balance, selectable application regions, brightness/contrast control.
- Code status: MIT repository is a possible source for future code reuse, but nothing was copied in preview.4.

### Additional recolor products
- Miyabix Tool: https://booth.pm/ja/items/9132637
- TexRecolor: https://booth.pm/ja/items/9083135
- Avenix Studio: https://booth.pm/ja/items/9036560
- VRC Color Changer: https://booth.pm/ja/items/6519471
- Reviewed ideas: original file input, material color-family recognition, per-lightness processing, edge cleanup, relative color transfer, UV-aware selection, and deterministic preview/export paths.

## Unity API references
- Texture2D.GetPixels32: https://docs.unity3d.com/2021.3/Documentation/ScriptReference/Texture2D.GetPixels32.html
- ImageConversion.LoadImage: https://docs.unity3d.com/2021.3/Documentation/ScriptReference/ImageConversion.LoadImage.html
- TextureImporter: https://docs.unity3d.com/2021.3/Documentation/ScriptReference/TextureImporter.html
- Color.linear: https://docs.unity3d.com/ScriptReference/Color-linear.html
- GL.sRGBWrite: https://docs.unity3d.com/ScriptReference/GL-sRGBWrite.html
- Reviewed ideas: Read/Write constraints, import-time Max Size / compression, PNG/JPEG source decoding, gamma/linear crossover, GPU readback state restoration, and output importer-setting preservation.
- Important: Unity `ImageConversion.LoadImage` does not perform gamma correction; the temporary texture must be constructed with an intentional sRGB setting for BaseColor input. Imported GPU readback requires explicit handling of the project's color-space and render state.

## License policy
1. Never copy code, shaders, models, textures, or documentation from a project unless its license or creator permission clearly allows the intended use.
2. For MIT code reuse, retain the original copyright and complete license text, preserve required notices, record source URL and commit/hash, and inspect dependency licenses.
3. For PolyForm Shield / competitive-use-restricted code, do not use source code in this competing tool. Public descriptions may inform independently written designs, without copying protected implementation expression.
4. For BOOTH tools whose license is unclear or whose product terms restrict redistribution, use only publicly described behavior as a reference and ask the creator for permission before code reuse.
5. This file is the audit ledger. Update it before adding any third-party source to the package.

## External code incorporated
None in 0.1.0-preview.4. All code currently shipped in this package was authored independently for this prototype. The cited projects informed high-level design only; no source files or assets were copied.

## Design decisions in the independent prototype
- Separate image decoding, color-family analysis, recolor math, preview, and export.
- Keep the Runtime core independent of Unity Editor UI.
- Read source PNG/JPEG/TGA bytes when supported instead of assuming imported texture pixels are the source of truth.
- Use a per-lightness material profile and independent hue/chroma/lightness gates; do not use one Euclidean distance radius as the complete selection rule.
- Treat two-point color flow as its own mapping mode and validate both sampled endpoints.
- Keep sampled endpoint pixels mapped exactly to their target endpoint colors.
- Map out-of-gamut colors by reducing OKLCH chroma while prioritizing lightness and hue, rather than independently clipping RGB channels.
- Keep shading retention and subtle hue/chroma variation as separate internal controls.
- In the test sandbox, specify target colors as explicit sRGB hex strings so test values do not depend on project ColorField behavior.

These are prototype design choices, not claims of proven quality across all VRC materials.
