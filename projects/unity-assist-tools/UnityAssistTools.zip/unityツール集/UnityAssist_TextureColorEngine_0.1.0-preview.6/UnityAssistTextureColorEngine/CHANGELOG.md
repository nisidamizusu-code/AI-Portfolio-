## 0.1.0-preview.6

- Removed development-only wording about the 1.4.1 UI from the editor window.
- Renamed the visible Unity menu item and window title to Texture Color Replacer.
- Simplified user-facing instructions and removed the technical read-method row.
- Kept the runtime color engine, image loading, recoloring, and export logic unchanged.

## 0.1.0-preview.5

- Replaced target-color HEX text fields with Unity's native visual Color Picker field.
- Kept single-color and two-point target color values as ordinary LDR colors; alpha and HDR controls are hidden.
- Left runtime color recognition, recoloring algorithms, source loading, and export code unchanged.

# Changelog

## 0.1.0-preview.4
- Fixed missing scalar `Lerp(float, float, float)` helper in `MaterialColorProfile`.
- Updated package version and build report.

## 0.1.0-preview.3
- Added hex sRGB target-color entry to the sandbox.
- Allowed sandbox PNG export into `Assets/` even when the source asset is under `Packages/`.
- Expanded research and license tracking.
