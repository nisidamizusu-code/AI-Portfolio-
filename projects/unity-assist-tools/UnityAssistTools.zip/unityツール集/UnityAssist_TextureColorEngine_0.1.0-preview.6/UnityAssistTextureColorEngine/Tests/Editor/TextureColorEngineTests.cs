using NUnit.Framework;

namespace UnityAssist.TextureColorEngine.Tests
{
    public sealed class TextureColorEngineTests
    {
        [Test]
        public void SingleColor_PreservesTransparentPixelsAndAlpha()
        {
            Rgba32[] pixels =
            {
                new Rgba32(170, 60, 45, 255),
                new Rgba32(170, 60, 45, 0),
                new Rgba32(130, 45, 35, 128),
                new Rgba32(20, 20, 20, 255)
            };
            TexturePixels image = new TexturePixels(2, 2, pixels, true);
            RecolorResult result = TextureColorEngine.RecolorSingle(image, 0, 0, new Rgba32(45, 90, 180, 255));

            Assert.AreEqual(0, result.Image.Pixels[1].A);
            Assert.AreEqual(128, result.Image.Pixels[2].A);
            Assert.AreEqual(pixels[1].R, result.Image.Pixels[1].R);
            Assert.AreEqual(pixels[1].G, result.Image.Pixels[1].G);
            Assert.AreEqual(pixels[1].B, result.Image.Pixels[1].B);
        }

        [Test]
        public void SingleColor_UsesColorFamilyAndRejectsNeutralBlack()
        {
            const int width = 64;
            const int height = 32;
            Rgba32[] pixels = new Rgba32[width * height];
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    if (x < 40)
                    {
                        float l = 0.28f + (y / (float)(height - 1)) * 0.46f;
                        float c = 0.075f + (y / (float)(height - 1)) * 0.045f;
                        float h = 250f + (y % 5 - 2) * 1.3f;
                        pixels[y * width + x] = ColorMath.ToSrgb(new Oklch(l, c, h), 255);
                    }
                    else if (x < 52)
                    {
                        pixels[y * width + x] = new Rgba32(8, 8, 10, 255);
                    }
                    else
                    {
                        pixels[y * width + x] = new Rgba32(130, 130, 130, 255);
                    }
                }
            }

            TexturePixels image = new TexturePixels(width, height, pixels, true);
            RecolorResult result = TextureColorEngine.RecolorSingle(image, 5, 15, new Rgba32(180, 45, 60, 255));

            Assert.Greater(result.MatchedPixels, 0);
            Assert.AreEqual(pixels[15 * width + 45].R, result.Image.Pixels[15 * width + 45].R);
            Assert.AreEqual(pixels[15 * width + 45].G, result.Image.Pixels[15 * width + 45].G);
            Assert.AreEqual(pixels[15 * width + 45].B, result.Image.Pixels[15 * width + 45].B);
            Assert.AreEqual(pixels[15 * width + 58].R, result.Image.Pixels[15 * width + 58].R);
        }

        [Test]
        public void TwoPointFlow_MapsBothEndpointsAndKeepsNeutralBlackOut()
        {
            const int width = 32;
            Rgba32[] pixels = new Rgba32[width];
            for (int x = 0; x < 20; x++)
            {
                float t = x / 19f;
                pixels[x] = ColorMath.ToSrgb(new Oklch(0.30f + 0.40f * t, 0.10f - 0.025f * t, 248f - 3f * t), 255);
            }
            for (int x = 20; x < width; x++) pixels[x] = new Rgba32(5, 5, 6, 255);

            TexturePixels image = new TexturePixels(width, 1, pixels, true);
            Rgba32 targetStart = new Rgba32(40, 70, 150, 255);
            Rgba32 targetEnd = new Rgba32(100, 160, 220, 255);
            RecolorResult result = TextureColorEngine.RecolorTwoPoint(image, 0, 0, 19, 0, targetStart, targetEnd);

            Assert.Greater(result.MatchedPixels, 0);
            Assert.AreEqual(pixels[25].R, result.Image.Pixels[25].R);
            Assert.AreEqual(pixels[25].G, result.Image.Pixels[25].G);
            Assert.AreEqual(pixels[25].B, result.Image.Pixels[25].B);
            Assert.AreEqual(targetStart.R, result.Image.Pixels[0].R);
            Assert.AreEqual(targetStart.G, result.Image.Pixels[0].G);
            Assert.AreEqual(targetStart.B, result.Image.Pixels[0].B);
            Assert.AreEqual(targetEnd.R, result.Image.Pixels[19].R);
            Assert.AreEqual(targetEnd.G, result.Image.Pixels[19].G);
            Assert.AreEqual(targetEnd.B, result.Image.Pixels[19].B);
        }


        [Test]
        public void TwoPointFlow_UsesBothHueEndpointsAcrossWrapAround()
        {
            const int width = 41;
            Rgba32[] pixels = new Rgba32[width];
            for (int x = 0; x < width; x++)
            {
                float t = x / (float)(width - 1);
                float hue = ColorMath.NormalizeHue(350f + 50f * t);
                pixels[x] = ColorMath.ToSrgb(new Oklch(0.58f, 0.12f, hue), 255);
            }
            TexturePixels image = new TexturePixels(width, 1, pixels, true);
            Rgba32 targetStart = new Rgba32(35, 130, 155, 255);
            Rgba32 targetEnd = new Rgba32(50, 150, 85, 255);

            RecolorResult result = TextureColorEngine.RecolorTwoPoint(
                image, 0, 0, width - 1, 0, targetStart, targetEnd);

            Assert.AreEqual(targetStart.R, result.Image.Pixels[0].R);
            Assert.AreEqual(targetStart.G, result.Image.Pixels[0].G);
            Assert.AreEqual(targetStart.B, result.Image.Pixels[0].B);
            Assert.AreEqual(targetEnd.R, result.Image.Pixels[width - 1].R);
            Assert.AreEqual(targetEnd.G, result.Image.Pixels[width - 1].G);
            Assert.AreEqual(targetEnd.B, result.Image.Pixels[width - 1].B);
            Assert.Greater(result.MatchedPixels, 0);
        }


        [Test]
        public void SingleColor_IncludesMutedDarkMaterialButRejectsNearBlack()
        {
            const int width = 32;
            Rgba32[] pixels = new Rgba32[width];
            for (int x = 0; x < 28; x++)
            {
                float t = x / 27f;
                float lightness = 0.22f + t * 0.5f;
                float chroma = 0.018f + t * 0.082f;
                pixels[x] = ColorMath.ToSrgb(new Oklch(lightness, chroma, 255f), 255);
            }
            pixels[28] = ColorMath.ToSrgb(new Oklch(0.22f, 0.002f, 0f), 255);
            pixels[29] = ColorMath.ToSrgb(new Oklch(0.35f, 0.004f, 0f), 255);
            pixels[30] = new Rgba32(95, 95, 95, 255);
            pixels[31] = new Rgba32(0, 0, 0, 255);

            TexturePixels image = new TexturePixels(width, 1, pixels, true);
            RecolorResult result = TextureColorEngine.RecolorSingle(image, 12, 0, new Rgba32(180, 70, 50, 255));

            Assert.Greater(result.MatchedPixels, 10);
            for (int x = 28; x < width; x++)
            {
                Assert.AreEqual(pixels[x].R, result.Image.Pixels[x].R, "Neutral pixel was recolored at x=" + x);
                Assert.AreEqual(pixels[x].G, result.Image.Pixels[x].G, "Neutral pixel was recolored at x=" + x);
                Assert.AreEqual(pixels[x].B, result.Image.Pixels[x].B, "Neutral pixel was recolored at x=" + x);
            }
        }

        [Test]
        public void TwoPointFlow_RejectsPixelsOutsideHueArcAndNeutralBlack()
        {
            const int width = 24;
            Rgba32[] pixels = new Rgba32[width];
            for (int x = 0; x < 21; x++)
            {
                float t = x / 20f;
                pixels[x] = ColorMath.ToSrgb(new Oklch(0.58f, 0.12f, ColorMath.NormalizeHue(350f + 50f * t)), 255);
            }
            pixels[21] = ColorMath.ToSrgb(new Oklch(0.58f, 0.12f, 180f), 255);
            pixels[22] = ColorMath.ToSrgb(new Oklch(0.58f, 0.003f, 0f), 255);
            pixels[23] = new Rgba32(110, 110, 110, 255);

            TexturePixels image = new TexturePixels(width, 1, pixels, true);
            RecolorResult result = TextureColorEngine.RecolorTwoPoint(
                image, 0, 0, 20, 0, new Rgba32(35, 130, 155, 255), new Rgba32(50, 150, 85, 255));

            for (int x = 21; x < width; x++)
            {
                Assert.AreEqual(pixels[x].R, result.Image.Pixels[x].R, "Out-of-family pixel recolored at x=" + x);
                Assert.AreEqual(pixels[x].G, result.Image.Pixels[x].G, "Out-of-family pixel recolored at x=" + x);
                Assert.AreEqual(pixels[x].B, result.Image.Pixels[x].B, "Out-of-family pixel recolored at x=" + x);
            }
        }

        [Test]
        public void TwoPointFlow_RejectsInvalidStartCoordinate()
        {
            TexturePixels image = new TexturePixels(2, 1, new[]
            {
                new Rgba32(170, 60, 45, 255),
                new Rgba32(130, 45, 35, 255)
            }, true);
            Assert.Throws<System.ArgumentOutOfRangeException>(() => TextureColorEngine.RecolorTwoPoint(
                image, -1, 0, 1, 0, new Rgba32(20, 80, 150, 255), new Rgba32(40, 100, 170, 255)));
        }

        [Test]
        public void GamutMapping_ReturnsValidByteRange()
        {
            Rgba32 result = ColorMath.ToSrgb(new Oklch(0.62f, 0.6f, 32f), 255);
            Assert.AreEqual(255, result.A);
            Assert.That(result.R, Is.InRange(0, 255));
            Assert.That(result.G, Is.InRange(0, 255));
            Assert.That(result.B, Is.InRange(0, 255));
        }

        private static float ColorDifference(Rgba32 a, Rgba32 b)
        {
            Oklab la = ColorMath.ToOklab(a);
            Oklab lb = ColorMath.ToOklab(b);
            float dl = la.L - lb.L;
            float da = la.A - lb.A;
            float db = la.B - lb.B;
            return (float)System.Math.Sqrt(dl * dl + da * da + db * db) * 255f;
        }
    }
}
