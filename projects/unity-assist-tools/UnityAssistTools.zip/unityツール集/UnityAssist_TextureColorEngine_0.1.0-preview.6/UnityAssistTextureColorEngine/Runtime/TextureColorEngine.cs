using System;

namespace UnityAssist.TextureColorEngine
{
    /// <summary>Internal defaults for VRC clothing textures. These are not intended as UI sliders.</summary>
    public sealed class EngineSettings
    {
        public float ShadingRetention = 0.76f;
        public float HueVariationRetention = 0.12f;
        public float ChromaVariationRetention = 0.12f;
        public float TwoPointLightnessMargin = 0.065f;
        public float TwoPointHueMarginDegrees = 9f;
        public float TwoPointChromaMargin = 0.025f;
        public byte TransparentAlphaThreshold = 16;

        public EngineSettings Clone()
        {
            return (EngineSettings)MemberwiseClone();
        }
    }

    /// <summary>
    /// Independent pixel engine. It has no EditorWindow, mask-painting UI, AI dependency, or dependency on the 1.4.1 UI.
    /// Selection is based on a lightness-conditioned hue/chroma profile and independent channel gates, never a Euclidean color-distance radius.
    /// </summary>
    public static class TextureColorEngine
    {
        private const float MinimumApplyWeight = 0.01f;

        public static MaterialColorProfile BuildSingleColorProfile(TexturePixels source, int sampleX, int sampleY)
        {
            return MaterialColorProfile.Build(source, sampleX, sampleY);
        }

        public static RecolorResult RecolorSingle(
            TexturePixels source,
            int sampleX,
            int sampleY,
            Rgba32 targetColor,
            EngineSettings settings = null)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            settings = settings ?? new EngineSettings();
            MaterialColorProfile profile = MaterialColorProfile.Build(source, sampleX, sampleY);
            Oklch target = ColorMath.ToOklch(targetColor);
            int sampleIndex = sampleY * source.Width + sampleX;
            Rgba32[] output = new Rgba32[source.Pixels.Length];
            int matched = 0;
            int partial = 0;
            int opaque = 0;

            for (int i = 0; i < source.Pixels.Length; i++)
            {
                Rgba32 pixel = source.Pixels[i];
                if (pixel.A < settings.TransparentAlphaThreshold)
                {
                    output[i] = pixel;
                    continue;
                }
                opaque++;
                if (i == sampleIndex)
                {
                    // The sampled source pixel is the exact anchor; it must map exactly to the target color.
                    output[i] = new Rgba32(targetColor.R, targetColor.G, targetColor.B, pixel.A);
                    matched++;
                    continue;
                }

                Oklch current = ColorMath.ToOklch(pixel);
                float weight = profile.GetSelectionWeight(current);
                if (weight <= MinimumApplyWeight)
                {
                    output[i] = pixel;
                    continue;
                }

                float profileHue, hueTolerance, medianChroma, minChroma, maxChroma;
                profile.GetAtLightness(current.L, out profileHue, out hueTolerance, out medianChroma, out minChroma, out maxChroma);

                float hueResidual = current.C < 0.012f ? 0f : ColorMath.SignedHueDelta(profileHue, current.H);
                float chromaRatio = current.C / Math.Max(0.012f, medianChroma);
                chromaRatio = ColorMath.Clamp(chromaRatio, 0.72f, 1.55f);

                // Replace material hue/chroma while preserving subdued per-pixel variation and most original luminance detail.
                Oklch changed = new Oklch(
                    target.L + (current.L - profile.SampleColor.L) * ColorMath.Clamp01(settings.ShadingRetention),
                    target.C * (1f + (chromaRatio - 1f) * ColorMath.Clamp01(settings.ChromaVariationRetention)),
                    target.H + hueResidual * ColorMath.Clamp01(settings.HueVariationRetention));

                Oklab blended = ColorMath.Blend(ColorMath.ToOklab(current), ColorMath.ToOklab(changed), weight);
                Oklch outputLch = ColorMath.ToOklch(blended);
                output[i] = ColorMath.ToSrgb(outputLch, pixel.A);
                if (weight >= 0.999f) matched++;
                else partial++;
            }

            return new RecolorResult(new TexturePixels(source.Width, source.Height, output, true), matched, partial, opaque);
        }

        public static RecolorResult RecolorTwoPoint(
            TexturePixels source,
            int startX,
            int startY,
            int endX,
            int endY,
            Rgba32 targetStartColor,
            Rgba32 targetEndColor,
            EngineSettings settings = null)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            settings = settings ?? new EngineSettings();
            if (startX < 0 || startY < 0 || startX >= source.Width || startY >= source.Height)
                throw new ArgumentOutOfRangeException("1点目の座標がテクスチャ範囲外です。");
            if (endX < 0 || endY < 0 || endX >= source.Width || endY >= source.Height)
                throw new ArgumentOutOfRangeException("2点目の座標がテクスチャ範囲外です。");
            Rgba32 startPixel = source.Pixels[startY * source.Width + startX];
            Rgba32 endPixel = source.Pixels[endY * source.Width + endX];
            if (startPixel.A < settings.TransparentAlphaThreshold)
                throw new InvalidOperationException("1点目が透明ピクセルです。");
            if (endPixel.A < settings.TransparentAlphaThreshold)
                throw new InvalidOperationException("2点目が透明ピクセルです。");

            Oklch sourceStart = ColorMath.ToOklch(startPixel);
            Oklch sourceEnd = ColorMath.ToOklch(endPixel);
            Oklch targetStart = ColorMath.ToOklch(targetStartColor);
            Oklch targetEnd = ColorMath.ToOklch(targetEndColor);

            float deltaL = sourceEnd.L - sourceStart.L;
            float deltaC = sourceEnd.C - sourceStart.C;
            float deltaH = ColorMath.SignedHueDelta(sourceStart.H, sourceEnd.H);
            float absL = Math.Abs(deltaL);
            float absC = Math.Abs(deltaC);
            float absH = Math.Abs(deltaH);
            bool useL = absL >= 0.045f;
            bool useC = absC >= 0.025f;
            bool useH = absH >= 5.0f;
            if (!useL && !useC && !useH)
                throw new InvalidOperationException("2点の色が近すぎます。明暗・色味の異なる2点を指定してください。");

            // Build the image-adaptive hue profile only when hue itself is not the flow axis.
            // If hue changes between endpoints, the explicit arc defined by both samples must be allowed;
            // a start-only profile would incorrectly reject the second endpoint and the colors near it.
            MaterialColorProfile profile = useH ? null : MaterialColorProfile.Build(source, startX, startY);
            int startIndex = startY * source.Width + startX;
            int endIndex = endY * source.Width + endX;

            Rgba32[] output = new Rgba32[source.Pixels.Length];
            int matched = 0;
            int partial = 0;
            int opaque = 0;

            for (int i = 0; i < source.Pixels.Length; i++)
            {
                Rgba32 pixel = source.Pixels[i];
                if (pixel.A < settings.TransparentAlphaThreshold)
                {
                    output[i] = pixel;
                    continue;
                }
                opaque++;
                if (i == startIndex)
                {
                    output[i] = new Rgba32(targetStartColor.R, targetStartColor.G, targetStartColor.B, pixel.A);
                    matched++;
                    continue;
                }
                if (i == endIndex)
                {
                    output[i] = new Rgba32(targetEndColor.R, targetEndColor.G, targetEndColor.B, pixel.A);
                    matched++;
                    continue;
                }

                Oklch current = ColorMath.ToOklch(pixel);
                float axisWeight = 1f;
                if (useL)
                {
                    float min = Math.Min(sourceStart.L, sourceEnd.L) - settings.TwoPointLightnessMargin;
                    float max = Math.Max(sourceStart.L, sourceEnd.L) + settings.TwoPointLightnessMargin;
                    axisWeight *= RangeWeight(current.L, min, max, 0.02f);
                }

                float minimumSourceChroma = Math.Min(sourceStart.C, sourceEnd.C);
                float maximumSourceChroma = Math.Max(sourceStart.C, sourceEnd.C);
                if (useC)
                {
                    // The chroma margin is relative to the selected material so a nearly neutral pixel
                    // cannot enter a colorful flow solely because the user selected a very dark endpoint.
                    float adaptiveMargin = Math.Min(settings.TwoPointChromaMargin, Math.Max(0.006f, minimumSourceChroma * 0.35f));
                    float min = Math.Max(0f, minimumSourceChroma - adaptiveMargin);
                    float max = maximumSourceChroma + settings.TwoPointChromaMargin;
                    axisWeight *= RangeWeight(current.C, min, max, 0.01f);
                }
                else if (maximumSourceChroma >= 0.012f)
                {
                    // Independent neutral guard for a mostly constant-chroma flow.
                    float materialFloor = minimumSourceChroma * 0.24f;
                    float low = Math.Max(0.006f, materialFloor * 0.45f);
                    float high = Math.Max(0.014f, materialFloor);
                    axisWeight *= ColorMath.SmoothStep(low, high, current.C);
                }

                if (useH)
                {
                    // Both endpoints define the allowed hue arc. No start-only hue profile is used here.
                    axisWeight *= HueArcRangeWeight(current.H, sourceStart.H, deltaH, settings.TwoPointHueMarginDegrees);
                }
                else
                {
                    // If hue is not a flow axis, use the texture's lightness-conditioned material hue profile.
                    float profileHue, tolerance, medianC, minC, maxC;
                    profile.GetAtLightness(current.L, out profileHue, out tolerance, out medianC, out minC, out maxC);
                    float hueLimit = Math.Max(tolerance, settings.TwoPointHueMarginDegrees);
                    float hueWeight = 1f - ColorMath.SmoothStep(hueLimit, hueLimit + 5f, ColorMath.HueDistance(profileHue, current.H));
                    axisWeight *= hueWeight;
                }

                float weight = ColorMath.Clamp01(axisWeight);
                if (weight <= MinimumApplyWeight)
                {
                    output[i] = pixel;
                    continue;
                }

                float t = DetermineProgress(current, sourceStart, deltaL, deltaC, deltaH, useL, useC, useH);
                Oklch expectedSource = ColorMath.Lerp(sourceStart, sourceEnd, t);
                Oklch expectedTarget = ColorMath.Lerp(targetStart, targetEnd, t);
                float lightnessResidual = (current.L - expectedSource.L) * ColorMath.Clamp01(settings.ShadingRetention);
                float hueResidual = ColorMath.SignedHueDelta(expectedSource.H, current.H) * ColorMath.Clamp01(settings.HueVariationRetention);
                float chromaRatio = current.C / Math.Max(0.015f, expectedSource.C);
                chromaRatio = ColorMath.Clamp(chromaRatio, 0.72f, 1.55f);
                Oklch changed = new Oklch(
                    expectedTarget.L + lightnessResidual,
                    expectedTarget.C * (1f + (chromaRatio - 1f) * ColorMath.Clamp01(settings.ChromaVariationRetention)),
                    expectedTarget.H + hueResidual);

                Oklab blended = ColorMath.Blend(ColorMath.ToOklab(current), ColorMath.ToOklab(changed), weight);
                output[i] = ColorMath.ToSrgb(ColorMath.ToOklch(blended), pixel.A);
                if (weight >= 0.999f) matched++;
                else partial++;
            }

            return new RecolorResult(new TexturePixels(source.Width, source.Height, output, true), matched, partial, opaque);
        }

        private static float DetermineProgress(Oklch pixel, Oklch start, float deltaL, float deltaC, float deltaH, bool useL, bool useC, bool useH)
        {
            float weightedProgress = 0f;
            float totalWeight = 0f;
            if (useL)
            {
                float weight = Math.Abs(deltaL) / 0.22f;
                weightedProgress += ColorMath.Clamp01((pixel.L - start.L) / deltaL) * weight;
                totalWeight += weight;
            }
            if (useC)
            {
                float weight = Math.Abs(deltaC) / 0.12f;
                weightedProgress += ColorMath.Clamp01((pixel.C - start.C) / deltaC) * weight;
                totalWeight += weight;
            }
            if (useH)
            {
                float weight = Math.Abs(deltaH) / 70f;
                weightedProgress += ColorMath.Clamp01(ColorMath.SignedHueDelta(start.H, pixel.H) / deltaH) * weight;
                totalWeight += weight;
            }
            return totalWeight <= 0.0001f ? 0f : ColorMath.Clamp01(weightedProgress / totalWeight);
        }

        private static float RangeWeight(float value, float min, float max, float softness)
        {
            if (value < min) return ColorMath.SmoothStep(min - softness, min, value);
            if (value > max) return 1f - ColorMath.SmoothStep(max, max + softness, value);
            return 1f;
        }

        private static float HueArcRangeWeight(float hue, float startHue, float signedDelta, float marginDegrees)
        {
            float progress = ColorMath.SignedHueDelta(startHue, hue) / signedDelta;
            float margin = marginDegrees / Math.Max(5f, Math.Abs(signedDelta));
            if (progress < 0f) return ColorMath.SmoothStep(-margin, 0f, progress);
            if (progress > 1f) return 1f - ColorMath.SmoothStep(1f, 1f + margin, progress);
            return 1f;
        }
    }
}
