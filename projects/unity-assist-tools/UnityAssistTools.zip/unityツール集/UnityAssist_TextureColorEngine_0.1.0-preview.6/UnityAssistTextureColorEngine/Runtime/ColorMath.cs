using System;

namespace UnityAssist.TextureColorEngine
{
    /// <summary>
    /// Color conversion utilities. Input/output bytes are sRGB; all calculations use linear RGB and OKLab/OKLCH.
    /// Gamut mapping reduces chroma while preserving lightness and hue instead of clipping RGB channels independently.
    /// </summary>
    public static class ColorMath
    {
        private static readonly float[] SrgbToLinearLookup = CreateSrgbToLinearLookup();
        private static readonly byte[] LinearToSrgbLookup = CreateLinearToSrgbLookup();

        public static float Clamp01(float value)
        {
            if (value < 0f) return 0f;
            if (value > 1f) return 1f;
            return value;
        }

        public static float Clamp(float value, float min, float max)
        {
            if (value < min) return min;
            if (value > max) return max;
            return value;
        }

        public static float NormalizeHue(float hue)
        {
            hue %= 360f;
            return hue < 0f ? hue + 360f : hue;
        }

        public static float SignedHueDelta(float from, float to)
        {
            float delta = NormalizeHue(to) - NormalizeHue(from);
            if (delta > 180f) delta -= 360f;
            if (delta < -180f) delta += 360f;
            return delta;
        }

        public static float HueDistance(float a, float b)
        {
            return Math.Abs(SignedHueDelta(a, b));
        }

        public static float SmoothStep(float edge0, float edge1, float value)
        {
            if (edge1 <= edge0) return value >= edge1 ? 1f : 0f;
            float t = Clamp01((value - edge0) / (edge1 - edge0));
            return t * t * (3f - 2f * t);
        }

        public static Oklab ToOklab(Rgba32 color)
        {
            float r = SrgbToLinearLookup[color.R];
            float g = SrgbToLinearLookup[color.G];
            float b = SrgbToLinearLookup[color.B];

            float l = 0.4122214708f * r + 0.5363325363f * g + 0.0514459929f * b;
            float m = 0.2119034982f * r + 0.6806995451f * g + 0.1073969566f * b;
            float s = 0.0883024619f * r + 0.2817188376f * g + 0.6299787005f * b;

            float lRoot = CubeRoot(l);
            float mRoot = CubeRoot(m);
            float sRoot = CubeRoot(s);

            return new Oklab(
                0.2104542553f * lRoot + 0.7936177850f * mRoot - 0.0040720468f * sRoot,
                1.9779984951f * lRoot - 2.4285922050f * mRoot + 0.4505937099f * sRoot,
                0.0259040371f * lRoot + 0.7827717662f * mRoot - 0.8086757660f * sRoot);
        }

        public static Oklch ToOklch(Rgba32 color)
        {
            return ToOklch(ToOklab(color));
        }

        public static Oklch ToOklch(Oklab lab)
        {
            float chroma = (float)Math.Sqrt(lab.A * lab.A + lab.B * lab.B);
            float hue = chroma < 0.000001f ? 0f : (float)(Math.Atan2(lab.B, lab.A) * 180.0 / Math.PI);
            return new Oklch(lab.L, chroma, hue);
        }

        public static Oklab ToOklab(Oklch lch)
        {
            double radians = lch.H * Math.PI / 180.0;
            return new Oklab(lch.L, (float)(lch.C * Math.Cos(radians)), (float)(lch.C * Math.Sin(radians)));
        }

        public static Rgba32 ToSrgb(Oklch desired, byte alpha)
        {
            // Binary-search chroma if the requested OKLCH color is outside the sRGB gamut.
            float low = 0f;
            float high = desired.C;
            float r, g, b;
            if (TryOklabToLinearRgb(ToOklab(desired), out r, out g, out b) && IsInGamut(r, g, b))
                return LinearRgbToSrgb(r, g, b, alpha);

            for (int i = 0; i < 14; i++)
            {
                float mid = (low + high) * 0.5f;
                Oklch test = new Oklch(desired.L, mid, desired.H);
                if (TryOklabToLinearRgb(ToOklab(test), out r, out g, out b) && IsInGamut(r, g, b))
                    low = mid;
                else
                    high = mid;
            }

            Oklch mapped = new Oklch(desired.L, low, desired.H);
            TryOklabToLinearRgb(ToOklab(mapped), out r, out g, out b);
            return LinearRgbToSrgb(r, g, b, alpha);
        }

        public static Oklch Lerp(Oklch a, Oklch b, float t)
        {
            t = Clamp01(t);
            float hue = NormalizeHue(a.H + SignedHueDelta(a.H, b.H) * t);
            return new Oklch(
                a.L + (b.L - a.L) * t,
                a.C + (b.C - a.C) * t,
                hue);
        }

        public static Oklab Blend(Oklab a, Oklab b, float t)
        {
            return Oklab.Lerp(a, b, t);
        }

        private static float SrgbToLinear(float value)
        {
            return value <= 0.04045f ? value / 12.92f : (float)Math.Pow((value + 0.055f) / 1.055f, 2.4f);
        }

        private static float LinearToSrgb(float value)
        {
            value = Clamp01(value);
            return value <= 0.0031308f ? value * 12.92f : 1.055f * (float)Math.Pow(value, 1.0 / 2.4) - 0.055f;
        }

        private static float[] CreateSrgbToLinearLookup()
        {
            float[] values = new float[256];
            for (int i = 0; i < values.Length; i++) values[i] = SrgbToLinear(i / 255f);
            return values;
        }

        private static byte[] CreateLinearToSrgbLookup()
        {
            const int size = 4096;
            byte[] values = new byte[size + 1];
            for (int i = 0; i <= size; i++)
                values[i] = (byte)Math.Round(LinearToSrgb(i / (float)size) * 255f);
            return values;
        }

        private static float CubeRoot(float value)
        {
            return value < 0f ? -(float)Math.Pow(-value, 1.0 / 3.0) : (float)Math.Pow(value, 1.0 / 3.0);
        }

        private static bool TryOklabToLinearRgb(Oklab lab, out float r, out float g, out float b)
        {
            float l = lab.L + 0.3963377774f * lab.A + 0.2158037573f * lab.B;
            float m = lab.L - 0.1055613458f * lab.A - 0.0638541728f * lab.B;
            float s = lab.L - 0.0894841775f * lab.A - 1.2914855480f * lab.B;
            l = l * l * l;
            m = m * m * m;
            s = s * s * s;
            r = 4.0767416621f * l - 3.3077115913f * m + 0.2309699292f * s;
            g = -1.2684380046f * l + 2.6097574011f * m - 0.3413193965f * s;
            b = -0.0041960863f * l - 0.7034186147f * m + 1.7076147010f * s;
            return !float.IsNaN(r) && !float.IsNaN(g) && !float.IsNaN(b) && !float.IsInfinity(r) && !float.IsInfinity(g) && !float.IsInfinity(b);
        }

        private static bool IsInGamut(float r, float g, float b)
        {
            const float epsilon = 0.00001f;
            return r >= -epsilon && r <= 1f + epsilon &&
                   g >= -epsilon && g <= 1f + epsilon &&
                   b >= -epsilon && b <= 1f + epsilon;
        }

        private static Rgba32 LinearRgbToSrgb(float r, float g, float b, byte alpha)
        {
            byte red = LinearToSrgbLookup[(int)Math.Round(Clamp01(r) * 4096f)];
            byte green = LinearToSrgbLookup[(int)Math.Round(Clamp01(g) * 4096f)];
            byte blue = LinearToSrgbLookup[(int)Math.Round(Clamp01(b) * 4096f)];
            return new Rgba32(red, green, blue, alpha);
        }
    }
}
