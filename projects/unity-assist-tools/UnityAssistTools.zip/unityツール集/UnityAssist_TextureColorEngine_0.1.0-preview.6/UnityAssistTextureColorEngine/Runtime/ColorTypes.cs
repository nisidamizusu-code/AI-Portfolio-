using System;

namespace UnityAssist.TextureColorEngine
{
    /// <summary>Unassociated RGBA8 pixel in sRGB byte encoding.</summary>
    public struct Rgba32
    {
        public byte R;
        public byte G;
        public byte B;
        public byte A;

        public Rgba32(byte r, byte g, byte b, byte a)
        {
            R = r; G = g; B = b; A = a;
        }

        public static Rgba32 Lerp(Rgba32 a, Rgba32 b, float t)
        {
            t = ColorMath.Clamp01(t);
            return new Rgba32(
                (byte)Math.Round(a.R + (b.R - a.R) * t),
                (byte)Math.Round(a.G + (b.G - a.G) * t),
                (byte)Math.Round(a.B + (b.B - a.B) * t),
                a.A);
        }
    }

    /// <summary>OKLab coordinates. L is approximately 0..1; a/b are signed.</summary>
    public struct Oklab
    {
        public float L;
        public float A;
        public float B;

        public Oklab(float l, float a, float b)
        {
            L = l; A = a; B = b;
        }

        public static Oklab Lerp(Oklab a, Oklab b, float t)
        {
            t = ColorMath.Clamp01(t);
            return new Oklab(
                a.L + (b.L - a.L) * t,
                a.A + (b.A - a.A) * t,
                a.B + (b.B - a.B) * t);
        }
    }

    /// <summary>OKLCH coordinates: L 0..1, C >= 0, H 0..360 degrees.</summary>
    public struct Oklch
    {
        public float L;
        public float C;
        public float H;

        public Oklch(float l, float c, float h)
        {
            L = ColorMath.Clamp01(l);
            C = Math.Max(0f, c);
            H = ColorMath.NormalizeHue(h);
        }
    }

    /// <summary>Top-left or bottom-left pixel ordering is owned by the adapter; the engine treats this as a flat row-major buffer.</summary>
    public sealed class TexturePixels
    {
        public int Width { get; private set; }
        public int Height { get; private set; }
        public Rgba32[] Pixels { get; private set; }

        public TexturePixels(int width, int height, Rgba32[] pixels, bool takeOwnership)
        {
            if (width <= 0 || height <= 0) throw new ArgumentOutOfRangeException("Texture dimensions must be positive.");
            if (pixels == null) throw new ArgumentNullException(nameof(pixels));
            if ((long)width * height != pixels.Length) throw new ArgumentException("Pixel count does not match texture dimensions.");
            Width = width;
            Height = height;
            Pixels = takeOwnership ? pixels : (Rgba32[])pixels.Clone();
        }

        public TexturePixels Clone()
        {
            return new TexturePixels(Width, Height, Pixels, false);
        }
    }

    public enum RecolorMode
    {
        SingleColor = 0,
        TwoPointFlow = 1
    }

    public sealed class RecolorResult
    {
        public TexturePixels Image { get; private set; }
        public int MatchedPixels { get; private set; }
        public int PartiallyMatchedPixels { get; private set; }
        public int OpaquePixels { get; private set; }

        public RecolorResult(TexturePixels image, int matchedPixels, int partialPixels, int opaquePixels)
        {
            Image = image;
            MatchedPixels = matchedPixels;
            PartiallyMatchedPixels = partialPixels;
            OpaquePixels = opaquePixels;
        }
    }
}
