using System;

namespace UnityAssist.TextureColorEngine
{
    /// <summary>
    /// Image-adaptive profile built from a clicked pixel and the texture's color distribution.
    /// It models a hue/chroma family per lightness band; it does not classify pixels by Euclidean color distance.
    /// </summary>
    public sealed class MaterialColorProfile
    {
        public const int LightnessBinCount = 16;
        private readonly float[] hueCenters;
        private readonly float[] hueTolerances;
        private readonly float[] medianChromas;
        private readonly float[] minimumChromas;
        private readonly float[] maximumChromas;

        public Oklch SampleColor { get; private set; }
        public bool IsNeutralMaterial { get; private set; }

        // Scalar interpolation for the per-lightness profile arrays.
        // This is intentionally local to the profile; ColorMath.Lerp handles Oklch values.
        private static float Lerp(float a, float b, float t)
        {
            return a + (b - a) * t;
        }

        internal MaterialColorProfile(
            Oklch sample,
            bool isNeutral,
            float[] hues,
            float[] tolerances,
            float[] medians,
            float[] minimums,
            float[] maximums)
        {
            SampleColor = sample;
            IsNeutralMaterial = isNeutral;
            hueCenters = hues;
            hueTolerances = tolerances;
            medianChromas = medians;
            minimumChromas = minimums;
            maximumChromas = maximums;
        }

        public void GetAtLightness(float lightness, out float hue, out float hueTolerance, out float medianChroma, out float minChroma, out float maxChroma)
        {
            float position = ColorMath.Clamp01(lightness) * (LightnessBinCount - 1);
            int lower = (int)Math.Floor(position);
            int upper = Math.Min(LightnessBinCount - 1, lower + 1);
            float t = position - lower;

            hue = ColorMath.NormalizeHue(hueCenters[lower] + ColorMath.SignedHueDelta(hueCenters[lower], hueCenters[upper]) * t);
            hueTolerance = Lerp(hueTolerances[lower], hueTolerances[upper], t);
            medianChroma = Lerp(medianChromas[lower], medianChromas[upper], t);
            minChroma = Lerp(minimumChromas[lower], minimumChromas[upper], t);
            maxChroma = Lerp(maximumChromas[lower], maximumChromas[upper], t);
        }

        public float GetSelectionWeight(Oklch color)
        {
            if (IsNeutralMaterial)
            {
                // Neutral colors have no stable hue. Keep this path narrow in lightness and chroma.
                float lightnessDelta = Math.Abs(color.L - SampleColor.L);
                float lWeight = 1f - ColorMath.SmoothStep(0.075f, 0.14f, lightnessDelta);
                float cWeight = 1f - ColorMath.SmoothStep(0.035f, 0.055f, color.C);
                return lWeight * cWeight;
            }

            float centerHue, tolerance, medianC, minC, maxC;
            GetAtLightness(color.L, out centerHue, out tolerance, out medianC, out minC, out maxC);

            float hueDifference = ColorMath.HueDistance(centerHue, color.H);
            float hueWeight = 1f - ColorMath.SmoothStep(tolerance, tolerance + 4f, hueDifference);

            // Chroma gates are independent from hue and lightness. This prevents neutral black/gray
            // from entering a colorful material selection just because its lightness is similar.
            float chromaReliability = ColorMath.SmoothStep(0.006f, 0.016f, color.C);
            float chromaLowWeight = ColorMath.SmoothStep(minC * 0.62f, minC * 1.18f, color.C);
            float chromaHighWeight = 1f - ColorMath.SmoothStep(maxC, maxC * 1.22f + 0.012f, color.C);
            return ColorMath.Clamp01(hueWeight * chromaReliability * chromaLowWeight * chromaHighWeight);
        }

        internal static MaterialColorProfile Build(TexturePixels image, int sampleX, int sampleY)
        {
            if (image == null) throw new ArgumentNullException(nameof(image));
            if (sampleX < 0 || sampleY < 0 || sampleX >= image.Width || sampleY >= image.Height)
                throw new ArgumentOutOfRangeException("Sample coordinates are outside the texture.");

            Rgba32 samplePixel = image.Pixels[sampleY * image.Width + sampleX];
            if (samplePixel.A < 16) throw new InvalidOperationException("スポイト位置が透明ピクセルです。表示されている色を選択してください。");
            Oklch sample = ColorMath.ToOklch(samplePixel);
            bool neutral = sample.C < 0.008f;

            float[] hueCenters = new float[LightnessBinCount];
            float[] hueTolerances = new float[LightnessBinCount];
            float[] medianChromas = new float[LightnessBinCount];
            float[] minimumChromas = new float[LightnessBinCount];
            float[] maximumChromas = new float[LightnessBinCount];

            if (neutral)
            {
                for (int i = 0; i < LightnessBinCount; i++)
                {
                    hueCenters[i] = sample.H;
                    hueTolerances[i] = 180f;
                    medianChromas[i] = 0.012f;
                    minimumChromas[i] = 0f;
                    maximumChromas[i] = 0.04f;
                }
                return new MaterialColorProfile(sample, true, hueCenters, hueTolerances, medianChromas, minimumChromas, maximumChromas);
            }

            const int hueBins = 360;
            const int chromaBins = 128;
            const float searchHueWindow = 52f;
            const float profileHueWindow = 18f;
            float[,] hueHistogram = new float[LightnessBinCount, hueBins];
            int[] binCounts = new int[LightnessBinCount];

            // Pass 1: build a lightness-conditioned hue histogram around the selected hue family.
            for (int i = 0; i < image.Pixels.Length; i++)
            {
                Rgba32 px = image.Pixels[i];
                if (px.A < 16) continue;
                Oklch color = ColorMath.ToOklch(px);
                if (color.C < 0.012f || ColorMath.HueDistance(sample.H, color.H) > searchHueWindow) continue;
                int lBin = GetLightnessBin(color.L);
                int hBin = ((int)Math.Round(color.H)) % hueBins;
                hueHistogram[lBin, hBin] += 1f + Math.Min(color.C, 0.25f);
                binCounts[lBin]++;
            }

            bool[] populated = new bool[LightnessBinCount];
            for (int lBin = 0; lBin < LightnessBinCount; lBin++)
            {
                if (binCounts[lBin] == 0)
                {
                    hueCenters[lBin] = sample.H;
                    hueTolerances[lBin] = 12f;
                    continue;
                }

                populated[lBin] = true;
                int bestHue = (int)Math.Round(sample.H) % hueBins;
                float bestScore = -1f;
                for (int h = 0; h < hueBins; h++)
                {
                    float seedDistance = ColorMath.HueDistance(sample.H, h);
                    if (seedDistance > searchHueWindow) continue;
                    float score = 0f;
                    for (int offset = -3; offset <= 3; offset++)
                    {
                        int index = (h + offset + hueBins) % hueBins;
                        score += hueHistogram[lBin, index] * (4 - Math.Abs(offset));
                    }
                    // Prefer the mode closest to the picked hue when histogram peaks are similar.
                    score /= 1f + seedDistance * 0.018f;
                    if (score > bestScore)
                    {
                        bestScore = score;
                        bestHue = h;
                    }
                }
                hueCenters[lBin] = bestHue;
            }

            // Fill empty lightness bands from the nearest observed band, preserving circular hue interpolation.
            for (int lBin = 0; lBin < LightnessBinCount; lBin++)
            {
                if (populated[lBin]) continue;
                int nearest = -1;
                int nearestDistance = int.MaxValue;
                for (int j = 0; j < LightnessBinCount; j++)
                {
                    if (!populated[j]) continue;
                    int distance = Math.Abs(j - lBin);
                    if (distance < nearestDistance) { nearest = j; nearestDistance = distance; }
                }
                hueCenters[lBin] = nearest >= 0 ? hueCenters[nearest] : sample.H;
                hueTolerances[lBin] = 12f;
            }

            // Pass 2: one full scan for all bands (avoid rescanning the image once per lightness band).
            int[,] chromaHistograms = new int[LightnessBinCount, chromaBins];
            int[,] hueSpreadHistograms = new int[LightnessBinCount, 91];
            int[] profileCounts = new int[LightnessBinCount];
            for (int i = 0; i < image.Pixels.Length; i++)
            {
                Rgba32 px = image.Pixels[i];
                if (px.A < 16) continue;
                Oklch color = ColorMath.ToOklch(px);
                // Keep low-chroma dark shades in the material's chroma profile, but exclude near-neutral noise.
                if (color.C < 0.006f) continue;
                int lBin = GetLightnessBin(color.L);
                if (!populated[lBin]) continue;
                float hDiff = ColorMath.HueDistance(hueCenters[lBin], color.H);
                if (hDiff > profileHueWindow) continue;
                int cBin = (int)ColorMath.Clamp(color.C / 0.004f, 0f, chromaBins - 1);
                int hBin = (int)ColorMath.Clamp((float)Math.Round(hDiff), 0f, 90f);
                chromaHistograms[lBin, cBin]++;
                hueSpreadHistograms[lBin, hBin]++;
                profileCounts[lBin]++;
            }

            for (int lBin = 0; lBin < LightnessBinCount; lBin++)
            {
                if (!populated[lBin]) continue;
                int count = profileCounts[lBin];
                if (count == 0)
                {
                    medianChromas[lBin] = Math.Max(sample.C, 0.02f);
                    minimumChromas[lBin] = medianChromas[lBin] * 0.22f;
                    maximumChromas[lBin] = medianChromas[lBin] * 2.2f + 0.03f;
                    hueTolerances[lBin] = 12f;
                    continue;
                }

                float medianC = HistogramPercentile(chromaHistograms, lBin, chromaBins, count, 0.50f) * 0.004f;
                float p10C = HistogramPercentile(chromaHistograms, lBin, chromaBins, count, 0.10f) * 0.004f;
                float p95C = HistogramPercentile(chromaHistograms, lBin, chromaBins, count, 0.95f) * 0.004f;
                float p80Hue = HistogramPercentile(hueSpreadHistograms, lBin, 91, count, 0.80f);
                medianChromas[lBin] = Math.Max(0.008f, medianC);
                minimumChromas[lBin] = Math.Max(0.006f, Math.Max(medianC * 0.22f, p10C * 0.65f));
                maximumChromas[lBin] = Math.Max(medianC * 1.8f, p95C * 1.25f) + 0.018f;
                hueTolerances[lBin] = ColorMath.Clamp(7.5f + p80Hue * 0.35f, 8f, 20f);
            }

            // Empty lightness bands must inherit the nearest populated band's full profile.
            // Leaving chroma statistics at zero makes dark/bright shades behave unpredictably.
            for (int lBin = 0; lBin < LightnessBinCount; lBin++)
            {
                if (populated[lBin]) continue;
                int nearest = FindNearestPopulated(populated, lBin);
                if (nearest < 0) continue;
                hueCenters[lBin] = hueCenters[nearest];
                hueTolerances[lBin] = hueTolerances[nearest];
                medianChromas[lBin] = medianChromas[nearest];
                minimumChromas[lBin] = minimumChromas[nearest];
                maximumChromas[lBin] = maximumChromas[nearest];
            }

            return new MaterialColorProfile(sample, false, hueCenters, hueTolerances, medianChromas, minimumChromas, maximumChromas);
        }

        private static int GetLightnessBin(float lightness)
        {
            return (int)ColorMath.Clamp((float)Math.Floor(ColorMath.Clamp01(lightness) * LightnessBinCount), 0f, LightnessBinCount - 1);
        }

        private static int FindNearestPopulated(bool[] populated, int from)
        {
            for (int radius = 1; radius < LightnessBinCount; radius++)
            {
                int left = from - radius;
                int right = from + radius;
                if (left >= 0 && populated[left]) return left;
                if (right < LightnessBinCount && populated[right]) return right;
            }
            return -1;
        }

        private static int HistogramPercentile(int[,] histogram, int row, int length, int total, float percentile)
        {
            int target = Math.Max(1, (int)Math.Ceiling(total * percentile));
            int accumulated = 0;
            for (int i = 0; i < length; i++)
            {
                accumulated += histogram[row, i];
                if (accumulated >= target) return i;
            }
            return length - 1;
        }
    }
}
