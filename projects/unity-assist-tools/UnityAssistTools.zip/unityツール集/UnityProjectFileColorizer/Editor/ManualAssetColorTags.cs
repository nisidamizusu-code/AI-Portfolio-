using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace UnityAssist.ProjectFileColorizer
{
    /// <summary>
    /// Stores user-assigned asset colors separately from the legacy extension-based colors.
    /// The asset itself is never modified; tags are keyed by Unity asset GUID.
    /// </summary>
    [InitializeOnLoad]
    internal static class ManualAssetColorTags
    {
        private const int CurrentDataVersion = 1;
        private const string SettingsFileName = "UnityAssist.ProjectFileColorizer.ManualTags.json";
        private static readonly Dictionary<string, Color> ColorsByGuid = new Dictionary<string, Color>();
        private static bool loaded;
        private static bool loadFailed;
        private static string lastError;

        internal static event Action TagsChanged;

        [Serializable]
        private sealed class SettingsData
        {
            public int version = CurrentDataVersion;
            public List<SettingsEntry> entries = new List<SettingsEntry>();
        }

        [Serializable]
        private sealed class SettingsEntry
        {
            public string guid;
            public Color color;
        }

        internal struct PaletteEntry
        {
            internal readonly string Name;
            internal readonly Color Color;

            internal PaletteEntry(string name, Color color)
            {
                Name = name;
                Color = color;
            }
        }

        private static readonly PaletteEntry[] Palette =
        {
            new PaletteEntry("ターコイズ", new Color32(47, 188, 178, 255)),
            new PaletteEntry("ブルー", new Color32(63, 136, 216, 255)),
            new PaletteEntry("グリーン", new Color32(85, 175, 112, 255)),
            new PaletteEntry("イエロー", new Color32(230, 190, 70, 255)),
            new PaletteEntry("オレンジ", new Color32(225, 138, 64, 255)),
            new PaletteEntry("レッド", new Color32(213, 91, 91, 255)),
            new PaletteEntry("パープル", new Color32(153, 113, 202, 255)),
            new PaletteEntry("グレー", new Color32(135, 145, 155, 255))
        };

        static ManualAssetColorTags()
        {
            Load();
        }

        internal static string LastError
        {
            get
            {
                EnsureLoaded();
                return lastError;
            }
        }

        internal static bool HasLoadError
        {
            get
            {
                EnsureLoaded();
                return loadFailed;
            }
        }

        internal static PaletteEntry[] GetPalette()
        {
            var copy = new PaletteEntry[Palette.Length];
            Array.Copy(Palette, copy, Palette.Length);
            return copy;
        }

        internal static bool TryGetColor(string guid, out Color color)
        {
            EnsureLoaded();
            if (string.IsNullOrEmpty(guid))
            {
                color = Color.white;
                return false;
            }
            return ColorsByGuid.TryGetValue(guid, out color);
        }

        internal static Dictionary<string, Color> GetSnapshot()
        {
            EnsureLoaded();
            return new Dictionary<string, Color>(ColorsByGuid);
        }

        internal static string GetColorName(Color color)
        {
            var value = (Color32)color;
            for (var i = 0; i < Palette.Length; i++)
            {
                if (ToColorKey(Palette[i].Color) == ToColorKey(value))
                {
                    return Palette[i].Name;
                }
            }

            return "カスタムカラー #" + ColorUtility.ToHtmlStringRGBA(value);
        }

        internal static string ToColorKey(Color color)
        {
            return ColorUtility.ToHtmlStringRGBA((Color32)color);
        }

        internal static string[] GetSelectedGuids()
        {
            // Selection.assetGUIDs is the Project-window-specific API and also handles
            // folders selected in the first column of the two-column Project Browser.
            var selectedGuids = Selection.assetGUIDs;
            if (selectedGuids == null || selectedGuids.Length == 0)
            {
                return new string[0];
            }

            var guids = new List<string>(selectedGuids.Length);
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var guid in selectedGuids)
            {
                if (!string.IsNullOrEmpty(guid) && seen.Add(guid))
                {
                    guids.Add(guid);
                }
            }

            return guids.ToArray();
        }

        internal static bool SetColors(string[] guids, Color color)
        {
            EnsureLoaded();
            if (loadFailed)
            {
                lastError = "手動カラー設定ファイルを読み込めないため、上書きを防止しました。設定ファイルを確認してください。";
                Debug.LogError("[Unity Assist Tools] " + lastError);
                return false;
            }

            if (guids == null || guids.Length == 0)
            {
                lastError = "色を設定するアセットが選択されていません。";
                return false;
            }

            var normalizedColor = NormalizeColor(color);
            var updated = new Dictionary<string, Color>(ColorsByGuid);
            foreach (var guid in guids)
            {
                if (!string.IsNullOrEmpty(guid))
                {
                    updated[guid] = normalizedColor;
                }
            }

            return Save(updated);
        }

        internal static bool RemoveColors(string[] guids)
        {
            EnsureLoaded();
            if (loadFailed)
            {
                lastError = "手動カラー設定ファイルを読み込めないため、変更を中止しました。設定ファイルを確認してください。";
                Debug.LogError("[Unity Assist Tools] " + lastError);
                return false;
            }

            if (guids == null || guids.Length == 0)
            {
                return false;
            }

            var updated = new Dictionary<string, Color>(ColorsByGuid);
            var changed = false;
            foreach (var guid in guids)
            {
                if (!string.IsNullOrEmpty(guid))
                {
                    changed |= updated.Remove(guid);
                }
            }

            return !changed || Save(updated);
        }

        internal static bool RemoveColor(string guid)
        {
            return RemoveColors(new[] { guid });
        }

        internal static void OpenColorGroups()
        {
            EditorWindow.GetWindow<ManualAssetColorGroupsWindow>("Color Groups");
        }

        internal static void OpenCustomColorWindow()
        {
            var guids = GetSelectedGuids();
            if (guids.Length == 0)
            {
                Debug.LogWarning("[Unity Assist Tools] Projectウィンドウでアセットを選択してから実行してください。");
                return;
            }

            var window = EditorWindow.GetWindow<ManualAssetColorPickerWindow>(true, "カスタムカラー", true);
            window.SetTargets(guids);
            window.minSize = new Vector2(300f, 118f);
        }

        private static void EnsureLoaded()
        {
            if (!loaded)
            {
                Load();
            }
        }

        private static void Load()
        {
            loaded = true;
            loadFailed = false;
            lastError = null;
            ColorsByGuid.Clear();

            string path = null;
            string backupPath = null;
            try
            {
                path = GetSettingsPath();
                backupPath = path + ".backup";

                // If the Editor was interrupted between replacing files, recover the last known-good copy.
                if (!File.Exists(path) && File.Exists(backupPath))
                {
                    File.Copy(backupPath, path, true);
                }

                if (!File.Exists(path))
                {
                    return;
                }

                SettingsData data;
                try
                {
                    data = ReadSettings(path);
                }
                catch (Exception primaryException)
                {
                    if (!File.Exists(backupPath))
                    {
                        throw;
                    }

                    data = ReadSettings(backupPath);
                    File.Copy(backupPath, path, true);
                    Debug.LogWarning(
                        "[Unity Assist Tools] 手動カラー設定の破損を検出したため、バックアップから復旧しました。\n" +
                        primaryException.Message);
                }

                foreach (var entry in data.entries)
                {
                    if (entry == null || string.IsNullOrEmpty(entry.guid))
                    {
                        continue;
                    }

                    ColorsByGuid[entry.guid] = NormalizeColor(entry.color);
                }
            }
            catch (Exception exception)
            {
                loadFailed = true;
                lastError = "手動カラー設定を読み込めませんでした。既存ファイルを上書きしないよう、変更を停止しました。";
                Debug.LogError("[Unity Assist Tools] " + lastError + "\n" + exception);
            }
        }

        private static SettingsData ReadSettings(string path)
        {
            var json = File.ReadAllText(path, Encoding.UTF8);
            var data = JsonUtility.FromJson<SettingsData>(json);
            if (data == null || data.version != CurrentDataVersion || data.entries == null)
            {
                throw new InvalidDataException("設定ファイルの形式またはバージョンが不正です。");
            }

            return data;
        }

        private static bool SettingsMatch(SettingsData actual, SettingsData expected)
        {
            if (actual == null || expected == null || actual.entries == null || expected.entries == null ||
                actual.entries.Count != expected.entries.Count)
            {
                return false;
            }

            var actualByGuid = new Dictionary<string, Color>(StringComparer.OrdinalIgnoreCase);
            foreach (var entry in actual.entries)
            {
                if (entry == null || string.IsNullOrEmpty(entry.guid) || actualByGuid.ContainsKey(entry.guid))
                {
                    return false;
                }
                actualByGuid.Add(entry.guid, NormalizeColor(entry.color));
            }

            foreach (var entry in expected.entries)
            {
                if (entry == null || string.IsNullOrEmpty(entry.guid))
                {
                    return false;
                }

                Color actualColor;
                if (!actualByGuid.TryGetValue(entry.guid, out actualColor))
                {
                    return false;
                }

                var expectedColor = NormalizeColor(entry.color);
                if (!Mathf.Approximately(actualColor.r, expectedColor.r) ||
                    !Mathf.Approximately(actualColor.g, expectedColor.g) ||
                    !Mathf.Approximately(actualColor.b, expectedColor.b) ||
                    !Mathf.Approximately(actualColor.a, expectedColor.a))
                {
                    return false;
                }
            }

            return true;
        }

        private static bool Save(Dictionary<string, Color> updated)
        {
            string path = null;
            string temporaryPath = null;
            string backupPath = null;
            var hadOriginal = false;
            var backupReady = false;

            try
            {
                path = GetSettingsPath();
                temporaryPath = path + ".tmp";
                backupPath = path + ".backup";
                hadOriginal = File.Exists(path);

                var data = new SettingsData();
                foreach (var pair in updated)
                {
                    data.entries.Add(new SettingsEntry { guid = pair.Key, color = pair.Value });
                }
                data.entries.Sort((left, right) => string.CompareOrdinal(left.guid, right.guid));

                var directory = Path.GetDirectoryName(path);
                if (!string.IsNullOrEmpty(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                // Write and validate a temporary file before touching the current settings.
                File.WriteAllText(temporaryPath, JsonUtility.ToJson(data, true), new UTF8Encoding(false));
                var temporaryData = ReadSettings(temporaryPath);
                if (!SettingsMatch(temporaryData, data))
                {
                    throw new InvalidDataException("一時設定ファイルの検証に失敗しました。");
                }

                // Keep the last known-good settings so a failed replacement can be rolled back.
                if (hadOriginal)
                {
                    File.Copy(path, backupPath, true);
                    backupReady = true;
                }

                // FileUtil.ReplaceFile is used only when a destination already exists.
                // For the first save, copy the validated temporary file to a new destination.
                if (hadOriginal)
                {
                    FileUtil.ReplaceFile(temporaryPath, path);
                }
                else
                {
                    File.Copy(temporaryPath, path);
                }

                var savedData = ReadSettings(path);
                if (!SettingsMatch(savedData, data))
                {
                    throw new InvalidDataException("保存後の設定ファイル検証に失敗しました。");
                }

                if (!hadOriginal)
                {
                    try
                    {
                        File.Copy(path, backupPath, true);
                    }
                    catch (Exception backupException)
                    {
                        Debug.LogWarning("[Unity Assist Tools] 初回保存後のバックアップ作成に失敗しました。設定本体は保存されています。\n" + backupException.Message);
                    }
                }

                if (File.Exists(temporaryPath))
                {
                    try
                    {
                        File.Delete(temporaryPath);
                    }
                    catch
                    {
                        // A stale temporary file is harmless; the validated destination is already saved.
                    }
                }

                ColorsByGuid.Clear();
                foreach (var pair in updated)
                {
                    ColorsByGuid.Add(pair.Key, pair.Value);
                }

                lastError = null;
                EditorApplication.RepaintProjectWindow();
                if (TagsChanged != null)
                {
                    try
                    {
                        TagsChanged();
                    }
                    catch (Exception callbackException)
                    {
                        Debug.LogException(callbackException);
                    }
                }

                return true;
            }
            catch (Exception exception)
            {
                // Restore the previous file if replacement or post-write validation failed.
                try
                {
                    if (backupReady && !string.IsNullOrEmpty(backupPath) && File.Exists(backupPath))
                    {
                        File.Copy(backupPath, path, true);
                    }
                    else if (!hadOriginal && !string.IsNullOrEmpty(path) && File.Exists(path))
                    {
                        File.Delete(path);
                    }
                }
                catch (Exception restoreException)
                {
                    Debug.LogError("[Unity Assist Tools] 手動カラー設定の復旧にも失敗しました。バックアップを保持しています。\n" + restoreException);
                }

                if (!string.IsNullOrEmpty(temporaryPath) && File.Exists(temporaryPath))
                {
                    try
                    {
                        File.Delete(temporaryPath);
                    }
                    catch
                    {
                        // Keep the original and backup files even if temporary-file cleanup fails.
                    }
                }

                lastError = "手動カラー設定を保存できませんでした。既存設定を復元し、今回の変更を取り消しました。";
                Debug.LogError("[Unity Assist Tools] " + lastError + "\n" + exception);
                return false;
            }
        }

        private static string GetSettingsPath()
        {
            var projectRoot = Directory.GetParent(Application.dataPath);
            if (projectRoot == null)
            {
                throw new DirectoryNotFoundException("Unity project root could not be resolved.");
            }

            return Path.Combine(projectRoot.FullName, "ProjectSettings", SettingsFileName);
        }

        private static Color NormalizeColor(Color color)
        {
            if (float.IsNaN(color.r) || float.IsInfinity(color.r) ||
                float.IsNaN(color.g) || float.IsInfinity(color.g) ||
                float.IsNaN(color.b) || float.IsInfinity(color.b) ||
                float.IsNaN(color.a) || float.IsInfinity(color.a))
            {
                return Color.white;
            }

            return new Color(
                Mathf.Clamp01(color.r),
                Mathf.Clamp01(color.g),
                Mathf.Clamp01(color.b),
                1f);
        }

        [MenuItem("Assets/Unity Assist Tools/カラータグ/ターコイズ", false, 120)]
        private static void ApplyTurquoise() { ApplyPaletteColor(0); }

        [MenuItem("Assets/Unity Assist Tools/カラータグ/ブルー", false, 121)]
        private static void ApplyBlue() { ApplyPaletteColor(1); }

        [MenuItem("Assets/Unity Assist Tools/カラータグ/グリーン", false, 122)]
        private static void ApplyGreen() { ApplyPaletteColor(2); }

        [MenuItem("Assets/Unity Assist Tools/カラータグ/イエロー", false, 123)]
        private static void ApplyYellow() { ApplyPaletteColor(3); }

        [MenuItem("Assets/Unity Assist Tools/カラータグ/オレンジ", false, 124)]
        private static void ApplyOrange() { ApplyPaletteColor(4); }

        [MenuItem("Assets/Unity Assist Tools/カラータグ/レッド", false, 125)]
        private static void ApplyRed() { ApplyPaletteColor(5); }

        [MenuItem("Assets/Unity Assist Tools/カラータグ/パープル", false, 126)]
        private static void ApplyPurple() { ApplyPaletteColor(6); }

        [MenuItem("Assets/Unity Assist Tools/カラータグ/グレー", false, 127)]
        private static void ApplyGray() { ApplyPaletteColor(7); }

        [MenuItem("Assets/Unity Assist Tools/カラータグ/カスタムカラー...", false, 130)]
        private static void ApplyCustomColor() { OpenCustomColorWindow(); }

        [MenuItem("Assets/Unity Assist Tools/カラータグ/色を解除", false, 131)]
        private static void RemoveSelectedColor()
        {
            var guids = GetSelectedGuids();
            if (guids.Length == 0)
            {
                Debug.LogWarning("[Unity Assist Tools] Projectウィンドウでアセットを選択してから実行してください。");
                return;
            }
            RemoveColors(guids);
        }

        private static void ApplyPaletteColor(int index)
        {
            if (index < 0 || index >= Palette.Length)
            {
                return;
            }

            var guids = GetSelectedGuids();
            if (guids.Length == 0)
            {
                Debug.LogWarning("[Unity Assist Tools] Projectウィンドウでアセットを選択してから実行してください。");
                return;
            }

            SetColors(guids, Palette[index].Color);
        }
    }

    internal sealed class ManualAssetColorPickerWindow : EditorWindow
    {
        private string[] targetGuids = new string[0];
        private Color selectedColor = new Color32(47, 188, 178, 255);

        internal void SetTargets(string[] guids)
        {
            targetGuids = guids ?? new string[0];
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("選択中のアセットに設定する色", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("対象: " + targetGuids.Length + " アセット", EditorStyles.miniLabel);
            selectedColor = EditorGUILayout.ColorField(new GUIContent("カラー"), selectedColor, true, false, false);
            EditorGUILayout.Space();

            using (new EditorGUI.DisabledScope(targetGuids.Length == 0 || ManualAssetColorTags.HasLoadError))
            {
                if (GUILayout.Button("選択したアセットに適用"))
                {
                    if (ManualAssetColorTags.SetColors(targetGuids, selectedColor))
                    {
                        Close();
                    }
                }
            }

            if (!string.IsNullOrEmpty(ManualAssetColorTags.LastError))
            {
                EditorGUILayout.HelpBox(ManualAssetColorTags.LastError, MessageType.Error);
            }
        }
    }

    internal sealed class ManualAssetColorGroupsWindow : EditorWindow
    {
        private sealed class AssetEntry
        {
            internal string Guid;
            internal string Path;
        }

        private sealed class ColorGroup
        {
            internal string Key;
            internal string Name;
            internal Color Color;
            internal readonly List<AssetEntry> Assets = new List<AssetEntry>();
            internal readonly List<AssetEntry> FilteredAssets = new List<AssetEntry>();
            internal bool Expanded;
        }

        private readonly List<ColorGroup> groups = new List<ColorGroup>();
        private Vector2 scrollPosition;
        private string searchText = string.Empty;

        private void OnEnable()
        {
            ManualAssetColorTags.TagsChanged += RefreshGroups;
            EditorApplication.projectChanged += RefreshGroups;
            RefreshGroups();
        }

        private void OnDisable()
        {
            ManualAssetColorTags.TagsChanged -= RefreshGroups;
            EditorApplication.projectChanged -= RefreshGroups;
        }

        private void OnGUI()
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                GUILayout.Label("カラー別アセット", EditorStyles.toolbarButton);
                GUILayout.FlexibleSpace();
                if (GUILayout.Button("更新", EditorStyles.toolbarButton, GUILayout.Width(48f)))
                {
                    RefreshGroups();
                }
            }

            EditorGUI.BeginChangeCheck();
            var nextSearchText = EditorGUILayout.TextField("検索", searchText ?? string.Empty);
            if (EditorGUI.EndChangeCheck())
            {
                searchText = nextSearchText;
                RefreshFilteredAssets();
            }
            EditorGUILayout.HelpBox("色を付けたアセットをグループ別に表示します。実際のファイルやフォルダは移動しません。", MessageType.Info);

            if (ManualAssetColorTags.HasLoadError)
            {
                EditorGUILayout.HelpBox(ManualAssetColorTags.LastError, MessageType.Error);
                return;
            }
            if (!string.IsNullOrEmpty(ManualAssetColorTags.LastError))
            {
                EditorGUILayout.HelpBox(ManualAssetColorTags.LastError, MessageType.Error);
            }

            scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);
            var visibleGroupCount = 0;
            foreach (var group in groups)
            {
                var matchingAssets = group.FilteredAssets;
                if (matchingAssets.Count == 0)
                {
                    continue;
                }

                visibleGroupCount++;
                using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        var swatch = GUILayoutUtility.GetRect(16f, 16f, GUILayout.Width(16f), GUILayout.Height(16f));
                        EditorGUI.DrawRect(swatch, group.Color);
                        group.Expanded = EditorGUILayout.Foldout(
                            group.Expanded,
                            group.Name + "  (" + matchingAssets.Count + ")",
                            true);
                    }

                    if (group.Expanded || !string.IsNullOrEmpty(searchText))
                    {
                        foreach (var asset in matchingAssets)
                        {
                            using (new EditorGUILayout.HorizontalScope())
                            {
                                GUILayout.Label(Path.GetFileName(asset.Path), GUILayout.Width(130f));
                                GUILayout.Label(asset.Path, EditorStyles.miniLabel, GUILayout.ExpandWidth(true));
                                if (GUILayout.Button("表示", GUILayout.Width(48f)))
                                {
                                    SelectAndPing(asset.Path);
                                }
                                if (GUILayout.Button("解除", GUILayout.Width(48f)))
                                {
                                    ManualAssetColorTags.RemoveColor(asset.Guid);
                                    GUIUtility.ExitGUI();
                                }
                            }
                        }
                    }
                }
            }

            if (visibleGroupCount == 0)
            {
                EditorGUILayout.HelpBox(
                    string.IsNullOrEmpty(searchText)
                        ? "手動カラーが設定されたアセットはありません。Projectウィンドウで右クリックして色を設定してください。"
                        : "検索条件に一致するアセットはありません。",
                    MessageType.None);
            }

            EditorGUILayout.EndScrollView();
        }

        private void RefreshFilteredAssets()
        {
            var query = (searchText ?? string.Empty).Trim();
            foreach (var group in groups)
            {
                group.FilteredAssets.Clear();
                foreach (var asset in group.Assets)
                {
                    if (query.Length == 0 ||
                        asset.Path.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0 ||
                        group.Name.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        group.FilteredAssets.Add(asset);
                    }
                }
            }
        }

        private void RefreshGroups()
        {
            groups.Clear();
            var snapshot = ManualAssetColorTags.GetSnapshot();
            var groupsByColor = new Dictionary<string, ColorGroup>();

            foreach (var pair in snapshot)
            {
                var path = AssetDatabase.GUIDToAssetPath(pair.Key);
                if (string.IsNullOrEmpty(path))
                {
                    continue;
                }

                var key = ManualAssetColorTags.ToColorKey(pair.Value);
                if (!groupsByColor.TryGetValue(key, out var group))
                {
                    group = new ColorGroup
                    {
                        Key = key,
                        Name = ManualAssetColorTags.GetColorName(pair.Value),
                        Color = pair.Value
                    };
                    groupsByColor.Add(key, group);
                    groups.Add(group);
                }

                group.Assets.Add(new AssetEntry { Guid = pair.Key, Path = path });
            }

            foreach (var group in groups)
            {
                group.Assets.Sort((left, right) => string.Compare(left.Path, right.Path, StringComparison.OrdinalIgnoreCase));
            }

            groups.Sort((left, right) => string.Compare(left.Name, right.Name, StringComparison.OrdinalIgnoreCase));
            RefreshFilteredAssets();
            Repaint();
        }

        private static void SelectAndPing(string path)
        {
            var asset = AssetDatabase.LoadMainAssetAtPath(path);
            if (asset == null)
            {
                Debug.LogWarning("[Unity Assist Tools] アセットを読み込めませんでした: " + path);
                return;
            }

            Selection.activeObject = asset;
            EditorGUIUtility.PingObject(asset);
        }

        [MenuItem("Tools/Unity File Colorizer/Color Groups", false, 2010)]
        private static void Open()
        {
            EditorWindow.GetWindow<ManualAssetColorGroupsWindow>("Color Groups");
        }
    }
}
