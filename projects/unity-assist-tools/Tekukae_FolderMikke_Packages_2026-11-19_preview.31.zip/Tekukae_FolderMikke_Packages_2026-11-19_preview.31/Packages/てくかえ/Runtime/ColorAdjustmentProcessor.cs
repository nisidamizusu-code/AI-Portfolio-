using System;

namespace Tekukae.TextureColorEngine
{
    /// <summary>Non-destructive post-conversion brightness and chroma adjustment for changed pixels only.</summary>
    public static class ColorAdjustmentProcessor
    {
        // Interactive previews are displayed in a window no wider than about 500 GUI points.
        // A 512px longest edge is sufficient while reducing per-drag work dramatically.
        public const int InteractivePreviewMaxDimension = 512;

        public sealed class PreviewData
        {
            public TexturePixels BaseImage { get; private set; }
            public byte[] ApplyWeights { get; private set; }

            internal PreviewData(TexturePixels baseImage, byte[] applyWeights)
            {
                BaseImage = baseImage;
                ApplyWeights = applyWeights;
            }
        }

        /// <summary>
        /// Builds a small, area-averaged preview source and mask once. This is only used while
        /// the user is actively dragging an adjustment slider; final output always uses full size.
        /// </summary>
        public static PreviewData CreatePreviewData(TexturePixels baseImage, byte[] applyWeights, int maxDimension)
        {
            if (baseImage == null) throw new ArgumentNullException(nameof(baseImage));
            if (applyWeights == null) throw new ArgumentNullException(nameof(applyWeights));
            if (applyWeights.Length != baseImage.Pixels.Length)
                throw new ArgumentException("Adjustment mask size does not match the image.", nameof(applyWeights));
            if (maxDimension < 1) throw new ArgumentOutOfRangeException(nameof(maxDimension));

            float scale = Math.Min(1f, maxDimension / (float)Math.Max(baseImage.Width, baseImage.Height));
            int previewWidth = Math.Max(1, (int)Math.Round(baseImage.Width * scale));
            int previewHeight = Math.Max(1, (int)Math.Round(baseImage.Height * scale));
            if (previewWidth == baseImage.Width && previewHeight == baseImage.Height)
                return new PreviewData(baseImage.Clone(), (byte[])applyWeights.Clone());

            Rgba32[] source = baseImage.Pixels;
            Rgba32[] previewPixels = new Rgba32[previewWidth * previewHeight];
            byte[] previewWeights = new byte[previewPixels.Length];

            for (int py = 0; py < previewHeight; py++)
            {
                int y0 = py * baseImage.Height / previewHeight;
                int y1 = Math.Max(y0 + 1, (py + 1) * baseImage.Height / previewHeight);
                for (int px = 0; px < previewWidth; px++)
                {
                    int x0 = px * baseImage.Width / previewWidth;
                    int x1 = Math.Max(x0 + 1, (px + 1) * baseImage.Width / previewWidth);
                    long sumR = 0, sumG = 0, sumB = 0, sumA = 0, sumWeight = 0;
                    int count = 0;
                    for (int sy = y0; sy < y1; sy++)
                    {
                        int row = sy * baseImage.Width;
                        for (int sx = x0; sx < x1; sx++)
                        {
                            int index = row + sx;
                            Rgba32 pixel = source[index];
                            sumR += pixel.R; sumG += pixel.G; sumB += pixel.B; sumA += pixel.A;
                            sumWeight += applyWeights[index];
                            count++;
                        }
                    }
                    int outputIndex = py * previewWidth + px;
                    previewPixels[outputIndex] = new Rgba32(
                        (byte)((sumR + count / 2) / count),
                        (byte)((sumG + count / 2) / count),
                        (byte)((sumB + count / 2) / count),
                        (byte)((sumA + count / 2) / count));
                    previewWeights[outputIndex] = (byte)((sumWeight + count / 2) / count);
                }
            }

            return new PreviewData(
                new TexturePixels(previewWidth, previewHeight, previewPixels, true), previewWeights);
        }

        // The UI range maps to a perceptual OKLab lightness offset of at most +/- 0.18.
        private const float MaximumLightnessOffset = 0.18f;

        /// <summary>
        /// Reusable adjustment workspace. Original OKLab values are calculated once when a
        /// recolor result is created, not every time the user moves a slider.
        /// </summary>
        public sealed class Workspace
        {
            private readonly TexturePixels baseImage;
            private readonly byte[] applyWeights;
            private readonly Oklab[] sourceLabs;
            private readonly int[] selectedIndices;

            public Workspace(TexturePixels baseImage, byte[] applyWeights)
            {
                if (baseImage == null) throw new ArgumentNullException(nameof(baseImage));
                if (applyWeights == null) throw new ArgumentNullException(nameof(applyWeights));
                if (applyWeights.Length != baseImage.Pixels.Length)
                    throw new ArgumentException("Adjustment mask size does not match the image.", nameof(applyWeights));

                this.baseImage = baseImage;
                this.applyWeights = applyWeights;

                int selectedCount = 0;
                for (int i = 0; i < applyWeights.Length; i++)
                    if (applyWeights[i] != 0 && baseImage.Pixels[i].A != 0)
                        selectedCount++;

                // Sparse masks use a compact index list so slider updates skip untouched
                // pixels entirely. Dense masks use a full-sized cache to avoid index overhead.
                bool useSparseIndices = selectedCount < baseImage.Pixels.Length * 0.42f;
                sourceLabs = new Oklab[useSparseIndices ? selectedCount : baseImage.Pixels.Length];
                selectedIndices = useSparseIndices ? new int[selectedCount] : null;

                int cursor = 0;
                for (int i = 0; i < baseImage.Pixels.Length; i++)
                {
                    Rgba32 pixel = baseImage.Pixels[i];
                    if (applyWeights[i] == 0 || pixel.A == 0) continue;

                    if (useSparseIndices) selectedIndices[cursor] = i;
                    sourceLabs[useSparseIndices ? cursor : i] = ColorMath.ToOklab(pixel);
                    cursor++;
                }
            }

            /// <summary>Writes the adjusted image into a reusable destination buffer.</summary>
            public void ApplyInto(Rgba32[] destination, float brightness, float saturationPercent)
            {
                ApplyIntoInternal(destination, brightness, saturationPercent, false);
            }

            public void ApplyIntoPreview(Rgba32[] destination, float brightness, float saturationPercent)
            {
                ApplyIntoInternal(destination, brightness, saturationPercent, true);
            }

            private void ApplyIntoInternal(Rgba32[] destination, float brightness, float saturationPercent, bool fastPreview)
            {
                if (destination == null) throw new ArgumentNullException(nameof(destination));
                if (destination.Length != baseImage.Pixels.Length)
                    throw new ArgumentException("Destination size does not match the image.", nameof(destination));

                brightness = ColorMath.Clamp(brightness, -100f, 100f);
                saturationPercent = ColorMath.Clamp(saturationPercent, 0f, 200f);
                bool isNeutral = Math.Abs(brightness) < 0.0001f && Math.Abs(saturationPercent - 100f) < 0.0001f;
                float lightnessOffset = brightness / 100f * MaximumLightnessOffset;
                float chromaScale = saturationPercent / 100f;

                if (selectedIndices != null)
                {
                    for (int j = 0; j < selectedIndices.Length; j++)
                    {
                        int i = selectedIndices[j];
                        Rgba32 original = baseImage.Pixels[i];
                        if (isNeutral)
                        {
                            destination[i] = original;
                            continue;
                        }
                        ApplyOne(destination, i, original, sourceLabs[j], applyWeights[i], lightnessOffset, chromaScale, fastPreview);
                    }
                }
                else
                {
                    for (int i = 0; i < destination.Length; i++)
                    {
                        byte maskByte = applyWeights[i];
                        if (maskByte == 0) continue;
                        Rgba32 original = baseImage.Pixels[i];
                        if (original.A == 0) continue;
                        if (isNeutral)
                        {
                            destination[i] = original;
                            continue;
                        }
                        ApplyOne(destination, i, original, sourceLabs[i], maskByte, lightnessOffset, chromaScale, fastPreview);
                    }
                }
            }

            private static void ApplyOne(Rgba32[] destination, int index, Rgba32 original, Oklab source,
                byte maskByte, float lightnessOffset, float chromaScale, bool fastPreview)
            {
                Oklab adjusted = new Oklab(
                    ColorMath.Clamp(source.L + lightnessOffset, 0f, 1f),
                    source.A * chromaScale,
                    source.B * chromaScale);
                Rgba32 adjustedPixel = fastPreview
                    ? ColorMath.ToSrgbPreview(adjusted, original.A)
                    : ColorMath.ToSrgb(adjusted, original.A);

                // Preserve the established soft-mask composition: blend the gamut-mapped
                // adjustment back with the original pixel at partially covered edges.
                if (maskByte != 255)
                {
                    Oklab mappedAdjusted = ColorMath.ToOklab(adjustedPixel);
                    adjusted = Oklab.Lerp(source, mappedAdjusted, maskByte / 255f);
                    adjustedPixel = fastPreview
                        ? ColorMath.ToSrgbPreview(adjusted, original.A)
                        : ColorMath.ToSrgb(adjusted, original.A);
                }

                destination[index] = adjustedPixel;
            }
        }

        /// <summary>Convenience API for callers that do not need repeated slider updates.</summary>
        public static TexturePixels Apply(TexturePixels baseImage, byte[] applyWeights, float brightness, float saturationPercent)
        {
            if (baseImage == null) throw new ArgumentNullException(nameof(baseImage));
            Workspace workspace = new Workspace(baseImage, applyWeights);
            Rgba32[] output = new Rgba32[baseImage.Pixels.Length];
            Array.Copy(baseImage.Pixels, output, output.Length);
            workspace.ApplyInto(output, brightness, saturationPercent);
            return new TexturePixels(baseImage.Width, baseImage.Height, output, true);
        }
    }
}
