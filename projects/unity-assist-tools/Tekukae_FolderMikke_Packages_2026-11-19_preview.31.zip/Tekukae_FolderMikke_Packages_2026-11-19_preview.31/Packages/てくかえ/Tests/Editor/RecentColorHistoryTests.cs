using NUnit.Framework;
using UnityEngine;
using Tekukae.TextureColorEngine.Editor;

namespace Tekukae.TextureColorEngine.Tests
{
    public sealed class RecentColorHistoryTests
    {
        [SetUp]
        public void SetUp()
        {
            RecentColorHistory.Clear();
        }

        [TearDown]
        public void TearDown()
        {
            RecentColorHistory.Clear();
        }

        [Test]
        public void Record_KeepsOnlySixteenMostRecentColors()
        {
            for (int i = 0; i < 20; i++)
                RecentColorHistory.Record(new Color32((byte)i, (byte)(i + 20), (byte)(i + 40), 255));

            var entries = RecentColorHistory.GetEntries();
            Assert.AreEqual(16, entries.Count);
            Assert.AreEqual(new Color32(19, 39, 59, 255), entries[0]);
            Assert.AreEqual(new Color32(4, 24, 44, 255), entries[15]);
        }

        [Test]
        public void Record_DuplicateMovesToFrontWithoutCreatingAnotherEntry()
        {
            Color32 first = new Color32(12, 34, 56, 255);
            Color32 second = new Color32(78, 90, 123, 255);
            RecentColorHistory.Record(first);
            RecentColorHistory.Record(second);
            RecentColorHistory.Record(first);

            var entries = RecentColorHistory.GetEntries();
            Assert.AreEqual(2, entries.Count);
            Assert.AreEqual(first, entries[0]);
            Assert.AreEqual(second, entries[1]);
        }
    }
}
