using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace Tekukae.TextureColorEngine.Editor
{
    /// <summary>Shared persistent history for colors successfully used in Tekukae previews.</summary>
    internal static class RecentColorHistory
    {
        internal const int MaximumEntries = 16;
        private const string PreferenceKey = "Tekukae.TextureColorEngine.RecentColorHistory.v1";
        private const int SwatchesPerRow = 8;
        private const float SwatchWidth = 34f;
        private const float SwatchHeight = 30f;

        internal static List<Color32> GetEntries()
        {
            var result = new List<Color32>(MaximumEntries);
            string stored = EditorPrefs.GetString(PreferenceKey, string.Empty);
            if (string.IsNullOrEmpty(stored)) return result;

            string[] entries = stored.Split(';');
            for (int i = 0; i < entries.Length && result.Count < MaximumEntries; i++)
            {
                Color32 color;
                if (!TryParse(entries[i], out color)) continue;
                if (Contains(result, color)) continue;
                result.Add(color);
            }
            return result;
        }

        internal static void Record(Color color)
        {
            Color32 bytes = color;
            Record(new Color32(bytes.r, bytes.g, bytes.b, 255));
        }

        internal static void Record(Color32 color)
        {
            color.a = 255;
            List<Color32> entries = GetEntries();
            for (int i = entries.Count - 1; i >= 0; i--)
            {
                if (SameRgb(entries[i], color)) entries.RemoveAt(i);
            }
            entries.Insert(0, color);
            if (entries.Count > MaximumEntries)
                entries.RemoveRange(MaximumEntries, entries.Count - MaximumEntries);
            Save(entries);
        }

        internal static void Clear()
        {
            EditorPrefs.DeleteKey(PreferenceKey);
        }

        /// <summary>Draws a larger framed palette of up to 16 swatches. Returns true when selection changes.</summary>
        internal static bool Draw(ref Color selectedColor)
        {
            List<Color32> entries = GetEntries();
            if (entries.Count == 0) return false;

            bool changed = false;
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField("使用色の履歴", EditorStyles.boldLabel);
                    GUILayout.Label(entries.Count + "/" + MaximumEntries, EditorStyles.miniLabel, GUILayout.Width(42f));
                    GUILayout.FlexibleSpace();
                    if (GUILayout.Button("消去", EditorStyles.miniButton, GUILayout.Width(54f), GUILayout.Height(22f)))
                    {
                        Clear();
                        changed = true;
                    }
                }

                int rowCount = (entries.Count + SwatchesPerRow - 1) / SwatchesPerRow;
                for (int row = 0; row < rowCount; row++)
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        GUILayout.Space(2f);
                        int start = row * SwatchesPerRow;
                        int end = Math.Min(start + SwatchesPerRow, entries.Count);
                        for (int i = start; i < end; i++)
                        {
                            Color32 entry = entries[i];
                            Rect swatchRect = GUILayoutUtility.GetRect(
                                SwatchWidth, SwatchHeight,
                                GUILayout.Width(SwatchWidth), GUILayout.Height(SwatchHeight));

                            // Draw the RGB swatch directly instead of tinting a dark Editor button style.
                            // GUI.backgroundColor multiplies the style texture and made every swatch look darker
                            // than the actual selected target color. DrawRect uses the stored sRGB Color32 value.
                            Color previousGuiColor = GUI.color;
                            Color previousBackground = GUI.backgroundColor;
                            GUI.color = Color.white;
                            GUI.backgroundColor = Color.white;
                            EditorGUI.DrawRect(swatchRect, new Color32(entry.r, entry.g, entry.b, 255));

                            bool hovered = swatchRect.Contains(Event.current.mousePosition);
                            Color borderColor = hovered
                                ? new Color(1f, 1f, 1f, 0.95f)
                                : new Color(0f, 0f, 0f, 0.55f);
                            DrawSwatchBorder(swatchRect, borderColor);

                            bool clicked = GUI.Button(
                                swatchRect,
                                new GUIContent("", "#" + ToHex(entry)),
                                GUIStyle.none);
                            GUI.color = previousGuiColor;
                            GUI.backgroundColor = previousBackground;

                            if (clicked)
                            {
                                selectedColor = new Color32(entry.r, entry.g, entry.b, 255);
                                Record(entry);
                                changed = true;
                            }
                        }
                        GUILayout.FlexibleSpace();
                    }
                }
            }

            if (changed) GUI.changed = true;
            return changed;
        }

        private static void DrawSwatchBorder(Rect rect, Color color)
        {
            const float thickness = 1f;
            EditorGUI.DrawRect(new Rect(rect.x, rect.y, rect.width, thickness), color);
            EditorGUI.DrawRect(new Rect(rect.x, rect.yMax - thickness, rect.width, thickness), color);
            EditorGUI.DrawRect(new Rect(rect.x, rect.y, thickness, rect.height), color);
            EditorGUI.DrawRect(new Rect(rect.xMax - thickness, rect.y, thickness, rect.height), color);
        }

        private static void Save(List<Color32> entries)
        {
            var values = new string[entries.Count];
            for (int i = 0; i < entries.Count; i++) values[i] = ToHex(entries[i]);
            EditorPrefs.SetString(PreferenceKey, string.Join(";", values));
        }

        private static bool TryParse(string value, out Color32 color)
        {
            color = new Color32(0, 0, 0, 255);
            if (string.IsNullOrEmpty(value) || value.Length != 6) return false;
            byte r, g, b;
            if (!byte.TryParse(value.Substring(0, 2), System.Globalization.NumberStyles.HexNumber, null, out r) ||
                !byte.TryParse(value.Substring(2, 2), System.Globalization.NumberStyles.HexNumber, null, out g) ||
                !byte.TryParse(value.Substring(4, 2), System.Globalization.NumberStyles.HexNumber, null, out b))
                return false;
            color = new Color32(r, g, b, 255);
            return true;
        }

        private static string ToHex(Color32 color)
        {
            return color.r.ToString("X2") + color.g.ToString("X2") + color.b.ToString("X2");
        }

        private static bool Contains(List<Color32> colors, Color32 candidate)
        {
            for (int i = 0; i < colors.Count; i++)
                if (SameRgb(colors[i], candidate)) return true;
            return false;
        }

        private static bool SameRgb(Color32 a, Color32 b)
        {
            return a.r == b.r && a.g == b.g && a.b == b.b;
        }
    }
}
