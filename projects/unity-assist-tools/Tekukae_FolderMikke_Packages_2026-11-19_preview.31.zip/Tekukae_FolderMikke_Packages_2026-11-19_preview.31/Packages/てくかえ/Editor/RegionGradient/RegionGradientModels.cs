using System;
using UnityEngine;
using Tekukae.TextureColorEngine;

namespace Tekukae.TextureColorEngine.Editor.RegionGradient
{
    [Serializable]
    internal sealed class RegionGradientTargetSettings
    {
        public Texture2D Texture;
        public Renderer Renderer;
        public int MaterialIndex;
        public string TextureProperty = "_MainTex";
        public string Label;
    }

    internal sealed class RegionGradientTarget
    {
        public RegionGradientTargetSettings Settings;
        public RegionTextureData Source;
        public Texture2D PreviewTexture;
        public Texture2D ResultTexture;
        public Texture2D ResultInteractiveTexture;
        public Color32[] BaseResultPixels;
        public byte[] CombinedApplyWeights;
        public TexturePixels AdjustmentPreviewBaseImage;
        public TexturePixels AdjustedPreviewImage;
        public ColorAdjustmentProcessor.Workspace AdjustmentPreviewWorkspace;
        public TexturePixels FullAdjustmentBaseImage;
        public TexturePixels AdjustedFullImage;
        public ColorAdjustmentProcessor.Workspace FullAdjustmentWorkspace;
        public bool HasFinalizedAdjustments;
        public bool NeedsFullFinalization;
        public float FinalizedBrightness;
        public float FinalizedSaturation = 100f;
        public Color32[] ResultPreviewColorBuffer;
        public Color32[] ResultFullColorBuffer;
        public RegionUvWorldMap UvWorldMap;
        public string Warning;
        private readonly System.Collections.Generic.Dictionary<int, RegionGradientSelection> selections =
            new System.Collections.Generic.Dictionary<int, RegionGradientSelection>();

        public RegionGradientSelection GetSelection(int regionId, bool create)
        {
            RegionGradientSelection selection;
            if (selections.TryGetValue(regionId, out selection)) return selection;
            if (!create) return null;
            selection = new RegionGradientSelection();
            selections.Add(regionId, selection);
            return selection;
        }

        public void RemoveSelection(int regionId)
        {
            RegionGradientSelection selection;
            if (!selections.TryGetValue(regionId, out selection)) return;
            selection.Dispose();
            selections.Remove(regionId);
        }

        public void Dispose()
        {
            Destroy(ref PreviewTexture);
            Destroy(ref ResultTexture);
            Destroy(ref ResultInteractiveTexture);
            foreach (var pair in selections) pair.Value.Dispose();
            selections.Clear();
            Source = null;
            BaseResultPixels = null;
            CombinedApplyWeights = null;
            AdjustmentPreviewBaseImage = null;
            AdjustedPreviewImage = null;
            AdjustmentPreviewWorkspace = null;
            FullAdjustmentBaseImage = null;
            AdjustedFullImage = null;
            FullAdjustmentWorkspace = null;
            HasFinalizedAdjustments = false;
            NeedsFullFinalization = false;
            ResultPreviewColorBuffer = null;
            ResultFullColorBuffer = null;
            UvWorldMap = null;
        }

        private static void Destroy(ref Texture2D texture)
        {
            if (texture == null) return;
            UnityEngine.Object.DestroyImmediate(texture);
            texture = null;
        }
    }

    internal sealed class RegionGradientSelection : IDisposable
    {
        public byte[] Mask;
        public Texture2D Overlay;
        public int SeedX = -1;
        public int SeedY = -1;

        public void Dispose()
        {
            if (Overlay != null) UnityEngine.Object.DestroyImmediate(Overlay);
            Overlay = null;
            Mask = null;
            SeedX = SeedY = -1;
        }
    }

    internal sealed class RegionGradientRegion
    {
        public int Id;
        public string Name;
        public bool Enabled = true;
        public RegionGradientSettings Settings = new RegionGradientSettings();

        public static RegionGradientSettings CloneSettings(RegionGradientSettings source)
        {
            var clone = new RegionGradientSettings();
            if (source == null) return clone;
            clone.PositionX = source.PositionX;
            clone.PositionY = source.PositionY;
            clone.AngleDegrees = source.AngleDegrees;
            clone.Scale = source.Scale;
            clone.StartColor = source.StartColor;
            clone.MiddleColor = source.MiddleColor;
            clone.EndColor = source.EndColor;
            clone.OriginalGradientRetention = source.OriginalGradientRetention;
            clone.ShadingRetention = source.ShadingRetention;
            clone.BrightnessRetention = source.BrightnessRetention;
            clone.SaturationRetention = source.SaturationRetention;
            clone.AnalysisRadius = source.AnalysisRadius;
            clone.FeatherPixels = source.FeatherPixels;
            return clone;
        }
    }

    internal sealed class RegionTextureData
    {
        public readonly int Width;
        public readonly int Height;
        public readonly Color32[] Pixels;
        public readonly string AssetPath;
        public readonly string Warning;
        public readonly bool IsSrgb;

        public RegionTextureData(int width, int height, Color32[] pixels, string assetPath, string warning, bool isSrgb)
        {
            if (width <= 0 || height <= 0 || pixels == null || (long)width * height != pixels.Length)
                throw new ArgumentException("Region texture dimensions and pixel data do not match.");
            Width = width;
            Height = height;
            Pixels = pixels;
            AssetPath = assetPath;
            Warning = warning;
            IsSrgb = isSrgb;
        }
    }

    internal sealed class RegionUvWorldMap
    {
        public readonly Vector3[] Positions;
        public readonly bool[] Valid;
        public readonly int OverlapPixels;
        public readonly Bounds LocalBounds;

        public RegionUvWorldMap(Vector3[] positions, bool[] valid, int overlapPixels, Bounds bounds)
        {
            Positions = positions;
            Valid = valid;
            OverlapPixels = overlapPixels;
            LocalBounds = bounds;
        }
    }

    internal sealed class RegionGradientSettings
    {
        public float PositionX = 0.5f;
        public float PositionY = 0.5f;
        public float AngleDegrees = 90f;
        public float Scale = 1.0f;
        public OklchColor StartColor = new OklchColor(0.72f, 0.12f, 330f);
        public OklchColor MiddleColor = new OklchColor(0.68f, 0.15f, 285f);
        public OklchColor EndColor = new OklchColor(0.62f, 0.14f, 235f);
        public float OriginalGradientRetention = 0.65f;
        public float ShadingRetention = 0.85f;
        public float BrightnessRetention = 0.70f;
        public float SaturationRetention = 0.70f;
        public int AnalysisRadius = 12;
        public int FeatherPixels = 2;
    }

    internal sealed class RegionGradientResult
    {
        public readonly Color32[] Pixels;
        public readonly int SelectedPixels;
        public readonly int PartiallySelectedPixels;
        public readonly byte[] ApplyWeights;

        public RegionGradientResult(Color32[] pixels, int selectedPixels, int partiallySelectedPixels, byte[] applyWeights)
        {
            Pixels = pixels;
            SelectedPixels = selectedPixels;
            PartiallySelectedPixels = partiallySelectedPixels;
            ApplyWeights = applyWeights;
        }
    }
}
