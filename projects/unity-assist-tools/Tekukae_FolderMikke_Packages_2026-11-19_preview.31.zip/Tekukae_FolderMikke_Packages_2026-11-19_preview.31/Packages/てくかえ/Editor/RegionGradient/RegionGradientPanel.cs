using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace Tekukae.TextureColorEngine.Editor.RegionGradient
{
    /// <summary>
    /// Editor UI/controller for the isolated Region Gradient feature.
    /// It does not call or mutate the existing color conversion engine.
    /// </summary>
    internal sealed class RegionGradientPanel : IDisposable
    {
        private readonly List<RegionGradientTarget> targets = new List<RegionGradientTarget>();
        private readonly List<RegionGradientRegion> regions = new List<RegionGradientRegion>
        {
            new RegionGradientRegion { Id = 1, Name = "グラデーション領域 1" }
        };
        private int nextRegionId = 2;
        private int activeRegionIndex;
        private RegionGradientRegion ActiveRegion
        {
            get { return regions[Mathf.Clamp(activeRegionIndex, 0, regions.Count - 1)]; }
        }
        private Transform avatarRoot;
        private Texture2D pendingTexture;
        private Renderer pendingRenderer;
        private int pendingMaterialIndex;
        private string pendingTextureProperty = "_MainTex";
        private int activeTargetIndex;
        private Vector2 targetScroll;
        private Vector2 workspaceScroll;
        private string statusMessage;
        private bool scenePicking;
        private EditorWindow owner;
        private Texture2D gradientStripTexture;
        private bool gradientStripDirty = true;
        private int gradientControlId;
        private int gradientDragHandle = -1;
        private float selectionTolerance = 0.55f;
        private float edgeSensitivity = 0.58f;
        private float outputBrightness = 0f;
        private float outputSaturation = 100f;
        private bool adjustmentRefreshPending;
        private bool adjustmentRefreshSubscribed;
        private bool adjustmentSliderDragging;
        private double adjustmentRefreshAt;
        private const double AdjustmentRefreshDelaySeconds = 0.22;
        private const int RegionPreviewMaxDimension = 384;
        private const int MaximumTargets = 12;
        private const int MaximumRegions = 16;

        public void Draw(EditorWindow editorWindow)
        {
            owner = editorWindow;
            workspaceScroll = EditorGUILayout.BeginScrollView(workspaceScroll);
            EditorGUILayout.HelpBox(
                "選択した領域にグラデーションを適用します。元画像の色変化・陰影・明度・彩度を個別に分析して反映します。既存の色変換処理とは独立しています。",
                MessageType.Info);

            DrawTargetGroupPanel();
            DrawRegionManagerPanel();
            if (targets.Count == 0)
            {
                EditorGUILayout.HelpBox("テクスチャを追加してください。3Dモデルから選択する場合はレンダラーも登録します。", MessageType.Warning);
                EditorGUILayout.EndScrollView();
                return;
            }

            activeTargetIndex = Mathf.Clamp(activeTargetIndex, 0, targets.Count - 1);
            activeRegionIndex = Mathf.Clamp(activeRegionIndex, 0, regions.Count - 1);
            DrawSelectionPanel();
            DrawGradientPanel();
            DrawOutputPanel();

            if (!string.IsNullOrEmpty(statusMessage))
                EditorGUILayout.HelpBox(statusMessage, MessageType.Info);
            EditorGUILayout.EndScrollView();
        }

        public void Dispose()
        {
            CancelPendingAdjustmentRefresh();
            StopScenePicking();
            if (gradientStripTexture != null) UnityEngine.Object.DestroyImmediate(gradientStripTexture);
            gradientStripTexture = null;
            if (GUIUtility.hotControl == gradientControlId) GUIUtility.hotControl = 0;
            for (int i = 0; i < targets.Count; i++) targets[i].Dispose();
            targets.Clear();
        }

        public void OnOwnerLostFocus()
        {
            adjustmentSliderDragging = false;
            if (adjustmentRefreshPending)
                adjustmentRefreshAt = EditorApplication.timeSinceStartup + 0.08;
        }

        private void DrawTargetGroupPanel()
        {
            EditorGUILayout.LabelField("対象テクスチャのグループ", EditorStyles.boldLabel);
            avatarRoot = (Transform)EditorGUILayout.ObjectField(
                new GUIContent("アバターのルート", "複数のレンダラーをアバターの共通座標で扱うためのルートオブジェクトです。"),
                avatarRoot, typeof(Transform), true);

            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField("追加する対象", EditorStyles.boldLabel);
                pendingTexture = (Texture2D)EditorGUILayout.ObjectField("テクスチャ", pendingTexture, typeof(Texture2D), false);
                pendingRenderer = (Renderer)EditorGUILayout.ObjectField("レンダラー（任意）", pendingRenderer, typeof(Renderer), true);
                using (new EditorGUILayout.HorizontalScope())
                {
                    pendingMaterialIndex = EditorGUILayout.IntField("マテリアル番号", pendingMaterialIndex, GUILayout.Width(190f));
                    pendingTextureProperty = EditorGUILayout.TextField("テクスチャ項目名", pendingTextureProperty);
                }
                using (new EditorGUI.DisabledScope(targets.Count >= MaximumTargets || (pendingTexture == null && pendingRenderer == null)))
                {
                    if (GUILayout.Button("対象を追加", GUILayout.Height(24f))) AddPendingTarget();
                }
                EditorGUILayout.LabelField("最大 " + MaximumTargets + "件の対象を登録できます。メイン・サイドなど、別々のテクスチャを同じグループに登録できます。", EditorStyles.miniLabel);
            }

            if (targets.Count > 0)
            {
                EditorGUILayout.LabelField("登録済みの対象", EditorStyles.boldLabel);
                targetScroll = EditorGUILayout.BeginScrollView(targetScroll, GUILayout.MaxHeight(190f));
                for (int i = 0; i < targets.Count; i++) DrawTargetRow(i);
                EditorGUILayout.EndScrollView();
                string[] labels = new string[targets.Count];
                for (int i = 0; i < targets.Count; i++) labels[i] = GetTargetLabel(targets[i], i);
                activeTargetIndex = EditorGUILayout.Popup("編集対象", activeTargetIndex, labels);
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button("3D座標マップを再構築")) RebuildWorldMaps();
                    if (GUILayout.Button("この領域の全対象の選択を解除")) ClearAllSelections();
                }
            }
        }

        private void DrawRegionManagerPanel()
        {
            EditorGUILayout.Space(6f);
            EditorGUILayout.LabelField("独立したグラデーション領域", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("変換したい箇所ごとに領域を追加してください。各領域は選択範囲・色・方向・位置・幅を個別に保持します。リストの下にある領域ほど、重なった部分に後から適用されます。", MessageType.Info);
            for (int i = 0; i < regions.Count; i++)
            {
                RegionGradientRegion region = regions[i];
                using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
                {
                    bool active = GUILayout.Toggle(activeRegionIndex == i, region.Name, "Button", GUILayout.Width(150f));
                    if (active && activeRegionIndex != i)
                    {
                        activeRegionIndex = i;
                        gradientStripDirty = true;
                    }
                    region.Name = EditorGUILayout.TextField(region.Name);
                    bool enabled = EditorGUILayout.ToggleLeft("有効", region.Enabled, GUILayout.Width(48f));
                    if (enabled != region.Enabled)
                    {
                        region.Enabled = enabled;
                        ClearAllResults();
                    }
                    int selectedTargets = CountSelectedTargets(region.Id);
                    GUILayout.Label(selectedTargets + "件の対象", EditorStyles.miniLabel, GUILayout.Width(58f));
                    using (new EditorGUI.DisabledScope(i == 0))
                    {
                        if (GUILayout.Button("↑", GUILayout.Width(25f)))
                        {
                            SwapRegions(i, i - 1);
                            GUIUtility.ExitGUI();
                        }
                    }
                    using (new EditorGUI.DisabledScope(i >= regions.Count - 1))
                    {
                        if (GUILayout.Button("↓", GUILayout.Width(25f)))
                        {
                            SwapRegions(i, i + 1);
                            GUIUtility.ExitGUI();
                        }
                    }
                    using (new EditorGUI.DisabledScope(regions.Count <= 1))
                    {
                        if (GUILayout.Button("削除", GUILayout.Width(42f)))
                        {
                            RemoveRegion(region);
                            GUIUtility.ExitGUI();
                        }
                    }
                }
            }
            using (new EditorGUI.DisabledScope(regions.Count >= MaximumRegions))
            {
                if (GUILayout.Button("＋ 変換領域を追加", GUILayout.Height(25f))) AddRegion();
            }
            EditorGUILayout.LabelField("領域数: " + regions.Count + " / " + MaximumRegions + "　選択中: " + ActiveRegion.Name,
                EditorStyles.miniLabel);
        }

        private int CountSelectedTargets(int regionId)
        {
            int count = 0;
            for (int i = 0; i < targets.Count; i++)
            {
                RegionGradientSelection selection = targets[i].GetSelection(regionId, false);
                if (selection != null && selection.Mask != null) count++;
            }
            return count;
        }

        private void AddRegion()
        {
            RegionGradientSettings copy = RegionGradientRegion.CloneSettings(ActiveRegion.Settings);
            int id = nextRegionId++;
            RegionGradientRegion region = new RegionGradientRegion
            {
                Id = id,
                Name = "グラデーション領域 " + id,
                Settings = copy,
                Enabled = true
            };
            regions.Add(region);
            activeRegionIndex = regions.Count - 1;
            gradientStripDirty = true;
            ClearAllResults();
            statusMessage = region.Name + "を追加しました。選択範囲は独立しています。各対象で加工箇所を選択してください。";
        }

        private void RemoveRegion(RegionGradientRegion region)
        {
            if (region == null || regions.Count <= 1) return;
            int removedIndex = regions.IndexOf(region);
            if (removedIndex < 0) return;
            for (int i = 0; i < targets.Count; i++) targets[i].RemoveSelection(region.Id);
            regions.RemoveAt(removedIndex);
            activeRegionIndex = Mathf.Clamp(activeRegionIndex > removedIndex ? activeRegionIndex - 1 : activeRegionIndex, 0, regions.Count - 1);
            gradientStripDirty = true;
            ClearAllResults();
            statusMessage = region.Name + "を削除しました。";
        }

        private void SwapRegions(int a, int b)
        {
            if (a < 0 || b < 0 || a >= regions.Count || b >= regions.Count) return;
            RegionGradientRegion temp = regions[a];
            regions[a] = regions[b];
            regions[b] = temp;
            if (activeRegionIndex == a) activeRegionIndex = b;
            else if (activeRegionIndex == b) activeRegionIndex = a;
            ClearAllResults();
            statusMessage = "適用順を変更しました。リストの下にある領域ほど後から適用されます。";
        }

        private void DrawTargetRow(int index)
        {
            RegionGradientTarget target = targets[index];
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    bool active = GUILayout.Toggle(activeTargetIndex == index, GetTargetLabel(target, index), "Button", GUILayout.Width(150f));
                    if (active) activeTargetIndex = index;
                    GUILayout.FlexibleSpace();
                    if (GUILayout.Button("再読み込み", GUILayout.Width(68f))) LoadTarget(target);
                    if (GUILayout.Button("削除", GUILayout.Width(48f)))
                    {
                        target.Dispose();
                        targets.RemoveAt(index);
                        activeTargetIndex = Mathf.Clamp(activeTargetIndex, 0, Mathf.Max(0, targets.Count - 1));
                        ClearAllResults();
                        GUIUtility.ExitGUI();
                    }
                }
                Texture2D texture = (Texture2D)EditorGUILayout.ObjectField("テクスチャ", target.Settings.Texture, typeof(Texture2D), false);
                Renderer renderer = (Renderer)EditorGUILayout.ObjectField("レンダラー", target.Settings.Renderer, typeof(Renderer), true);
                using (new EditorGUILayout.HorizontalScope())
                {
                    int materialIndex = EditorGUILayout.IntField("マテリアル番号", target.Settings.MaterialIndex, GUILayout.Width(190f));
                    string property = EditorGUILayout.TextField("テクスチャ項目名", target.Settings.TextureProperty);
                    if (materialIndex != target.Settings.MaterialIndex || property != target.Settings.TextureProperty)
                    {
                        target.Settings.MaterialIndex = Mathf.Max(0, materialIndex);
                        target.Settings.TextureProperty = property;
                        target.UvWorldMap = null;
                        ClearAllResults();
                    }
                }
                if (texture != target.Settings.Texture || renderer != target.Settings.Renderer)
                {
                    target.Settings.Texture = texture;
                    target.Settings.Renderer = renderer;
                    target.UvWorldMap = null;
                    LoadTarget(target);
                    ClearAllResults();
                }
                if (!string.IsNullOrEmpty(target.Warning))
                    EditorGUILayout.HelpBox(target.Warning, MessageType.Warning);
            }
        }

        private void AddPendingTarget()
        {
            Texture2D texture = pendingTexture;
            string property = string.IsNullOrEmpty(pendingTextureProperty) ? "_MainTex" : pendingTextureProperty.Trim();
            if (texture == null && pendingRenderer != null)
            {
                Material[] materials = pendingRenderer.sharedMaterials;
                if (pendingMaterialIndex >= 0 && pendingMaterialIndex < materials.Length)
                {
                    Material material = materials[pendingMaterialIndex];
                    if (material != null)
                    {
                        if (texture != null && (string.IsNullOrEmpty(property) || !material.HasProperty(property) || material.GetTexture(property) != texture))
                        {
                            if (!RegionGradientMeshUtility.TryFindTextureProperty(material, texture, out property)) property = null;
                        }
                        else if (string.IsNullOrEmpty(property) || !material.HasProperty(property))
                        {
                            if (!RegionGradientMeshUtility.TryGetTextureProperty(material, out property)) property = null;
                        }
                        if (texture == null && !string.IsNullOrEmpty(property)) texture = material.GetTexture(property) as Texture2D;
                    }
                }
            }
            if (texture == null)
            {
                statusMessage = "テクスチャを取得できません。テクスチャを直接指定するか、レンダラー・マテリアル番号・テクスチャ項目名を確認してください。";
                return;
            }
            for (int i = 0; i < targets.Count; i++)
            {
                if (targets[i].Settings.Texture == texture)
                {
                    statusMessage = "同じテクスチャは既に登録されています。同じテクスチャを重複して登録することはできません。";
                    return;
                }
            }
            var entry = new RegionGradientTarget
            {
                Settings = new RegionGradientTargetSettings
                {
                    Texture = texture,
                    Renderer = pendingRenderer,
                    MaterialIndex = Mathf.Max(0, pendingMaterialIndex),
                    TextureProperty = property,
                    Label = texture.name
                }
            };
            targets.Add(entry);
            activeTargetIndex = targets.Count - 1;
            LoadTarget(entry);
            ClearAllResults();
            pendingTexture = null;
            statusMessage = "対象を追加しました。";
        }

        private void DrawSelectionPanel()
        {
            RegionGradientTarget target = targets[activeTargetIndex];
            RegionGradientSelection selection = target.GetSelection(ActiveRegion.Id, false);
            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("自動領域選択 / " + ActiveRegion.Name, EditorStyles.boldLabel);
            if (target.Source == null)
            {
                EditorGUILayout.HelpBox("選択対象のテクスチャが読み込まれていません。対象の「再読み込み」を実行してください。", MessageType.Warning);
                return;
            }
            EditorGUILayout.LabelField("テクスチャサイズ", target.Source.Width + " × " + target.Source.Height);
            if (!string.IsNullOrEmpty(target.Source.Warning)) EditorGUILayout.HelpBox(target.Source.Warning, MessageType.Warning);
            EditorGUILayout.LabelField("色の許容範囲", selectionTolerance.ToString("0.00"));
            selectionTolerance = EditorGUILayout.Slider(selectionTolerance, 0.05f, 1f);
            EditorGUILayout.LabelField("境界の検出感度", edgeSensitivity.ToString("0.00"));
            edgeSensitivity = EditorGUILayout.Slider(edgeSensitivity, 0f, 1f);
            using (new EditorGUILayout.HorizontalScope())
            {
                bool hasSceneRenderer = HasSceneRenderer();
                using (new EditorGUI.DisabledScope(!scenePicking && !hasSceneRenderer))
                {
                    if (GUILayout.Button(scenePicking ? "シーンビュー選択を終了" : "シーンビューから選択"))
                    {
                        if (scenePicking) StopScenePicking();
                        else StartScenePicking();
                    }
                }
                using (new EditorGUI.DisabledScope(selection == null || selection.Mask == null))
                {
                    if (GUILayout.Button("この領域の選択を解除")) ClearSelection(target);
                }
            }
            if (target.UvWorldMap != null)
                EditorGUILayout.HelpBox("この対象は3D座標マッピング済みです。各領域の設定は独立していますが、メイン・サイドなど同じ領域に登録した対象は共通座標を使用します。", MessageType.Info);
            DrawTextureSelectionCanvas(target);
            if (selection != null && selection.Mask != null)
            {
                int selected = 0;
                for (int i = 0; i < selection.Mask.Length; i++) if (selection.Mask[i] > 0) selected++;
                EditorGUILayout.LabelField("選択ピクセル数: " + selected.ToString("N0") + " / 開始位置: (" + selection.SeedX + ", " + selection.SeedY + ")", EditorStyles.miniLabel);
                if (selected == 0) EditorGUILayout.HelpBox("クリックした画素は透明、または領域選択の対象外です。別の位置を選択してください。", MessageType.Warning);
            }
            EditorGUILayout.HelpBox("現在選択中の領域専用マスクです。クリックで連続領域を自動選択、Shift＋クリックで追加、Alt＋クリック（シーンビューではCtrl＋クリック）で除外します。", MessageType.None);
        }

        private void DrawTextureSelectionCanvas(RegionGradientTarget target)
        {
            EditorGUILayout.LabelField("テクスチャ表示（クリックで自動選択）", EditorStyles.centeredGreyMiniLabel);
            Rect container = GUILayoutUtility.GetRect(300f, 300f, GUILayout.ExpandWidth(true));
            GUI.Box(container, GUIContent.none);
            Rect imageRect = FitRect(container, target.Source.Width, target.Source.Height);
            if (target.PreviewTexture == null) target.PreviewTexture = RegionGradientTextureIO.CreatePreview(target.Source, target.Source.Pixels);
            GUI.DrawTexture(imageRect, target.PreviewTexture, ScaleMode.StretchToFill, true);
            RegionGradientSelection selection = target.GetSelection(ActiveRegion.Id, false);
            if (selection != null && selection.Overlay != null) GUI.DrawTexture(imageRect, selection.Overlay, ScaleMode.StretchToFill, true);
            if (selection != null && selection.SeedX >= 0 && selection.SeedY >= 0)
                DrawSeedMarker(imageRect, selection.SeedX, selection.SeedY, target.Source.Width, target.Source.Height);

            if (target.UvWorldMap == null)
                DrawGradientHandles(imageRect, ActiveRegion.Settings);
            Event e = Event.current;
            gradientControlId = GUIUtility.GetControlID(FocusType.Passive);
            if (e.type == EventType.MouseDown && e.button == 0 && imageRect.Contains(e.mousePosition))
            {
                int handle = HitGradientHandle(imageRect, e.mousePosition, ActiveRegion.Settings);
                if (handle >= 0)
                {
                    gradientDragHandle = handle;
                    GUIUtility.hotControl = gradientControlId;
                    e.Use();
                }
                else
                {
                    int x = Mathf.Clamp(Mathf.FloorToInt((e.mousePosition.x - imageRect.x) / imageRect.width * target.Source.Width), 0, target.Source.Width - 1);
                    int y = Mathf.Clamp(Mathf.FloorToInt((imageRect.yMax - e.mousePosition.y) / imageRect.height * target.Source.Height), 0, target.Source.Height - 1);
                    SelectRegion(target, x, y, e.shift, e.alt);
                    e.Use();
                }
                if (owner != null) owner.Repaint();
            }
            else if (e.type == EventType.MouseDrag && GUIUtility.hotControl == gradientControlId && gradientDragHandle >= 0)
            {
                UpdateGradientHandle(imageRect, e.mousePosition, gradientDragHandle, ActiveRegion.Settings);
                gradientStripDirty = true;
                ClearAllResults();
                e.Use();
                if (owner != null) owner.Repaint();
            }
            else if (e.type == EventType.MouseUp && GUIUtility.hotControl == gradientControlId)
            {
                GUIUtility.hotControl = 0;
                gradientDragHandle = -1;
                e.Use();
            }
        }

        private void DrawGradientPanel()
        {
            RegionGradientSettings settings = ActiveRegion.Settings;
            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("知覚色グラデーション / " + ActiveRegion.Name, EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("色の補間・分析・合成には、この機能専用のOKLab / OKLCH処理を使用します。既存の色変換処理は呼び出しません。", MessageType.None);
            EditorGUI.BeginChangeCheck();
            DrawGradientColorField("開始色", ref settings.StartColor);
            DrawGradientColorField("中間色", ref settings.MiddleColor);
            DrawGradientColorField("終了色", ref settings.EndColor);
            EditorGUILayout.Space(4f);
            EditorGUILayout.LabelField("位置・方向", EditorStyles.boldLabel);
            settings.PositionX = EditorGUILayout.Slider("横位置（X）", settings.PositionX, 0f, 1f);
            settings.PositionY = EditorGUILayout.Slider("縦位置（Y）", settings.PositionY, 0f, 1f);
            settings.AngleDegrees = EditorGUILayout.Slider("角度", settings.AngleDegrees, 0f, 360f);
            settings.Scale = EditorGUILayout.Slider("広がり", settings.Scale, 0.05f, 2f);
            EditorGUILayout.Space(4f);
            EditorGUILayout.LabelField("元テクスチャの特徴を保持", EditorStyles.boldLabel);
            settings.OriginalGradientRetention = EditorGUILayout.Slider("元の色変化", settings.OriginalGradientRetention, 0f, 1f);
            settings.ShadingRetention = EditorGUILayout.Slider("陰影", settings.ShadingRetention, 0f, 1f);
            settings.BrightnessRetention = EditorGUILayout.Slider("明度", settings.BrightnessRetention, 0f, 1f);
            settings.SaturationRetention = EditorGUILayout.Slider("彩度", settings.SaturationRetention, 0f, 1f);
            settings.FeatherPixels = EditorGUILayout.IntSlider("選択境界のぼかし", settings.FeatherPixels, 0, 24);
            if (EditorGUI.EndChangeCheck())
            {
                gradientStripDirty = true;
                ClearAllResults();
            }
            DrawGradientStrip(settings);
        }

        private void DrawGradientColorField(string label, ref OklchColor color)
        {
            Color32 srgb = RegionGradientColorMath.ToSrgb(color, 255);
            Color selected = new Color(srgb.r / 255f, srgb.g / 255f, srgb.b / 255f, 1f);
            Color next = EditorGUILayout.ColorField(new GUIContent(label), selected, false, false, false);
            Tekukae.TextureColorEngine.Editor.RecentColorHistory.Draw(ref next);
            Color32 nextSrgb = (Color32)next;
            if (nextSrgb.r != srgb.r || nextSrgb.g != srgb.g ||
                nextSrgb.b != srgb.b || nextSrgb.a != srgb.a)
            {
                color = RegionGradientColorMath.ToOklch(RegionGradientColorMath.ToOklab(nextSrgb));
            }
        }

        private void DrawGradientStrip(RegionGradientSettings settings)
        {
            if (gradientStripTexture == null)
            {
                gradientStripTexture = new Texture2D(128, 1, TextureFormat.RGBA32, false, false);
                gradientStripTexture.hideFlags = HideFlags.HideAndDontSave;
                gradientStripDirty = true;
            }
            if (gradientStripDirty)
            {
                Color32[] pixels = new Color32[128];
                for (int i = 0; i < pixels.Length; i++)
                {
                    float t = i / 127f;
                    OklchColor c = t <= 0.5f
                        ? RegionGradientColorMath.Lerp(settings.StartColor, settings.MiddleColor, t * 2f)
                        : RegionGradientColorMath.Lerp(settings.MiddleColor, settings.EndColor, (t - 0.5f) * 2f);
                    pixels[i] = RegionGradientColorMath.ToSrgb(c, 255);
                }
                gradientStripTexture.SetPixels32(pixels);
                gradientStripTexture.Apply(false, false);
                gradientStripDirty = false;
            }
            Rect rect = GUILayoutUtility.GetRect(80f, 22f, GUILayout.ExpandWidth(true));
            GUI.DrawTexture(rect, gradientStripTexture, ScaleMode.StretchToFill, false);
        }

        private void DrawOutputPanel()
        {
            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("プレビュー・保存", EditorStyles.boldLabel);
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("すべての対象のプレビューを更新", GUILayout.Height(28f))) BuildAllPreviews();
                using (new EditorGUI.DisabledScope(!HasAnyResult()))
                {
                    if (GUILayout.Button("プレビュー済み画像をPNG保存", GUILayout.Height(28f))) ExportAllResults();
                }
            }
            EditorGUILayout.LabelField("変換後の色調整（変更箇所共通）", EditorStyles.boldLabel);
            EditorGUI.BeginChangeCheck();
            outputBrightness = EditorGUILayout.Slider("明るさ", outputBrightness, -100f, 100f);
            outputSaturation = EditorGUILayout.Slider("彩度", outputSaturation, 0f, 200f);
            bool adjustmentChanged = EditorGUI.EndChangeCheck();
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.FlexibleSpace();
                if (GUILayout.Button("調整をリセット", GUILayout.Width(110f)))
                {
                    outputBrightness = 0f;
                    outputSaturation = 100f;
                    adjustmentChanged = true;
                }
            }
            if (adjustmentChanged)
                ScheduleAdjustedPreviews(GUIUtility.hotControl != 0 && Event.current.rawType != EventType.MouseUp);

            if (adjustmentRefreshPending && Event.current.rawType == EventType.MouseUp)
            {
                adjustmentSliderDragging = false;
                FinalizeActiveAdjustedPreview();
            }

            if (activeTargetIndex >= 0 && activeTargetIndex < targets.Count)
            {
                RegionGradientTarget target = targets[activeTargetIndex];
                Texture2D displayTexture = adjustmentRefreshPending && target.ResultInteractiveTexture != null
                    ? target.ResultInteractiveTexture
                    : target.ResultTexture;
                if (displayTexture != null)
                {
                    EditorGUILayout.LabelField("処理結果プレビュー", EditorStyles.centeredGreyMiniLabel);
                    Rect container = GUILayoutUtility.GetRect(300f, 250f, GUILayout.ExpandWidth(true));
                    GUI.Box(container, GUIContent.none);
                    GUI.DrawTexture(FitRect(container, displayTexture.width, displayTexture.height), displayTexture, ScaleMode.StretchToFill, true);
                }
            }
            int ready = 0;
            for (int i = 0; i < targets.Count; i++) if (targets[i].ResultTexture != null) ready++;
            EditorGUILayout.LabelField("プレビュー生成済み: " + ready + " / " + targets.Count + "件", EditorStyles.miniLabel);
        }

        private void LoadTarget(RegionGradientTarget target)
        {
            if (target == null) return;
            target.Dispose();
            if (target.Settings.Texture == null)
            {
                target.Warning = "テクスチャが指定されていません。";
                ClearAllResults();
                return;
            }
            target.Settings.Label = target.Settings.Texture.name;
            try
            {
                target.Source = RegionGradientTextureIO.Load(target.Settings.Texture);
                target.PreviewTexture = RegionGradientTextureIO.CreatePreview(target.Source, target.Source.Pixels);
                target.Warning = null;
                if (target.Settings.Renderer != null)
                {
                    Material[] materials = target.Settings.Renderer.sharedMaterials;
                    if (target.Settings.MaterialIndex >= 0 && target.Settings.MaterialIndex < materials.Length)
                    {
                        Material material = materials[target.Settings.MaterialIndex];
                        if (material != null && !string.IsNullOrEmpty(target.Settings.TextureProperty) &&
                            material.GetTexture(target.Settings.TextureProperty) != target.Settings.Texture)
                            target.Warning = "指定したテクスチャとレンダラーのマテリアル項目が一致していません。シーンビュー選択・3D座標マッピングを使用する場合は、対応する項目名を指定してください。";
                    }
                }
                if (!string.IsNullOrEmpty(target.Source.Warning))
                    target.Warning = string.IsNullOrEmpty(target.Warning) ? target.Source.Warning : target.Warning + " " + target.Source.Warning;
                for (int i = 0; i < regions.Count; i++) target.RemoveSelection(regions[i].Id);
                target.UvWorldMap = null;
            }
            catch (Exception ex)
            {
                target.Warning = "読み込み失敗: " + ex.Message;
                Debug.LogException(ex);
            }
            ClearAllResults();
        }

        private void SelectRegion(RegionGradientTarget target, int x, int y)
        {
            SelectRegion(target, x, y, false, false);
        }

        private void SelectRegion(RegionGradientTarget target, int x, int y, bool additive, bool subtractive)
        {
            if (target == null || target.Source == null) return;
            RegionGradientSelection selection = target.GetSelection(ActiveRegion.Id, true);
            try
            {
                byte[] region = RegionSelectionEngine.Select(
                    target.Source.Pixels, target.Source.Width, target.Source.Height, x, y,
                    selectionTolerance, edgeSensitivity, target.Source.Pixels.Length);
                if (subtractive)
                {
                    if (selection.Mask == null)
                    {
                        statusMessage = "除外する前に、この領域で選択範囲を作成してください。";
                        return;
                    }
                    for (int i = 0; i < region.Length; i++)
                        if (region[i] > 0) selection.Mask[i] = 0;
                }
                else if (additive && selection.Mask != null)
                {
                    for (int i = 0; i < region.Length; i++)
                        if (region[i] > 0) selection.Mask[i] = 255;
                }
                else selection.Mask = region;
                selection.SeedX = x;
                selection.SeedY = y;
                RebuildMaskOverlay(target, selection);
                ClearAllResults();
                statusMessage = additive ? ActiveRegion.Name + "に領域を追加しました。" :
                    subtractive ? ActiveRegion.Name + "から領域を除外しました。" :
                    target.Settings.Label + "の" + ActiveRegion.Name + "を選択しました。";
            }
            catch (Exception ex)
            {
                statusMessage = "自動選択に失敗しました: " + ex.Message;
                Debug.LogException(ex);
            }
        }

        private void RebuildMaskOverlay(RegionGradientTarget target, RegionGradientSelection selection)
        {
            if (selection.Overlay != null) UnityEngine.Object.DestroyImmediate(selection.Overlay);
            selection.Overlay = null;
            if (selection.Mask == null || target.Source == null) return;
            Color32[] overlay = new Color32[selection.Mask.Length];
            for (int i = 0; i < overlay.Length; i++)
                overlay[i] = selection.Mask[i] == 0 ? new Color32(255, 55, 35, 0) : new Color32(255, 55, 35, 105);
            selection.Overlay = new Texture2D(target.Source.Width, target.Source.Height, TextureFormat.RGBA32, false, false);
            selection.Overlay.SetPixels32(overlay);
            selection.Overlay.Apply(false, true);
            selection.Overlay.hideFlags = HideFlags.HideAndDontSave;
        }

        private void ClearSelection(RegionGradientTarget target)
        {
            if (target == null) return;
            target.RemoveSelection(ActiveRegion.Id);
            ClearAllResults();
        }

        private void ClearAllSelections()
        {
            for (int i = 0; i < targets.Count; i++) targets[i].RemoveSelection(ActiveRegion.Id);
            statusMessage = ActiveRegion.Name + "の全対象の選択を解除しました。";
            ClearAllResults();
        }

        private void RebuildWorldMaps()
        {
            int built = 0;
            if (avatarRoot == null)
            {
                for (int i = 0; i < targets.Count; i++) targets[i].UvWorldMap = null;
                statusMessage = "アバターのルートが指定されていません。テクスチャ座標で処理します。メイン・サイドに共通の3D座標グラデーションを適用する場合は、アバターのルートを指定してください。";
                ClearAllResults();
                return;
            }
            for (int i = 0; i < targets.Count; i++)
            {
                RegionGradientTarget target = targets[i];
                target.UvWorldMap = null;
                if (target.Source == null || target.Settings.Renderer == null) continue;
                string warning;
                target.UvWorldMap = RegionGradientMeshUtility.BuildWorldMap(
                    target.Settings.Renderer, target.Settings.MaterialIndex, target.Settings.TextureProperty, target.Settings.Texture,
                    avatarRoot, target.Source.Width, target.Source.Height, out warning);
                if (target.UvWorldMap != null) built++;
                if (!string.IsNullOrEmpty(warning)) target.Warning = warning;
            }
            statusMessage = "3D座標マップを " + built + " / " + targets.Count + "件の対象で構築しました。";
            ClearAllResults();
        }

        private static bool HasAnySelectedPixel(byte[] mask)
        {
            if (mask == null) return false;
            for (int i = 0; i < mask.Length; i++)
                if (mask[i] > 0) return true;
            return false;
        }

        private void BuildAllPreviews()
        {
            try
            {
                CancelPendingAdjustmentRefresh();
                bool needsMaps = false;
                for (int i = 0; i < targets.Count; i++)
                    if (targets[i].Settings.Renderer != null && targets[i].UvWorldMap == null) needsMaps = true;
                if (needsMaps) RebuildWorldMaps();

                RegionGradientTarget[] array = targets.ToArray();
                int processed = 0;
                int totalPasses = 0;
                int skippedDisabled = 0;
                int fallbackTargets = 0;
                for (int i = 0; i < targets.Count; i++)
                {
                    RegionGradientTarget target = targets[i];
                    if (target.Source == null) continue;
                    bool hasEnabledSelection = false;
                    for (int r = 0; r < regions.Count; r++)
                    {
                        RegionGradientSelection candidate = target.GetSelection(regions[r].Id, false);
                        if (regions[r].Enabled && candidate != null && HasAnySelectedPixel(candidate.Mask))
                        {
                            hasEnabledSelection = true;
                            break;
                        }
                    }
                    if (hasEnabledSelection && target.Settings.Renderer != null && target.UvWorldMap == null)
                        fallbackTargets++;
                    Color32[] working = (Color32[])target.Source.Pixels.Clone();
                    byte[] combinedApplyWeights = new byte[working.Length];
                    Vector2[] coordinates = RegionGradientMeshUtility.BuildNormalizedCoordinates(array, i);
                    bool changed = false;
                    for (int r = 0; r < regions.Count; r++)
                    {
                        RegionGradientRegion region = regions[r];
                        RegionGradientSelection selection = target.GetSelection(region.Id, false);
                        if (selection == null || !HasAnySelectedPixel(selection.Mask)) continue;
                        if (!region.Enabled)
                        {
                            skippedDisabled++;
                            continue;
                        }
                        RegionGradientResult result = RegionGradientProcessor.Apply(
                            target.Source.Pixels, working, target.Source.Width, target.Source.Height,
                            selection.Mask, coordinates, region.Settings);
                        working = result.Pixels;
                        for (int pixelIndex = 0; pixelIndex < combinedApplyWeights.Length; pixelIndex++)
                            if (result.ApplyWeights[pixelIndex] > combinedApplyWeights[pixelIndex])
                                combinedApplyWeights[pixelIndex] = result.ApplyWeights[pixelIndex];
                        Tekukae.TextureColorEngine.Editor.RecentColorHistory.Record(
                            RegionGradientColorMath.ToSrgb(region.Settings.StartColor, 255));
                        Tekukae.TextureColorEngine.Editor.RecentColorHistory.Record(
                            RegionGradientColorMath.ToSrgb(region.Settings.MiddleColor, 255));
                        Tekukae.TextureColorEngine.Editor.RecentColorHistory.Record(
                            RegionGradientColorMath.ToSrgb(region.Settings.EndColor, 255));
                        totalPasses++;
                        changed = true;
                    }
                    if (!changed) continue;
                    target.BaseResultPixels = working;
                    target.CombinedApplyWeights = combinedApplyWeights;
                    InitializeAdjustmentCache(target);
                    RefreshAdjustedPreview(target, false);
                    processed++;
                }
                statusMessage = processed == 0
                    ? "プレビュー対象がありません。有効な領域で加工範囲を選択してください。"
                    : "プレビューを更新しました（対象 " + processed + "件 / 領域適用 " + totalPasses + "回）。元のテクスチャは変更していません。" +
                      (skippedDisabled > 0 ? " 無効にした領域 " + skippedDisabled + "件は適用していません。" : "") +
                      (fallbackTargets > 0 ? " 3D座標マップを利用できない対象 " + fallbackTargets + "件はUV座標で処理しました。" : "");
            }
            catch (Exception ex)
            {
                statusMessage = "プレビュー生成に失敗しました: " + ex.Message;
                Debug.LogException(ex);
            }
        }

        private void InitializeAdjustmentCache(RegionGradientTarget target)
        {
            if (target == null || target.Source == null || target.BaseResultPixels == null || target.CombinedApplyWeights == null)
                return;

            Rgba32[] basePixels = new Rgba32[target.BaseResultPixels.Length];
            for (int i = 0; i < basePixels.Length; i++)
            {
                Color32 p = target.BaseResultPixels[i];
                basePixels[i] = new Rgba32(p.r, p.g, p.b, p.a);
            }
            TexturePixels baseImage = new TexturePixels(target.Source.Width, target.Source.Height, basePixels, true);
            ColorAdjustmentProcessor.PreviewData preview = ColorAdjustmentProcessor.CreatePreviewData(
                baseImage, target.CombinedApplyWeights, RegionPreviewMaxDimension);
            target.FullAdjustmentBaseImage = baseImage;
            target.AdjustedFullImage = baseImage.Clone();
            target.FullAdjustmentWorkspace = new ColorAdjustmentProcessor.Workspace(
                baseImage, target.CombinedApplyWeights);
            target.HasFinalizedAdjustments = false;
            target.NeedsFullFinalization = true;

            target.AdjustmentPreviewBaseImage = preview.BaseImage;
            target.AdjustedPreviewImage = preview.BaseImage.Clone();
            target.AdjustmentPreviewWorkspace = new ColorAdjustmentProcessor.Workspace(
                preview.BaseImage, preview.ApplyWeights);
        }

        private void ScheduleAdjustedPreviews(bool sliderDragging)
        {
            // Only the active target is visible in the preview pane. Mark all outputs dirty,
            // but update only the visible low-resolution preview while dragging.
            for (int i = 0; i < targets.Count; i++)
                if (targets[i].BaseResultPixels != null) targets[i].NeedsFullFinalization = true;
            if (activeTargetIndex >= 0 && activeTargetIndex < targets.Count)
                RefreshAdjustedPreview(targets[activeTargetIndex], true);
            adjustmentSliderDragging = sliderDragging;
            adjustmentRefreshPending = true;
            adjustmentRefreshAt = EditorApplication.timeSinceStartup + AdjustmentRefreshDelaySeconds;
            if (!adjustmentRefreshSubscribed)
            {
                EditorApplication.update += UpdateAdjustmentRefresh;
                adjustmentRefreshSubscribed = true;
            }
            if (owner != null) owner.Repaint();
        }

        private void UpdateAdjustmentRefresh()
        {
            if (!adjustmentRefreshPending)
            {
                CancelPendingAdjustmentRefresh();
                return;
            }
            // Do not switch to full resolution while the slider is still held, even
            // if the user pauses during a long drag and the debounce interval expires.
            if (adjustmentSliderDragging || GUIUtility.hotControl != 0) return;
            if (EditorApplication.timeSinceStartup < adjustmentRefreshAt) return;
            FinalizeActiveAdjustedPreview();
        }

        private void FinalizeActiveAdjustedPreview()
        {
            CancelPendingAdjustmentRefresh();
            if (activeTargetIndex >= 0 && activeTargetIndex < targets.Count)
                RefreshAdjustedPreview(targets[activeTargetIndex], false);
            if (owner != null) owner.Repaint();
        }

        private void FinalizeAdjustedPreviews()
        {
            CancelPendingAdjustmentRefresh();
            for (int i = 0; i < targets.Count; i++)
                RefreshAdjustedPreview(targets[i], false);
            if (owner != null) owner.Repaint();
        }

        private void CancelPendingAdjustmentRefresh()
        {
            adjustmentRefreshPending = false;
            adjustmentSliderDragging = false;
            if (adjustmentRefreshSubscribed)
            {
                EditorApplication.update -= UpdateAdjustmentRefresh;
                adjustmentRefreshSubscribed = false;
            }
        }

        private void RefreshAdjustedPreview(RegionGradientTarget target, bool interactivePreview)
        {
            if (target == null || target.Source == null || target.AdjustmentPreviewWorkspace == null) return;

            Rgba32[] adjustedPixels;
            int width;
            int height;
            Color32[] colorBuffer;
            if (interactivePreview)
            {
                target.AdjustmentPreviewWorkspace.ApplyIntoPreview(
                    target.AdjustedPreviewImage.Pixels, outputBrightness, outputSaturation);
                adjustedPixels = target.AdjustedPreviewImage.Pixels;
                width = target.AdjustedPreviewImage.Width;
                height = target.AdjustedPreviewImage.Height;
                colorBuffer = target.ResultPreviewColorBuffer;
                if (colorBuffer == null || colorBuffer.Length != adjustedPixels.Length)
                    target.ResultPreviewColorBuffer = colorBuffer = new Color32[adjustedPixels.Length];
            }
            else
            {
                // Reuse a full-resolution workspace and destination image. A settled
                // preview is only recalculated when the requested values actually change.
                if (target.FullAdjustmentWorkspace == null || target.AdjustedFullImage == null) return;
                if (target.HasFinalizedAdjustments && !target.NeedsFullFinalization &&
                    Mathf.Approximately(target.FinalizedBrightness, outputBrightness) &&
                    Mathf.Approximately(target.FinalizedSaturation, outputSaturation))
                    return;

                target.FullAdjustmentWorkspace.ApplyInto(
                    target.AdjustedFullImage.Pixels, outputBrightness, outputSaturation);
                adjustedPixels = target.AdjustedFullImage.Pixels;
                width = target.AdjustedFullImage.Width;
                height = target.AdjustedFullImage.Height;
                colorBuffer = target.ResultFullColorBuffer;
                if (colorBuffer == null || colorBuffer.Length != adjustedPixels.Length)
                    target.ResultFullColorBuffer = colorBuffer = new Color32[adjustedPixels.Length];
            }

            for (int i = 0; i < adjustedPixels.Length; i++)
            {
                Rgba32 p = adjustedPixels[i];
                colorBuffer[i] = new Color32(p.R, p.G, p.B, p.A);
            }

            Texture2D destinationTexture = interactivePreview
                ? target.ResultInteractiveTexture
                : target.ResultTexture;
            if (destinationTexture == null || destinationTexture.width != width || destinationTexture.height != height)
            {
                if (destinationTexture != null) UnityEngine.Object.DestroyImmediate(destinationTexture);
                destinationTexture = new Texture2D(width, height, TextureFormat.RGBA32, false, false);
                destinationTexture.name = target.Settings.Label +
                    (interactivePreview ? "_グラデーション操作中プレビュー" : "_グラデーションプレビュー");
                if (interactivePreview) target.ResultInteractiveTexture = destinationTexture;
                else target.ResultTexture = destinationTexture;
            }
            destinationTexture.SetPixels32(colorBuffer);
            destinationTexture.Apply(false, false);
            if (!interactivePreview)
            {
                target.HasFinalizedAdjustments = true;
                target.NeedsFullFinalization = false;
                target.FinalizedBrightness = outputBrightness;
                target.FinalizedSaturation = outputSaturation;
            }
            else
            {
                target.NeedsFullFinalization = true;
            }
        }

        private void ExportAllResults()
        {
            int exported = 0;
            string activeTargetOutputPath = null;
            try
            {
                FinalizeAdjustedPreviews();
                for (int i = 0; i < targets.Count; i++)
                {
                    RegionGradientTarget target = targets[i];
                    if (target.ResultTexture == null || target.Source == null) continue;
                    Color32[] pixels = target.ResultTexture.GetPixels32();
                    string name = target.Settings.Label + "_グラデーション";
                    string path = RegionGradientTextureIO.ExportPng(target, pixels, name);
                    if (i == activeTargetIndex)
                        activeTargetOutputPath = path;
                    exported++;
                }

                AssetDatabase.Refresh();
                if (!string.IsNullOrEmpty(activeTargetOutputPath))
                {
                    Texture2D asset = AssetDatabase.LoadAssetAtPath<Texture2D>(activeTargetOutputPath);
                    if (asset != null)
                        EditorGUIUtility.PingObject(asset);
                }

                statusMessage = exported == 0
                    ? "保存できるプレビューがありません。"
                    : exported + "件のPNG画像を保存しました。元のテクスチャは上書きしていません。" +
                      (string.IsNullOrEmpty(activeTargetOutputPath)
                          ? " 現在選択中の対象には保存済みプレビューがないため、プロジェクトウィンドウの強調表示は行っていません。"
                          : " 現在選択中の対象の出力画像をプロジェクトウィンドウで表示しました。");
            }
            catch (Exception ex)
            {
                statusMessage = "保存に失敗しました: " + ex.Message;
                Debug.LogException(ex);
            }
        }

        private bool HasAnyResult()
        {
            for (int i = 0; i < targets.Count; i++) if (targets[i].ResultTexture != null) return true;
            return false;
        }

        private void ClearAllResults()
        {
            CancelPendingAdjustmentRefresh();
            for (int i = 0; i < targets.Count; i++)
            {
                if (targets[i].ResultTexture != null)
                {
                    UnityEngine.Object.DestroyImmediate(targets[i].ResultTexture);
                    targets[i].ResultTexture = null;
                }
                if (targets[i].ResultInteractiveTexture != null)
                {
                    UnityEngine.Object.DestroyImmediate(targets[i].ResultInteractiveTexture);
                    targets[i].ResultInteractiveTexture = null;
                }
                targets[i].BaseResultPixels = null;
                targets[i].CombinedApplyWeights = null;
                targets[i].AdjustmentPreviewBaseImage = null;
                targets[i].AdjustedPreviewImage = null;
                targets[i].AdjustmentPreviewWorkspace = null;
                targets[i].FullAdjustmentBaseImage = null;
                targets[i].AdjustedFullImage = null;
                targets[i].FullAdjustmentWorkspace = null;
                targets[i].HasFinalizedAdjustments = false;
                targets[i].NeedsFullFinalization = false;
                targets[i].ResultPreviewColorBuffer = null;
                targets[i].ResultFullColorBuffer = null;
            }
        }

        private bool HasSceneRenderer()
        {
            for (int i = 0; i < targets.Count; i++)
                if (targets[i].Settings.Renderer != null) return true;
            return false;
        }

        private void StartScenePicking()
        {
            if (scenePicking) return;
            if (!HasSceneRenderer())
            {
                statusMessage = "シーンビューから選択するには、レンダラーを登録した対象が必要です。";
                return;
            }
            scenePicking = true;
            SceneView.duringSceneGui += DuringSceneGUI;
            statusMessage = "シーンビューで登録済みのレンダラーをクリックしてください。クリックした位置に対応するUV領域を自動選択します。";
            SceneView.RepaintAll();
        }

        private void StopScenePicking()
        {
            if (!scenePicking) return;
            scenePicking = false;
            SceneView.duringSceneGui -= DuringSceneGUI;
            SceneView.RepaintAll();
        }

        private void DuringSceneGUI(SceneView sceneView)
        {
            if (!scenePicking) return;
            Event e = Event.current;
            Handles.BeginGUI();
            GUI.Label(new Rect(12f, 12f, 520f, 24f), "領域グラデーション：対象のレンダラーをクリック（Escキーで終了）", EditorStyles.helpBox);
            Handles.EndGUI();
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Escape)
            {
                StopScenePicking();
                if (owner != null) owner.Repaint();
                e.Use();
                return;
            }
            if (e.type != EventType.MouseDown || e.button != 0 || e.alt) return;
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            int bestTarget = -1;
            float bestDistance = float.MaxValue;
            Vector2 bestUv = Vector2.zero;
            for (int i = 0; i < targets.Count; i++)
            {
                RegionGradientTarget target = targets[i];
                if (target.Source == null || target.Settings.Renderer == null) continue;
                Vector2 uv;
                float distance;
                if (!RegionGradientMeshUtility.TryPick(target.Settings.Renderer, target.Settings.MaterialIndex, ray, out uv, out distance)) continue;
                if (distance >= bestDistance) continue;
                Material[] materials = target.Settings.Renderer.sharedMaterials;
                if (target.Settings.MaterialIndex < 0 || target.Settings.MaterialIndex >= materials.Length) continue;
                Material material = materials[target.Settings.MaterialIndex];
                if (material == null) continue;
                string property = target.Settings.TextureProperty;
                if (string.IsNullOrEmpty(property) || !material.HasProperty(property)) continue;
                if (material.GetTexture(property) != target.Settings.Texture) continue;
                Vector2 textureUv = Vector2.Scale(uv, material.GetTextureScale(property)) + material.GetTextureOffset(property);
                textureUv = WrapUv(textureUv, target.Settings.Texture == null ? TextureWrapMode.Repeat : target.Settings.Texture.wrapMode);
                bestTarget = i;
                bestDistance = distance;
                bestUv = textureUv;
            }
            if (bestTarget < 0) return;
            RegionGradientTarget hitTarget = targets[bestTarget];
            if (bestUv.x < 0f || bestUv.x > 1f || bestUv.y < 0f || bestUv.y > 1f) return;
            int x = Mathf.Clamp(Mathf.FloorToInt(bestUv.x * hitTarget.Source.Width), 0, hitTarget.Source.Width - 1);
            int y = Mathf.Clamp(Mathf.FloorToInt(bestUv.y * hitTarget.Source.Height), 0, hitTarget.Source.Height - 1);
            activeTargetIndex = bestTarget;
            SelectRegion(hitTarget, x, y, e.shift, e.control || e.command);
            StopScenePicking();
            e.Use();
            if (owner != null) owner.Repaint();
            sceneView.Repaint();
        }

        private static Vector2 WrapUv(Vector2 uv, TextureWrapMode mode)
        {
            if (mode == TextureWrapMode.Clamp) return new Vector2(Mathf.Clamp01(uv.x), Mathf.Clamp01(uv.y));
            if (mode == TextureWrapMode.Mirror)
            {
                return new Vector2(Mirror(uv.x), Mirror(uv.y));
            }
            return new Vector2(Mathf.Repeat(uv.x, 1f), Mathf.Repeat(uv.y, 1f));
        }

        private static float Mirror(float value)
        {
            float t = Mathf.Repeat(value, 2f);
            return t <= 1f ? t : 2f - t;
        }

        private static string GetTargetLabel(RegionGradientTarget target, int index)
        {
            if (target == null || target.Settings == null) return "対象 " + (index + 1);
            return string.IsNullOrEmpty(target.Settings.Label) ? "対象 " + (index + 1) : target.Settings.Label;
        }

        private static Rect FitRect(Rect container, int width, int height)
        {
            float aspect = (float)width / Mathf.Max(1, height);
            float containerAspect = container.width / Mathf.Max(1f, container.height);
            if (aspect > containerAspect)
            {
                float h = container.width / aspect;
                return new Rect(container.x, container.y + (container.height - h) * 0.5f, container.width, h);
            }
            float w = container.height * aspect;
            return new Rect(container.x + (container.width - w) * 0.5f, container.y, w, container.height);
        }

        private void DrawGradientHandles(Rect imageRect, RegionGradientSettings settings)
        {
            Vector2 center = new Vector2(settings.PositionX, settings.PositionY);
            float angle = settings.AngleDegrees * Mathf.Deg2Rad;
            Vector2 direction = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));
            Vector2 half = direction * (settings.Scale * 0.5f);
            Vector2 start = center - half;
            Vector2 end = center + half;
            Vector2 startGui = UvToGui(imageRect, start);
            Vector2 endGui = UvToGui(imageRect, end);
            Vector2 centerGui = UvToGui(imageRect, center);
            Handles.BeginGUI();
            Handles.color = new Color(1f, 1f, 1f, 0.9f);
            Handles.DrawAAPolyLine(3f, startGui, endGui);
            Handles.color = new Color(0.95f, 0.25f, 0.25f, 1f);
            Handles.DrawSolidDisc(startGui, Vector3.forward, 6f);
            Handles.color = new Color(0.25f, 0.8f, 1f, 1f);
            Handles.DrawSolidDisc(endGui, Vector3.forward, 6f);
            Handles.color = Color.white;
            Handles.DrawWireDisc(centerGui, Vector3.forward, 5f);
            Handles.EndGUI();
        }

        private int HitGradientHandle(Rect imageRect, Vector2 mouse, RegionGradientSettings settings)
        {
            Vector2 center = new Vector2(settings.PositionX, settings.PositionY);
            float angle = settings.AngleDegrees * Mathf.Deg2Rad;
            Vector2 half = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * (settings.Scale * 0.5f);
            Vector2 start = UvToGui(imageRect, center - half);
            Vector2 end = UvToGui(imageRect, center + half);
            Vector2 middle = UvToGui(imageRect, center);
            if (Vector2.Distance(mouse, start) <= 10f) return 0;
            if (Vector2.Distance(mouse, end) <= 10f) return 1;
            if (Vector2.Distance(mouse, middle) <= 9f) return 2;
            return -1;
        }

        private void UpdateGradientHandle(Rect imageRect, Vector2 mouse, int handle, RegionGradientSettings settings)
        {
            Vector2 point = GuiToUv(imageRect, mouse);
            Vector2 center = new Vector2(settings.PositionX, settings.PositionY);
            float angle = settings.AngleDegrees * Mathf.Deg2Rad;
            Vector2 half = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * (settings.Scale * 0.5f);
            Vector2 start = center - half;
            Vector2 end = center + half;
            if (handle == 2)
            {
                center = point;
            }
            else if (handle == 0)
            {
                start = point;
                center = (start + end) * 0.5f;
                Vector2 delta = end - start;
                settings.Scale = Mathf.Clamp(delta.magnitude, 0.05f, 2f);
                settings.AngleDegrees = Mathf.Atan2(delta.y, delta.x) * Mathf.Rad2Deg;
            }
            else
            {
                end = point;
                center = (start + end) * 0.5f;
                Vector2 delta = end - start;
                settings.Scale = Mathf.Clamp(delta.magnitude, 0.05f, 2f);
                settings.AngleDegrees = Mathf.Atan2(delta.y, delta.x) * Mathf.Rad2Deg;
            }
            settings.PositionX = Mathf.Clamp01(center.x);
            settings.PositionY = Mathf.Clamp01(center.y);
            settings.AngleDegrees = RegionGradientColorMath.NormalizeHue(settings.AngleDegrees);
        }

        private static Vector2 UvToGui(Rect imageRect, Vector2 uv)
        {
            return new Vector2(imageRect.x + uv.x * imageRect.width, imageRect.yMax - uv.y * imageRect.height);
        }

        private static Vector2 GuiToUv(Rect imageRect, Vector2 gui)
        {
            return new Vector2(
                Mathf.Clamp01((gui.x - imageRect.x) / Mathf.Max(1f, imageRect.width)),
                Mathf.Clamp01((imageRect.yMax - gui.y) / Mathf.Max(1f, imageRect.height)));
        }

        private static void DrawSeedMarker(Rect imageRect, int x, int y, int width, int height)
        {
            float px = imageRect.x + (x + 0.5f) / width * imageRect.width;
            float py = imageRect.yMax - (y + 0.5f) / height * imageRect.height;
            Color color = new Color(1f, 0.9f, 0.1f, 1f);
            EditorGUI.DrawRect(new Rect(px - 6f, py - 1f, 12f, 2f), color);
            EditorGUI.DrawRect(new Rect(px - 1f, py - 6f, 2f, 12f), color);
        }
    }
}
